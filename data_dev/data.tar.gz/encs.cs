Brněnská Velká cena?
Nejdražší položkou je každoročně před Velkou cenou zalistovací poplatek.
"Masa lidí, která při Grand Prix přijede do Brna, tam utratí peníze za ubytování, jídlo či zábavu, což by mělo víceméně vyvážit náklady spojené s pořádáním akce včetně zalistovacího poplatku," zhodnotil ekonom Petr Pelc.
Velká cena tam přitahuje návštěvníky i ze zahraničí.
Pro Brno je důležitá stejně jako například tuřanské letiště nebo výstaviště.
A to jsou projekty, které se z veřejných peněz podporují, "dodal ekonom.
- náklady za uplynulých pět ročníků: 686 milionů korun
- možná řešení: více peněz od státu, využití reklamní plochy, zvýšení ceny lístků
- aktuální stav: jednání o nové smlouvě na pořádání závodů na dalších pět let
Podle ředitele Institutu veřejné správy Filipa Hrůzy si pořadatelé nyní musí vyhodnotit, jestli je pro Brno závod výhodný.
"Grand Prix totiž odsává peníze z veřejných rozpočtů na jiné záležitosti.
Do budoucna přitom můžou být náklady na motoristickou událost ještě vyšší.
Ve hře je totiž varianta zvýšení zalistovacího poplatku téměř na dvojnásobek.
Jak už Deník Rovnost informoval, zástupci Jihomoravského kraje i Brna kvůli potížím se získáváním peněz na Velkou cenu jednají také o možnosti využít reklamu.
Limitovaný je také výběr firem, protože pokud má Dorna generálního sponzora, tak nemůže být druhým sponzorem firma ze stejné oblasti, "vysvětlila Vaňková.
Více peněz můžou pořadatelé v dalších letech získat také ze vstupenek.
Nehoda na D5: Dálnici zavřela srážka kamionů
Událost byla hlášena kolem 08: 00 na 22. kilometru ve směru na Prahu. "Dálnice je uzavřena, aspoň tedy pro nákladní dopravu. Osobní auta mohou jet přes benzinku," uvedla ráno policejní mluvčí Michaela Richterová. Provoz se podařilo obnovit kolem 14: 30. Předběžná škoda je podle Richterové minimálně dva miliony korun, příčinu nehody policisté vyšetřují.
Mluvčí středočeských hasičů Petr Svoboda uvedl, že jeden kamion přepravoval osobní vozidla a druhý plastový granulát.
K nehodě byli kvůli úniku pohonných hmot povoláni pracovníci odboru životního prostředí berounské radnice.
Vyproštění havarovaných vozidel a zprůjezdnění dálnice zajistila soukromá firma, která odtěžila i kontaminovanou zeminu.
Koordinovaná kontrola prostředků určených na financování projektů realizovaných v rámci Operačního programu přeshraniční spolupráce Česká republika – Polská republika 2007 – 2013
Rozvíjející se společenství obyvatel Evropy je hnací silou přeshraniční spolupráce jako nedílné součásti širší územní kooperace, která je součástí našich životů posledních 20 let.
Nechme tedy toto společenství poskytnout úvodní slovo k této společné zprávě dvou nejvyšších kontrolních institucí sousedících zemí:
Programy pokrývají různé hraniční regiony: některé pokrývají přímořské oblasti, jiné vnitrozemské hranice v rámci EU nebo hranice sdílené s kandidátskými zeměmi.
Většina programů je bilaterálních, ale některé zahrnují i více než dvě sousední země.“
„Programy zahrnují následující aktivity: opravy a rekonstrukce přeshraničních silnic, cyklistických stezek a mostů, investice do přeshraničních systémů pro nakládání s odpady, zdravotnických zařízení, výzkumných středisek, protipovodňových opatření atd., společnou správu přírodních lokalit nebo rozvoj turistických cílů, rozvoj společných služeb pro místní obyvatelstvo, poradenství v otázkách zaměstnanosti, vytváření tematických sítí a klastrů pro inovace.
Podpora z programu je poskytnuta pod podmínkou, že organizace z obou stran hranice (například regionální úřady, univerzity nebo malé a střední podniky) se spojí za účelem realizace projektů, které vycházejí z potřeb hraničního regionu.
Představitelé spolupracujících regionů, relevantních ministerstev a dalších místních partnerů se pravidelně scházejí a rozhodují, které projekty budou podpořeny.
Finanční prostředky jsou poskytnuty s podmínkou, že projektoví partneři z obou stran hranice spolupracují způsobem, který naplňuje alespoň dva z následujících čtyř znaků: společná příprava, společná realizace, společný personál, společné financování.“
V rámci partnerství jsou úkoly a odpovědnost za přípravu, realizaci, financování a kontrolu aktivit projektu jasně definovány a rozděleny příslušným partnerům.
Mezi hlavní atributy partnerství patří: společná volba vedoucího partnera, společná příprava projektu a žádosti, uzavření společné dohody o partnerství podepsané všemi partnery, převzetí celkové zodpovědnosti za realizaci projektu vedoucím partnerem, celkové platby podpory přijímá vedoucí partner a provádí jejich převod příslušným partnerům projektu.
Podpořeny mohou být způsobilé projekty realizované na území krajů a vojvodství přiléhajících ke společné hranici.
Dne 11. prosince 2007 schválila Evropská komise (EK) Operační program přeshraniční spolupráce Česká republika – Polská republika 2007 – 2013 (OPPS ČR – POL).