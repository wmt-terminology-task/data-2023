Brněnská Velká cena?
Nejdražší položkou je každoročně před Velkou cenou zalistovací poplatek.
"Masa lidí, která při Grand Prix přijede do Brna, tam utratí peníze za ubytování, jídlo či zábavu, což by mělo víceméně vyvážit náklady spojené s pořádáním akce včetně zalistovacího poplatku," zhodnotil ekonom Petr Pelc.
Velká cena tam přitahuje návštěvníky i ze zahraničí.
Pro Brno je důležitá stejně jako například tuřanské letiště nebo výstaviště.
A to jsou projekty, které se z veřejných peněz podporují, "dodal ekonom.
- náklady za uplynulých pět ročníků: 686 milionů korun
- možná řešení: více peněz od státu, využití reklamní plochy, zvýšení ceny lístků
- aktuální stav: jednání o nové smlouvě na pořádání závodů na dalších pět let
Podle ředitele Institutu veřejné správy Filipa Hrůzy si pořadatelé nyní musí vyhodnotit, jestli je pro Brno závod výhodný.
"Grand Prix totiž odsává peníze z veřejných rozpočtů na jiné záležitosti.
Do budoucna přitom můžou být náklady na motoristickou událost ještě vyšší.
Ve hře je totiž varianta zvýšení zalistovacího poplatku téměř na dvojnásobek.
Jak už Deník Rovnost informoval, zástupci Jihomoravského kraje i Brna kvůli potížím se získáváním peněz na Velkou cenu jednají také o možnosti využít reklamu.
Limitovaný je také výběr firem, protože pokud má Dorna generálního sponzora, tak nemůže být druhým sponzorem firma ze stejné oblasti, "vysvětlila Vaňková.
Více peněz můžou pořadatelé v dalších letech získat také ze vstupenek.
Nehoda na D5: Dálnici zavřela srážka kamionů
Událost byla hlášena kolem 08: 00 na 22. kilometru ve směru na Prahu. "Dálnice je uzavřena, aspoň tedy pro nákladní dopravu. Osobní auta mohou jet přes benzinku," uvedla ráno policejní mluvčí Michaela Richterová. Provoz se podařilo obnovit kolem 14: 30. Předběžná škoda je podle Richterové minimálně dva miliony korun, příčinu nehody policisté vyšetřují.
Mluvčí středočeských hasičů Petr Svoboda uvedl, že jeden kamion přepravoval osobní vozidla a druhý plastový granulát.
K nehodě byli kvůli úniku pohonných hmot povoláni pracovníci odboru životního prostředí berounské radnice.
Vyproštění havarovaných vozidel a zprůjezdnění dálnice zajistila soukromá firma, která odtěžila i kontaminovanou zeminu.
Koordinovaná kontrola prostředků určených na financování projektů realizovaných v rámci Operačního programu přeshraniční spolupráce Česká republika – Polská republika 2007 – 2013
Rozvíjející se společenství obyvatel Evropy je hnací silou přeshraniční spolupráce jako nedílné součásti širší územní kooperace, která je součástí našich životů posledních 20 let.
Nechme tedy toto společenství poskytnout úvodní slovo k této společné zprávě dvou nejvyšších kontrolních institucí sousedících zemí:
Programy pokrývají různé hraniční regiony: některé pokrývají přímořské oblasti, jiné vnitrozemské hranice v rámci EU nebo hranice sdílené s kandidátskými zeměmi.
Většina programů je bilaterálních, ale některé zahrnují i více než dvě sousední země.“
„Programy zahrnují následující aktivity: opravy a rekonstrukce přeshraničních silnic, cyklistických stezek a mostů, investice do přeshraničních systémů pro nakládání s odpady, zdravotnických zařízení, výzkumných středisek, protipovodňových opatření atd., společnou správu přírodních lokalit nebo rozvoj turistických cílů, rozvoj společných služeb pro místní obyvatelstvo, poradenství v otázkách zaměstnanosti, vytváření tematických sítí a klastrů pro inovace.
Podpora z programu je poskytnuta pod podmínkou, že organizace z obou stran hranice (například regionální úřady, univerzity nebo malé a střední podniky) se spojí za účelem realizace projektů, které vycházejí z potřeb hraničního regionu.
Představitelé spolupracujících regionů, relevantních ministerstev a dalších místních partnerů se pravidelně scházejí a rozhodují, které projekty budou podpořeny.
Finanční prostředky jsou poskytnuty s podmínkou, že projektoví partneři z obou stran hranice spolupracují způsobem, který naplňuje alespoň dva z následujících čtyř znaků: společná příprava, společná realizace, společný personál, společné financování.“
V rámci partnerství jsou úkoly a odpovědnost za přípravu, realizaci, financování a kontrolu aktivit projektu jasně definovány a rozděleny příslušným partnerům.
Mezi hlavní atributy partnerství patří: společná volba vedoucího partnera, společná příprava projektu a žádosti, uzavření společné dohody o partnerství podepsané všemi partnery, převzetí celkové zodpovědnosti za realizaci projektu vedoucím partnerem, celkové platby podpory přijímá vedoucí partner a provádí jejich převod příslušným partnerům projektu.
Podpořeny mohou být způsobilé projekty realizované na území krajů a vojvodství přiléhajících ke společné hranici.
Dne 11. prosince 2007 schválila Evropská komise (EK) Operační program přeshraniční spolupráce Česká republika – Polská republika 2007 – 2013 (OPPS ČR – POL).
Na implementaci operačního programu bylo vyčleněno 258 187 467 €.
Finanční údaje o čerpání prostředků EU z Operačního programu přeshraniční spolupráce Česká republika – Polská republika 2007 – 2013 ke konci roku 2013 jsou uvedeny v následující tabulce:
Dohoda o spolupráci nejvyšších kontrolních institucí České republiky (NKÚ) a Polské republiky (NIK) byla uzavřena prezidenty obou úřadů dne 27. února 2013 po předchozích vzájemných jednáních na zasedání hlav nejvyšších kontrolních institucí Visegrádské čtyřky, Rakouska a Slovinska, která se konala v září 2012 v Lovasberény v Maďarsku.
Cílem spolupráce bylo prověřit, zda implementace operačního programu probíhá v souladu s právními předpisy a se závaznými programovými dokumenty nebo dohodami, zda řídicí a kontrolní systém funguje spolehlivě, zda jsou dosahovány cíle operačního programu a zda jsou vybrané projekty realizovány v souladu se stanovenými podmínkami poskytnuté podpory.
Tato spolupráce měla formu paralelní kontroly, při které kontrolní úřady na základě svého zákonného mandátu nezávisle prověřily témata, jejichž obsah byl předem společně projednán.
Na základě obou kontrolních závěrů, uvedených v příloze, vznikla tato společná zpráva.
Vybraný společný kontrolní vzorek zahrnoval šest projektů (příloha 1), které spadají do oblasti podpory 1.1 – Posilování dopravní dostupnosti a oblasti podpory 2.2 – Podpora rozvoje cestovního ruchu.
Před zahájením kontroly představovalo čerpání finančních prostředků z těchto dvou oblastí podpory více než 60% peněžních prostředků proplacených příjemcům do konce roku 2012 z ERDF za všechny realizované projekty v rámci celého OPPS ČR – POL.
Finanční prostředky vyplacené příjemcům podpory z ERDF, které byly kontrolovány NKÚ a NIK, dosáhly celkové výše 25 362 174 €(NKÚ) a 8 450 784 €(NIK).
Kontrolovaný objem prostředků představoval 41% ze všech prostředků vyplacených příjemcům podpory z oblastí podpory 1.1 a 2.2.
HLAVNÍ KONTROLNÍ ZÁVĚRY
Obě kontroly nezávisle provedené NKÚ na české straně a NIK na polské straně ukázaly, že úroveň identifikovaných nesrovnalostí nepřekročila hladinu významnosti.
Implementace OPPS ČR – POL, zahrnující fungování řídicího a kontrolního systému a realizaci vybraných projektů, byla úspěšná.
Kontrolované osoby, které byly součástí řídicího a kontrolního systému, učinily kroky vedoucí k omezení rizika nesprávného použití finančních prostředků a nevyužití poskytnutých prostředků z ERDF.
Důkazem efektivity realizovaných projektů v rámci operačního programu je vysoká úroveň plnění stanovených cílů, která byla podpořena i výsledky průzkumu společenského hodnocení realizace projektů.
SHRNUTÍ VÝSLEDKŮ KONTROLY
Vyhodnocení řídicího a kontrolního systému
Koordinovaný přístup umožnil provést kontrolu řídicího a kontrolního systému OPPS ČR – POL implementovaného následujícími institucemi v obou zemích: řídicím orgánem (Ministerstvo pro místní rozvoj ČR), národním koordinátorem (Ministerstvo pro místní rozvoj POL) a kontrolory (Centrum pro regionální rozvoj a vojvodství).
Koordinovaný audit zároveň umožnil vyhodnocení úkolů a funkcí realizovaných společným technickým sekretariátem a monitorovacím výborem.
Během hodnocení řídicího systému se kontrola zaměřila na činnosti prováděné v souvislosti s nastavením a výkonem funkce řídicího orgánu a národního koordinátora, a to zejména v souvislosti s nastavením cílů programu a monitorováním dosaženého pokroku, evaluační činností a výročními zprávami, posuzováním, hodnocením, výběrem a schvalováním projektových žádostí, čerpáním prostředků programu a plněním povinnosti zveřejňovat správné, úplné a aktuální informace o dotacích, dále s kontrolní činností řídicího orgánu, nastavením výkonu činností a výstupy z auditů pověřeného auditního subjektu a se systémem hlášení a monitorování nesrovnalostí a jeho dodržováním, zároveň byla prověřena koordinace úkolů a spolupráce mezi institucemi zapojenými do OPPS ČR – POL.
Dále byla prověřena činnost příslušných orgánů v oblasti analýzy rizik a sestavování plánů kontrol v místě realizace projektů a byla posouzena hodnocení projektových žádostí prováděná nezávislými hodnotiteli.
V oblasti hodnocení a schvalování projektů bylo zjištěno riziko netransparentnosti tohoto procesu.
Další nedostatky byly zjištěny v oblasti nastavení monitorovacích indikátorů a v nastavení systému hlášení nesrovnalostí.
Na základě těchto zjištění vyhodnotil Nejvyšší kontrolní úřad kontrolní a řídicí systém implementovaný řídicím orgánem jako částečně účinný.
Nesrovnalosti zjištěné NIK, které se týkaly fungování řídicího a kontrolního systému v Polsku ve vztahu k porušování platných zákonů a pravidel, nebyly vyhodnoceny jako významné.
Uvedené nesrovnalosti měly dopad pouze na jednotlivé projekty a neměly podstatný vliv na implementaci celého OPPS ČR – POL.
B. Vyhodnocení výsledků projektů
Kontrola neprokázala rozpor mezi indikátory a cíli stanovenými pro jednotlivé projekty a těmi vymezenými operačním programem.
Ve všech kontrolovaných projektech byly dosaženy očekávané výsledky, financované aktivity byly realizovány a byly splněny indikátory (měřitelné parametry) stanovené v projektových žádostech operačního programu.
Důležitým aspektem, kterému NKÚ a NIK věnovaly pozornost ve svých závěrech, je omezená možnost objektivního hodnocení plnění předpokládaných výsledků jednotlivých projektů s ohledem na cíle jednotlivých projektů a zároveň na cíle celého operačního programu.
Průzkum a jeho vyhodnocení realizovala Škola vyššího odborného vzdělávání v Nyse (Polsko).
Průzkum se týkal zejména vhodnosti, kvality, výměny informací, využití prostředků a společenské funkce projektů včetně realizovaných investic.
Podle respondentů plnily zkoumané projekty kritéria vyjádřená v operačním programu.
Respondenti si také všimli pozitivního dopadu investic na zlepšení kvality dopravní a turistické infrastruktury, dopravní dostupnosti, turistické atraktivity, podnikatelských podmínek, kvality života občanů a obnovení kontaktů mezi obyvateli hraničního regionu.
Tento rozdíl se vztahuje na hodnocení výsledků jednotlivých projektů, kde v některých případech je významný rozdíl.
C. Vyhodnocení legality kontrolovaných projektů
U příjemců podpory byl prověřen soulad věcné a časové realizace projektu s harmonogramem a obsahem projektové žádosti, dále bylo prověřeno plnění stanovených cílů a účelu projektu, naplňování závazných monitorovacích indikátorů, řízení změn v projektech, nakládání s případnými příjmy projektu, plnění povinnosti oddělené účetní evidence projektových transakcí, dodržování zákazu financování projektů z jiných zdrojů EU, realizování projektového partnerství a dodržování jeho podmínek, plnění povinné publicity týkající se zejména šíření povědomí o zdrojích financování projektů z EU, dodržování podmínek způsobilosti projektových výdajů, vybírání dodavatelů a ověření dodaných plnění na základě zadaných veřejných zakázek.
Celková finanční hodnota nedostatků kvalifikovaných NKÚ a NIK jako výdaje nezpůsobilé k financování z prostředků EU byla zjištěna ve výši 85 094 €.
Navzdory zjištěným nesrovnalostem vyhodnotily NKÚ a NIK implementaci vybraných projektů příjemci podpory pozitivně.
Ve většině případů byly závazky vyplývající z podmínek podpory příjemci řádně plněny.
Prostředky určené na implementaci kontrolovaných projektů byly vynaloženy v souladu s nařízeními EU a národním právem.
Jednalo se o jednotlivé případy nesystémové povahy a týkaly se zvláště nedůsledné přípravy projektové dokumentace a porušení pravidel pro zadávání veřejných zakázek, které však neměly dopad na výběr dodavatele nebo dodávky smluvně dohodnutých prací.
Společné doporučení NKÚ a NIK se týká zlepšení monitorovacího systému zejména s ohledem na konzistentní stanovení řádných monitorovacích indikátorů pro všechny specifické cíle prioritní osy operačního programu.
Všeobecně je také nutné usilovat o stanovení takových indikátorů na úrovni programu i projektů, které umožní spolehlivější ověření plnění stanovených dopadů.
Zpráva byla vyhotovena v českém, anglickém a polském jazyce a podepsána prezidenty nejvyšších kontrolních institucí České republiky a Polské republiky.
Dodatek č. 1 ke Smlouvě o podnájmu bytu ze dne 13. května 2016
Vlastníkem předmětného bytu je bytové družstvo „Bytové družstvo Alfrédova 13“, IČ: 123 45 678, se sídlem v Praze 4, Kamýk, Alfrédova 13, PSČ: 142 00 (dále jen "Bytové družstvo").
Vzhledem k tomu, že obě smluvní strany mají zájem na dalším trvání vztahu založeného Smlouvou o nájmu bytu, dohodly se prodloužení nájmu o další dva roky, tj. nájemkyně je oprávněna předmětný byt užívat až do 31. 12. 2020 včetně.
Tento Dodatek č. 1 nabývá platnosti a účinnosti dnem podpisu oběma smluvními stranami.
Tento Dodatek č. 1 je sepsán a podepsán ve 2 (slovy: dvou) stejnopisech, z nichž každý má platnost originálu.
Každá smluvní strana obdrží jeden stejnopis.
V případě, že některé ustanovení tohoto Dodatku č.1 je, či se stane neplatným nebo neúčinným, není tím dotčena platnost ani účinnost ostatních ustanovení tohoto Dodatku č.1.
Smluvní strany se v takovém případě zavazují nahradit neplatné nebo neúčinné ustanovení tohoto Dodatku č.1 ustanovením platným a účinným, které bude nejvíce odpovídat účelu tohoto Dodatku č.1.
Smluvní strany prohlašují, že si Dodatek č. 1 přečetly, že s jeho obsahem souhlasí a že Dodatek č. 1 byl uzavřen svobodně, vážně, nikoliv v tísni za nápadně nevýhodných podmínek.
Na důkaz těchto skutečností připojují účastníci této Smlouvy svůj vlastnoruční podpis.
Marta Burešová, nájemkyně
Obchodní podmínky pro nájem robotů s technickou asistencí
1.2 „Okolnosti vylučující odpovědnost“ jsou překážky, které nastaly nezávisle na vůli povinné strany a brání jí ve splnění její povinnosti, jestliže nelze rozumně předpokládat, že by povinná strana tyto překážky nebo jejich následky odvrátila nebo překonala, a dále, že by v době vzniku závazku tyto překážky předvídala.
1.3 „Podmínky“ jsou tyto obchodní podmínky pro nájem Robotů s technickou asistencí.
1.6 „Formulář“ je smluvní formulář poskytovaný Pronajímatelem, který obsahuje konkrétní údaje a podmínky každého jednotlivého Nájmu.
1.12 „Technická asistence“ je služba technického personálu Pronajímatele během přípravy a konání Akce.
Technická asistence zahrnuje zejména instalaci Robotů a lokalizačních čidel, přípravu prostor, kde se budou Roboti během Akce pohybovat, dohled nad bezpečným provozem Robotů během Akce, zabezpečení manuálního ovládání Robotů a jejich nabíjení.
2.1 Těmito Podmínkami se řídí Nájem Robotů.
2.2 Formulář a případné dodatky k němu, údaje, které Nájemce poskytne v Návodu a tyto Podmínky, jsou dále společně označeny jako Smlouva.
2.3 Podmínky se použijí na nájem Robotů na Akce konající se v některém z členských států Evropské unie, ve Švýcarsku a Chorvatsku.
3 Nájem
3.1 Pronajímatel se zavazuje v souladu se Smlouvou Customizovat Roboty, poskytnout je k Akci a poskytnout Nájemci Technickou asistenci.
4.5 Pronajímatel ve Formuláři stanoví nájemné, podepíše jej, připojí Návod a zašle Formulář a Návod některým ze způsobů uvedených v článku 11 Nájemci.
4.6 Smlouva je uzavřena okamžikem, kdy Pronajímatel obdrží podepsané přijetí stanovení nájemného ve Formuláři Nájemcem.
Pokud Pronajímatel zjistí nedostatky ve vyplnění Návodu, vyrozumí o nich Nájemce prostřednictvím e-mailu.
Pokud Nájemce nápravu nezjedná do 5 pracovních dní ode dne, kdy připomínky Pronajímatele obdržel, je Pronajímatel oprávněn Customizovat Roboty dle vlastního uvážení a účtovat Nájemci za tuto službu poplatek podle ceníku uvedeného v části 6 Návodu.
4.9 Nájemce může během Customizace písemně požadovat Změny nejpozději 20 dní před začátkem Akce, později pouze s písemným souhlasem Pronajímatele.
Pokud Nájemce žádá více, než tři Změny, je Pronajímatel oprávněn účtovat Nájemci za tuto službu poplatek podle ceníku uvedeného v části 6 Návodu.
4.10 Nájemce je oprávněn smlouvu před uskutečněním Akce písemně zrušit.
Zruší-li Nájemce smlouvu (i) více, než dva měsíce před zahájením Akce, výše odstupného bude odpovídat nákladům Pronajímatele na Customizaci; (ii) dva měsíce až jeden týden před zahájením Akce, výše odstupného bude odpovídat záloze na nájemné; (iii) jeden týden až 24 hodin před zahájením Akce, výše odstupného činí 80% nájemného, (iv) méně, než 24 hodin před zahájením Akce, výše odstupného činí 100% nájemného.
5.2.5 v případě akce přesahující 8 hodin čistého času provozu Robotů zabezpečit zdroje elektrické energie (standardní zásuvka 230 V) pro dobíjení baterií Robotů; Nájemce bere na vědomí, že dobíjení Robotů trvá nejméně 2 hodiny, během nichž nejsou Roboti schopni provozu;
V nájemném je zahrnuta Customizace Robotů, doprava Robotů na místo konání Akce a z něj a Technická asistence.
6.3 Pronajímatel je oprávněn požadovat zaplacení nájemného nebo jeho části po odečtení zálohy kdykoliv po skončení Akce nebo poté, co Nájemce zrušil Smlouvu v souladu s článkem 4.7 nebo pokud Pronajímatel odstoupil od smlouvy podle článku9.
Je-li Nájemce v prodlení, je Pronajímatel oprávněn požadovat zaplacení smluvní pokuty ve výši 0,1% z dlužné částky za každý i započatý den prodlení.
7.1 Pronajímatel odpovídá za to, že Roboti plní během Akce úkoly specifikované Nájemcem ve Smlouvě, zejména se pohybují, přehrávají audio a video, komunikují pomocí dotykového monitoru a tisknou letáky.
7.2.1 Nájemce nedodal ani po písemném upozornění a uplynutí přiměřené lhůty k nápravě podklady specifikované v Návodu; nebo
7.3.2 pokud Roboti neplní dočasně jednu ze základních funkcí (pohyb, audio, video, komunikace prostřednictvím dotykového monitoru, tisk) nebo jsou k dispozici pouze na část Akce, je Nájemce oprávněn požadovat poměrnou slevu na nájemném až do výše nájemného;
7.3.3 pokud Roboti neplní dílčí funkce (např. nelze přehrát jedno video), je Nájemce oprávněn požadovat slevu na nájemném nepřesahující 70% nájemného.
8.2 Pronajímatel odpovídá za škodu způsobenou provozem Robotů či instalací lokalizačních čidel Nájemci nebo třetím osobám.
S výjimkou objektivní odpovědnosti vyžadované kogentními ustanoveními platného práva se pronajímatel zprostí odpovědnosti, pokud škoda měla původ v jednání Nájemce nebo třetí osoby nebo vznikla v důsledku Okolností vylučujících odpovědnost.
8.3 Nájemce odpovídá za škodu, kterou na Robotech během přípravy Akce nebo Akce způsobí nebo kterou způsobí třetí osoby.
Nájemce neodpovídá za škodu, která vznikla v důsledku Okolností vylučujících odpovědnost.
8.4 S ohledem na ustanovení § 379 obchodního zákoníku (zk. č. 513 / 1991 Sb.) a s ohledem na okolnosti uzavření Smlouvy, smluvní strany prohlašují, že úhrnná předvídatelná a přiměřená škoda, která by mohla z porušení Smlouvy nebo platného ustanovení právních předpisů v souvislosti se Smlouvou vzniknout, nepřesáhne částku 250 000 Kč.
9.2 Pronajímatel je oprávněn okamžitě odstoupit od Smlouvy, pokud Nájemce
9.3 Odstoupením od Smlouvy není dotčen nárok oprávněné strany požadovat náhradu škody podle Smlouvy.
10.1 Práva k duševnímu vlastnictví vztahující se k Robotům náleží nadále nositelům těchto práv.
Nájemce není oprávněn jakkoliv zasahovat do těchto práv, zejména není oprávněn měnit, odstraňovat či zakrývat ochranné známky či označení na Robotech.
10.2 Nájemce opravňuje pronajímatele pořizovat audiovizuální záznamy Robotů a uživatelů Robotů při přípravě Akce a během Akce, jakož je i šířit prostřednictvím všech dostupných médií, pokud jejich šířením nebude Nájemce poškozen.
Pronajímatel opravňuje Nájemce pořizovat audiovizuální záznamy Robotů během Akce, jakož je i šířit prostřednictvím všech dostupných médií, pokud jejich šířením bude podpořeno dobré jméno Pronajímatele a / nebo značky […] a pokud jejich šířením nebude Pronajímatel nebo značka […] nijak poškozena.
10.3 V případě porušení povinnosti podle tohoto článku jednou smluvní stranou je poškozená strana oprávněna požadovat smluvní pokutu ve výši 20% nájemného a náhradu škody za každé jednotlivé porušení.
11.1.3 e-mailem na e-mailovou adresu přijímající strany.
V tomto případě nebude e-mail považován za doručený, pokud jej odesílatel písemně nepotvrdí do tří pracovních dní ode dne odeslání e-mailu.
11.3 Strany se mohou ve Smlouvě dohodnout, že budou používat e-mail a jiné prostředky elektronické komunikace k odesílání a přijímání písemné komunikace a tato komunikace bude považována za podepsanou písemnou komunikaci.
12.2 Pokud Smlouva nestanoví jinak, jsou peněžité nároky podle Smlouvy splatné do 14 dní ode dne doručení písemné výzvy oprávněné smluvní strany k jejímu uhrazení povinnou smluvní stranou.
12.3 Ve věcech neupravených smlouvou se právní vztah mezi stranami řídí českým právním řádem, zejména zákonem č. 513 / 1991 Sb., obchodní zákoník, ve znění pozdějších předpisů. Smluvní strany výslovně vylučují použití ustanovení § § 663-723 zákona č. 40 / 1964 Sb., občanský zákoník, ve znění pozdějších předpisů.
12.4 Vztahuje-li se důvod neplatnosti jen na některé ustanovení Smlouvy nebo jeho část, toto ustanovení bude vykládáno nebo omezeno pouze tak, aby byla vyloučena jeho neplatnost. Ostatní ustanovení nebo jejich části zůstanou nedotčeny.
12.6 Smlouva představuje úplnou dohodu smluvních stran o Nájmu. Smlouvu je možné měnit pouze písemnou dohodou oprávněných zástupců smluvních stran.
Smlouva o poskytování služeb podpory provozu a rozvoje informačního systému – Service level agreement
zapsaná v obchodním rejstříku, který vede Městský soud v Praze, spisová značka B 1731
zapsaná v obchodním rejstříku, který vede [●], spisová značka [●]
1.1 V této Smlouvě mají následující výrazy a slovní spojení níže uvedený význam:
Akceptační procedura znamená postup, kterým Objednatel akceptuje Dodávku.
Člověkoden znamená práci jedné osoby po dobu 8 (osmi) pracovních hodin.
Dodávka znamená Verzi, Upgrade nebo Patch, které Dodavatel dodá na základě této Smlouvy.
Každá Dodávka je očíslovaná a obsahuje instalační postup a všechny příslušné náležitosti ve smyslu Průvodního dopisu Dodávky.
Charta projektu znamená dokument, kterým se při plnění Smlouvy formálně řídí procesy a komunikace mezi Stranami.
Charta projektu musí být vypracována v souladu s Metodikou řízení projektu.
Hlášení Incidentu znamená výzva Objednatele na přešetření a vyřešení Incidentu.
Incident kategorie A znamená Incident v provozním prostředí, který znemožňuje užívání Aplikace, nebo jsou nefunkční kritické funkčnosti Aplikace a neexistuje možnost takový Incident obejít využitím jiných funkcí Aplikace, nebo má přímý negativní dopad na koncového zákazníka Oprávněného subjektu.
Některé Incidenty kategorie A jsou uvedeny v Příloze č. 7 (Klasifikace Incidentů).
Incident kategorie B znamená Incident v provozním prostředí, který omezuje, ale neznemožňuje užívání Aplikace, a je možné ho obejít využitím jiných funkcí Aplikace.
Některé Incidenty kategorie B jsou uvedeny v Příloze č. 7 (Klasifikace Incidentů).
Incident kategorie C znamená Incident v provozním prostředí, který není ani Incident kategorie A ani Incident kategorie B. Některé Incidenty kategorie C jsou uvedeny v Příloze č. 7 (Klasifikace Incidentů).
Incident kategorie TA znamená Incident v akceptačním prostředí, který znemožňuje efektivní provádění Akceptační procedury, zcela znemožňuje provědení konkrétního testovacího scenáře, nebo jsou nefunkční kritické funkčnosti Aplikace a neexistuje možnost takový Incident obejít využitím jiných funkcí Aplikace.
Některé Incidenty kategorie TA jsou uvedeny v Příloze č. 7 (Klasifikace Incidentů).
Incident kategorie TB znamená Incident v akceptačním prostředí, který neomezuje efektivní provádění Akceptační procedury, ale znemožňuje provědení nebo dokončení konkrétního testovacího scenáře.
Některé Incidenty kategorie TB jsou uvedeny v Příloze č. 7 (Klasifikace Incidentů).
Incident kategorie TC znamená Incident v akceptačním prostředí, který není ani Incident kategorie TA ani Incident kategorie TB.
Některé Incidenty kategorie TC jsou uvedeny v Příloze č. 7 (Klasifikace Incidentů).
Metodika řízení projektu znamená zásady, kterými se organizuje poskytování Služeb.
Metodika řízení projektu stanovuje závazná pravidla, kterými se, ve shodě se smluvními ujednáními mezi Objednatelem a Zhotovitelem, řídí řídící, koordinační a kontrolní činnosti v rámci poskytování Služeb.
Metodiku řízení projektu Strany projednají, doplní, upraví a schválí v Chartě projektu.
Občanský zákoník znamená zákon č. 89 / 2012 Sb., občanský zákoník ve znění pozdějších předpisů.
Oprávněný subjekt znamená Objednatel a subjekt přímo či nepřímo ovládaný kterýmkoli z konečných vlastníků Objednatele.
Patch znamená inkrementální změnu Aplikace, která řeší Incidenty kategorie A nebo B v provozním prostředí nebo Incidenty kategorie TA nebo TB nebo TC v akceptačním prostředí.
Patch je určený pro konkrétní Upgrade, resp. Patch.
Pracovní den znamená kterýkoli den, kromě soboty a neděle a dnů, na něž připadá státní svátek nebo ostatní svátek podle platných a účinných právních předpisů České republiky.
Pracovní hodina znamená 60 minut v době, kdy je Zhotovitel povinen poskytovat Službu.
Průvodní list Dodávky znamená písemnost, která obsahuje informace o náležitostech Dodávky a informace nezbytné pro její aplikování do technologického prostředí Objednavatele.
Service Level Agreement (dále jen „SLA“) znamená tuto Smlouvu, včetně všech jejích příloh.
Smlouva o dílo znamená smlouva uzavřená mezi Zhotovitelem a Objednatelem podle Přílohy č. 13 (Obsah smluvy o dílo).
Předmětem Smlouvy o dílo je provedení díla na základě Změnové dokumentace.
Smlouva o dílo vzniká v okamžiku, ve kterém Objednatel přijal Zhotovitelovu nabídku ve formě Změnové dokumentace.
Smlouvu o dílo nelze uzavřít ústně.
Obsah Smlouvy o dílo, nedohodnou-li se Strany v konkrétním případě jinak, se řídí Přílohou č. 13 (Obsah smluvy o dílo).
Upgrade obsahuje rovněž popis způsobu testování pro novou funkcionalitu, která se v něm nachází.
Do Upgradu se zařazují Objednavatelem určené změny Aplikace realizované na základě Změnové dokumentace a řešení Incidentů kategorie C.
Verze znamená ucelený stav Aplikace v tvaru, který umožňuje úplnou a samostatnou instalaci Aplikace včetně jejího nastavení, a to tak, aby poskytovala funkcionality ve smyslu Specifikace a provozních nastavení.
Změnové řízení je postup, kterým se provede změna Aplikace a Dokumentace.
Výsledkem Změnového řízení je změna Aplikace a Dokumentace, která je v souladu s požadavkem na změnu.
Všechny odkazy v této Smlouvě na zákony budou vykládány jako odkazy na zákony v platném a účinném znění.
2.1 Za podmínek této Smlouvy, za úplatu, tak, aby Objednatel mohl řádně užívat Aplikaci, Zhotovitel bude Objednateli poskytovat Služby.
Zhotovitel vyvine nejvyšší možné úsilí, které po něm lze spravedlivě požadovat, aby Služby poskytoval na co nejvyšší možné úrovni.
Výše Odměny se vypočíta podle Přílohy č. 2 (Odměna).
3.2 Pokud tato Smlouva skončí před uplynutím období, za které se Odměna platí, Objednatel zaplatí Zhotoviteli poměrnou část Odměny.
Daňový doklad vystaví Zhotovitel po uplynutí měsíce, za který vystavuje daňový doklad.
Dnem zdanitelného plnění je poslední den období, za které Zhotovitel Služby vyúčtuje.
4.5.2 bude obsahovat nesprávné cenové údaje; nebo pokud
4.5.4 daňový doklad bude jinak v rozporu s touto Smlouvou nebo dohodou Stran,
Objednatel má právo daňový doklad před termínem jeho splatnosti vrátit.
Pokud Objednatel neuhradí Odměnu nebo její část z důvodu uplatnění nároku z vad Služeb, není v prodlení.
Ručení za daň z přidané hodnoty
5.1 Podpisem této listiny Zhotovitel prohlašuje, že ke dni uzavření této Smlouvy není ve smyslu zákona č. 235 / 2004 Sb., o dani z přidané hodnoty (dále jen „ZDPH“) nespolehlivým plátcem. Pokud se v době trvání této Smlouvy Zhotovitel stane nespolehlivým plátcem ve smyslu ZDPH, ihned tuto skutečnost oznámí Objednateli.
5.2 Pokud ve smyslu § 109 odst. 3 ZDPH nastane důvod pro vznik Objednatelovy ručitelské povinnosti, Objednatel má právo, postupem podle § 109a ZDPH, za Zhotovitele uhradit stanovenou DPH, a to přímo na účet Zhotovitelova správce daně. Pokud podle předchozí věty DPH místo Zhotovitele uhradí Objednatel, Objednatel Zhotoviteli zaplatí za plnění Odměnu sníženou o takto uhrazenou DPH. Zaplacením takto snížené Odměny zaniká Objednatelova povinnost zaplatit Odměnu.
Tuto částku zaplatí Zhotovitel Objednateli do 1 (jednoho) týdne ode dne, ve kterém byla Zhotoviteli doručena Objednatelova písemná výzva.
Pokud Zhotovitel Objednateli neuhradí částku, kterou na základě ručení místo něj Objednatel uhradil Zhotovitelovu správci daně, Objednatel může tuto svou pohledávku započít na jakoukoli Zhotovitelovu pohledávku za Objednatelem.
6.2 Zhotovitel bude při plnění této Smlouvy postupovat vždy svědomitě, bude respektovat zájmy Objednatele, jež mu jsou známy či mu známy musí být, a to v souladu s principem nejvyšší odborné péče.
Zhotovitel se tímto zavazuje písemně upozornit Objednatele na nevhodnost jeho pokynů.
6.4 Objednatel se zavazuje umožnit Zhotoviteli přístup k vlastnímu software pouze v rozsahu, v jakém to umožňuje příslušná licenční smlouva a v rozsahu nezbytném pro řádné plnění této Smlouvy.
6.5 Zhotovitel může pro poskytování Služeb použít třetích osob za podmínky, že použití těchto osob předem písemně schválí Objednatel.
6.6 Při poskytování Služeb dodržuje Zhotovitel bezpečnostní pravidla uvedená v Příloze č. 12 (Bezpečnostní pravidla).
Zhotovitel se zavazuje poskytovat Služby v časových odezvách a lhůtách definovaných u jednotlivých Služeb.
7.1 Obě Strany si budou navzájem vyměňovat všechny informace potřebné k naplňování této Smlouvy.
7.2 Zhotovitel vždy písemně upozorní Objednatele, že Objednatel neposkytl součinnost, a to bezodkladně poté, co mu nebude součinnost poskytnuta.
V písemném upozornění podle předchozí věty uvede Zhotovitel (1) o jaké konkrétní neposkytnutí součinnosti Objednatele se jedná, (2) způsob, jak Objednatel má součinnost poskytnout, a (3) uvést lhůtu pro dodatečné poskytnutí součinnosti.
Pokud v důsledku neposkytnutí součinnosti, na které byl Objednatel Zhotovitelem písemně upozorněn, dojde ke zpoždění v poskytování Služby, prodlužuje se doba pro poskytnutí Služby o dobu, po kterou neposkytnutí součinnosti ze strany Objednatele trvalo.
7.4 Pokud Objednatel Zhotoviteli neposkytne součinnost ani přesto, že mu k jejímu poskytnutí Zhotovitel určil přiměřenou lhůtu, Zhotovitel nemá právo na účet Objednatele zajistit náhradní plnění, ani nemá právo, i kdyby na to Objednatele upozornil, od této Smlouvy odstoupit.
8.1 Komunikace Stran při plnění této Smlouvy se řídí projektovými zásadami.
Projektové zásady určuje Příloha č. 6 (Metodika řízení projektu).
Metodika řízení projektu stanovuje závazná pravidla, kterými se řídí řídící, koordinační a kontrolní činnosti při poskytování Služeb.
Chartu projektu Strany schválí nejpozději do dvou (2) týdnů ode dne, ve kterém poslední Strana podepsala tuto listinu.
9.1 Zhotovitel odpovídá za to, že všechny jím poskytnuté Služby bude poskytovat v souladu se všemi českými obecně závaznými právními předpisy a touto Smlouvou, a že poskytnuté Služby neporušují žádné právo duševního vlastnictví třetí strany, včetně patentové ochrany, ochranných známek, autorských práv anebo obchodního tajemství.
9.2 Objednatel má právo kontrolovat postup při poskytování Služeb a plnění této Smlouvy.
Akceptační procedura, Předání Dodávky Upgrade do Akceptační procedury
10.1 Cílem Akceptační procedury je ověřit, zda se výsledek Zhotovitelovy činnosti shoduje se Specifikací a Změnovou dokumentací Změn zařazených do Dodávky Upgrade.
Dále je cílem Akceptační procedury oveřit, zda Incidenty zařazené do Dodávky Upgrade jsou vyřešeny.
10.2 Náležitosti a kroky Akceptační procedury jsou uvedeny v Příloze č. 9 (Akceptační procedura).
10.3 Pokud Zhotovitel výsledek své činnosti podle této Smlouvy předvede Objednateli a prokáže výsledky jednotkových a integračních testů, které na takovém výsledku provedl, výsledek své činnosti Zhotovitel odevzdá Objednateli k provedení Akceptační procedury.
10.4 O odevzdání výsledku Zhotovitelovi činnosti k Akceptační proceduře sepíší Strany zápis.
Návrh Zápisu o odevzdání Dodávky Upgrade k Akceptační proceduře předloží Zhotovitel.
Návrh Zápisu o odevzdání Dodávky Upgrade k Akceptační proceduře vždy obsahuje výsledek jednotkových a integračních testů.
Vzor Zápisu o odevzdání Dodávky Upgrade k Akceptační proceduře je obsahem Přílohy č. 10 (Vzor Zápisu o odevzdání Dodávky Upgrade k Akceptační proceduře).
Zahájení, průběh a ukončení Akceptační procedury Dodávky Upgrade
11.1 Bez zbytečného odkladu poté, co Strany podepíší Zápis o odevzdání Dodávky Upgrade k Akceptační proceduře, dohodnou si časový harmonogram provedení Akceptační procedury a Objednatel zahájí Akceptační proceduru.
11.2 V průběhu provádění Akceptační procedury Objednatel sepisuje Incidenty, které se na výsledku Zhotovitelovy činnosti, ve srovnání s požadovanými vlastnostmi Dodávky Upgrade, projevily a tento soupis odevzdá Zhotoviteli.
Incidenty může Objednatel hlásit Zhotoviteli i v průběhu provádění Akceptační procedury.
V průběhu Akceptační procedury Zhotovitel může Incidenty řešit, vady odstraňovat a ve smyslu smluvených postupů opravený výsledek své činnosti odevzdávat Objednateli k dalšímu provádění Akceptační procedury.
11.3 Akceptační procedura je ukončena buď:
11.3.2 ukončením období, které pro provádění Akceptační procedury určuje dohodnutý časový harmonogram; nebo
11.3.3 pokud v průběhu provádění Akceptační procedury počet Incidentů, které jsou vadami, překročí počet vad uvedený v akceptačních kritériích, který dává Objednateli právo Akceptační proceduru zastavit.
12.1 Pokud byly provedeny všechny kroky Akceptační procedury, a pokud Dodávka upgrade splňuje všechny v Příloze č. 9 (Akceptační procedura) uvedená akceptační kritéria, a pokud do ukončení Akceptační procedury Zhotovitel vyřešil všechny nahlášené Incidenty výsledku své činnosti a odstranil všechny identifikované vady výsledku své činnosti, Akceptační procedura se ukončí jako úspěšná bez výhrad.
12.2 Pokud byly provedeny všechny kroky Akceptační procedury a pokud Dodávka Upgrade splňuje všechny v Příloze č. 9 (Akceptační procedura) uvedená akceptační kritéria, a pokud do ukončení Akceptační procedury Zhotovitel nevyřešil všechny nahlášené Incidenty výsledku své činnosti a neodstranil všechny identifikované vady výsledku své činnosti, Akceptační procedura se ukončí jako úspěšná s výhradou.
12.3 Pokud se Akceptační procedura ukončí jako úspěšná, Strany sepíší Zápis o převzetí Dodávky Upgrade do užívání.
Návrh zápisu o převzetí Dodávky Upgrade do užívání předloží Zhotovitel.
Pokud Dodávka Upgrade má vady, návrh takového zápisu vždy obsahuje seznam vad a požadovaný termín jejich odstranění.
Nejpozději do jednoho (1) týdne ode dne, ve kterém Objednatel vyjádřil souhlas s návrhem Zápisu o převzetí Dodávky Upgrade do užívání, Strany zápis podepíší.
Vzor takového zápisu o převzetí Dodávky Upgrade do užívání tvoří Přílohu č. 11 (Vzor Zápisu o převzetí Dodávky Upgrade do užívání).
12.4 Pokud se Akceptační procedura ukončí jako úspěšná s výhradou odstranění vad, Zhotovitel odstraní všechny vady v termínech uvedených v Zápisu o převzetí Dodávky Upgrade do užívání.
Opravenou Dodávku Zhotovitel předá Objednateli k opakovanému ověření.
Pokud v termínech uvedených v Zápisu o převzetí Dodávky Upgrade do užívání Zhotovitel neodstraní všechny vady, Zhotovitel je v prodlení.
12.5 Podpisem Zápisu o převzetí Dodávky Upgrade k užívání (1) Objednatel potvrzuje, že v okamžiku podpisu takového zápisu Dodávka Upgrade nemá vady, které brání užívání Aplikace a (2) Zhotovitel prohlašuje, že Dodávka Upgrade je provedena v souladu se Specifikací a Změnovou Dokumentaci Změn zařažených do Upgrade a českým právním řádem.
Okamžik, ve kterém poslední Strana podepíše Zápis o převzetí Dodávky Upgrade do užívání je okamžikem, ve kterém (1) Zhotovitel splnil svou povinnost provést Dodávku a (2) Objednatel nabývá vlastnické právo k Dodávce.
12.6 I když je Objednatel v prodlení s převzetím Dodávky Upgrade, Zhotovitel nemá právo Dodávku Upgrade prodat třetí osobě.
Pokud Objednatel Dodávku Upgrade převezme, práva ze zjevné vady Dodávky Upgrade mu zůstávají zachována, a to i když Zhotovitel soudu namítne, že právo nebylo uplatněno včas.
Neúspěšné ukončení Akceptační procedury Dodávky Upgrade
Akceptační procedura se ukončí jako neúspěšná také, pokud v průběhu provádění Akceptační procedury počet vad, které Objednatel zjistí, překročí počet vad uvedený v akceptačních kritériích, který dává Objednateli právo Akceptační proceduru zastavit.
Pokud se Akceptační procedura ukončí jako neúspěšná, Objednatel sepíše vady, které se na k provedení Akceptační procedury odevzdané Dodávce Upgrade projevily a tento soupis, spolu s Dodávkou Upgrade, vrátí Zhotoviteli.
13.2 Pokud se Akceptační procedura ukončí jako neúspěšná, má se za to, že Zhotovitel neodevzdal Dodávku Upgrade k provedení Akceptační procedury.
Na příslušný Zápis o odevzdání Dodávky Upgrade k provedení Akceptační procedury se pohlíží, jako by nikdy nevznikl.
13.3 Pokud Dodávku Upgrade Zhotovitel neodevzdá k provedení Akceptační procedury včas, Zhotovitel je v prodlení.
13.4 Pokud se Akceptační procedura ukončí jako neúspěšná, Zhotovitel v co nejkratším čase odstraní vady, které vedly k ukončení Akceptační procedury jako neúspěšné a opravenou Dodávku odevzdá Objednateli k provedení opakované Akceptační procedury.
Náklady na provedení opakované Akceptační procedury nese Zhotovitel.
14.1 Cílem Akceptační procedury je ověřit, zda se výsledek Zhotovitelovy činnosti vyřešil Incident nebo Incidenty zařazené do Dodávky Patch.
14.2 Náležitosti a kroky Akceptační procedury jsou uvedeny v Příloze č. 9 (Akceptační procedura).
Součástí Akceptační procedury jsou akceptační kritéria, které musí Dodávka Patch splnit.
14.3 Bez zbytečného odkladu poté, co Zhotovitel odevzdá Dodávku Patch k Akceptační proceduře, Objednatel zahájí Akceptační proceduru.
14.4 V průběhu provádění Akceptační procedury Objednatel oveří, zda Incidenty, které Dodávka Patch obsahuje, jsou vyřešeny.
14.5 Pokud byly provedeny všechny kroky Akceptační procedury, a pokud Dodávka Patch splňuje všechny v Příloze č. 9 (Akceptační kritéria) uvedená akceptační kritéria, Akceptační procedura se ukončí jako úspěšná.
Pokud Dodávka Patch nevyřešila všechny v něm zařazené Incidenty, Dodavatel vyřeší takové Incidenty v další Dodávce Patch.
14.6 Pokud Dodávka Patch nesplňuje v Příloze č. 9 (Akceptační procedura) uvedená akceptační kritéria Akceptační procedura se ukončí jako neúspěšná a Objednatel sepíše vady, které se na k provedení Akceptační procedury odevzdané Dodávce Patch projevily a tento soupis, spolu s Dodávkou Patch, vrátí Zhotoviteli.
15.1 Pokud při poskytování Služeb vznikne zdrojový kód, Zhotovitel při akceptaci Dodávky Upgrade odevzdá tento zdrojový kód Objednateli, a to v zapečetěném obalu.
Objednatel má právo provést kontrolu zdrojového kódu proti např. škodlivému kódu nebo bezpečnostním rizikům, případně pro účely splnění nařízení kontrolního úřadu.
15.2 Pokud ani na druhou písemnou výzvu, kterou Objednatel Zhotoviteli odešle nejdříve po třech (3) týdnech ode dne odeslání první výzvy, Zhotovitel neposkytne součinnost při řešení problému souvisejícího s Aplikaci, Objednatel má právo jakýmkoli způsobem použít zdrojový kód, včetně jeho úpravy nebo předání třetí osobě za účelem úpravy.
15.3 Zdrojový kód předá Zhotovitel Objednateli v editovatelné elektronické podobě, ve formátu daného vývojového prostředí a ve verzi, která odpovídá aktuální verzi Aplikace.
Zdrojový kód předá Zhotovitel Objednateli nejpozději v den, ve kterém Strany podepíší Zápis o převzetí Dodávky Upgrade k užívání.
Spolu se zdrojovým kódem Zhotovitel předá Objednateli veškeré se zdrojovým kódem související materiály.
16.1.1 uzavřením a plněním této Smlouvy neporuší žádné platné právní předpisy České republiky; a že
16.1.2 disponuje veškerými licencemi, souhlasy, registracemi nebo schváleními, které jsou nezbytné pro uzavření nebo plnění této Smlouvy, a že tyto licence, souhlasy, registrace nebo schválení jsou platné a účinné; a že
16.1.4 se podrobně seznámil s obchodní činností Oprávněných subjektů, zejména s jejich obchodními procesy, a že se seznámil s platnými právním řádem České republiky, a to tak, aby mohl poskytovat Služby v souladu se obchodní činností Oprávněných subjektů a uvedenými právními řády; a že
16.1.6 neexistují žádné události, skutečnosti nebo okolnosti, které mohou být považovány za porušení této Smlouvy.
16.2 Pokud některé ze Zhotovitelových prohlášení bude nepravdivé anebo zavádějící Zhotovitel zaplatí Objednateli smluvní pokutu ve výši 25 000 Kč za každé takové nepravdivé nebo zavádějící prohlášení.
Ochrana osobních údajů
17.1 Při poskytování Služeb nesmí Zhotovitel nakládat s osobními údaji zpracovávanými Oprávněnými subjekty.
Zhotovitel zejména nesmí nakládat s osobními údaji zaměstnanců, klientů Oprávněných subjektů, či dalších osob, jejichž osobní údaje Oprávněný subjekt zpracovává v rámci svých IT systémů či jiným způsobem (dále jako „Osobní údaje“).
Pokud se pro účely řádného poskytnutí Služby v průběhu poskytování Služeb ukáže nezbytné, aby Zhotovitel zpracovával Osobní údaje, před započetím zpracování Zhotovitel oznámí tuto skutečnost Objednateli, uzavře s ním příslušnou smlouvu o zpracování Osobních údajů a případně podnikne další kroky tak, aby veškeré zpracování Osobních údajů probíhalo v souladu s platnými právními předpisy.
18.1 Strany zachovají mlčenlivost o této Smlouvě a všech skutečnostech, které se v souvislosti s touto Smlouvou dozvěděly.
Zejména Strany zachovají mlčenlivost o takových informacích, které tvoří předmět jejich obchodního tajemství nebo obchodního tajemství Oprávněných subjektů (skutečnosti, o kterých se v souvislosti s touto Smlouvou Strany dozvěděly a informace, které tvoří předmět jejich obchodního tajemství nebo obchodního tajemství Oprávněných subjektů dále jen „Důvěrné informace“).
Přijímající Strana vyvine pro utajení Důvěrných informací předávající Strany stejné úsilí, jako by se jednalo o její vlastní Důvěrné informace.
Důvěrné informace použijí Strany pouze k plnění této Smlouvy.
18.3 Důvěrnými informacemi nejsou informace, které:
18.3.4 po podpisu této Smlouvy třetí osoba poskytne přijímající Straně, jež takové informace přitom nezískala přímo ani nepřímo od Strany, která je jejich vlastníkem.
18.4 Podpisem této listiny Zhotovitel bere na vědomí, že se při plnění této Smlouvy může seznámit se skutečnostmi, které podle zákona č. 21 / 1992 o bankách tvoří bankovní tajemství (dále jen „Bankovní informace“). Zhotovitel nezpřístupní žádné Bankovní informace žádné třetí osobě ani nebude Bankovní informace jakýmkoli způsobem shromažďovat, sbírat, uchovávat, rozšiřovat, zpřístupňovat, zpracovávat, využívat či sdružovat s jinými informacemi jinak než za účelem plnění této Smlouvy. V období, kdy bude s Bankovními informacemi nakládat, Zhotovitel zajistí jejich maximální ochranu, kterou po něm lze rozumně požadovat, před jejich ztrátou, odcizením, zničením, neoprávněným přístupem, náhodným či jiným poškozením či jiným neoprávněným využíváním nebo zpracováním. Po skončení činnosti podle této Smlouvy Zhotovitel bez zbytečného odkladu vrátí Objednateli veškeré Bankovní informace, jejich kopie, popřípadě jejich záznamy pořízené na nosičích dat či jiných médiích. Zhotovitel nemá v žádném případě právo si Bankovní informace ponechat nebo je používat za jiným účelem než naplňování této Smlouvy. Tato povinnost i povinnost mlčenlivosti trvá i po skončení této Smlouvy.
18.5 Pokud Zhotovitel poruší svou povinnost mlčenlivosti a Důvěrné informace nebo Bankovní informace se dozví třetí osoba, za každé takové porušení povinnosti mlčenlivosti Zhotovitel zaplatí Objednateli smluvní pokutu ve výši 500 000 Kč.
Pokud Objednatel poruší svou povinnost mlčenlivosti a Důvěrné informace se kromě Oprávněného subjektu dozví třetí osoba, za každé takové porušení povinnosti mlčenlivosti Objednatel zaplatí Zhotoviteli smluvní pokutu ve výši 500 000 Kč.
Smluvní pokuta
19.1 Pokud některou ze Služeb na přivolání Zhotovitel neposkytne v dohodnuté provozní době, Zhotovitel za každý den, ve kterém některou z takových Služeb neposkytl v dohodnuté provozní době, zaplatí Objednateli smluvní pokutu ve výši 5% z Měsíčního paušálního poplatku.
19.2 Pokud Zhotovitel neodstraní Incident kategorie A ve lhůtě na vyřešení Incidentu kategorie A, za každou hodinu prodlení Zhotovitel zaplatí Objednateli smluvní pokutu ve výši 500 CZK.
19.3 Pokud Zhotovitel neodstraní Incident kategorie B ve lhůtě na vyřešení Incidentu kategorie B, za každou hodinu prodlení Zhotovitel zaplatí Objednateli smluvní pokutu ve výši 300 CZK.
19.4 Pokud Zhotovitel neodstraní Incident kategorie C ve lhůtě na vyřešení Incidentu kategorie C, za každý den prodlení Zhotovitel zaplatí Objednateli smluvní pokutu ve výši 1 000 CZK.
19.6 Pokud při poskytování Služby Změnové řízení Zhotovitel nedodá Dodávku včas, Zhotovitel zaplatí Objednateli jednorázovou smluvní pokutu ve výši 1% z Odměny za Dodávku a dále za každý den prodlení 0,1% z takové Odměny.
19.7 Pokud Zhotovitel nedodá Expertní službu včas, Zhotovitel za každý den prodlení zaplatí Objednateli smluvní pokutu ve výši 0,5% z Odměny za příslušnou Expertní službu, nejméně však 1 000 CZK.
Splatnost sankcí a následky porušení Smlouvy
20.2 Zaplacení smluvní pokuty anebo jiné sankce podle této Smlouvy se nedotýká povinnosti zaplatit smluvní pokutu anebo jinou sankci při opětovném porušení stejné povinnosti nebo při porušení jiné povinnosti podle této Smlouvy.
Zaplacením smluvní pokuty anebo jiné sankce nezaniká povinnost splnit povinnost smluvní pokutou anebo jinou sankcí zajištěnou.
Zaplacením smluvní pokuty anebo jiné sankce není dotčen nárok na náhradu újmy vzniklé v důsledku porušení této Smlouvy.
Povinnost nahradit újmu
Zhotovitel však upozorní Objednatele na věcně nesprávné nebo jinak chybné zadání.
Žádná ze Stran není odpovědná za prodlení se splněním povinnosti, pokud svou povinnost nesplnila v důsledku prodlení druhé Strany nebo v důsledku okolností vylučujících odpovědnost.
21.3 Pokud nastanou okolnosti, které vylučují odpovědnost a zároveň brání řádnému plnění této Smlouvy, Strana, která se o vzniku takové skutečnosti dozvěděla, na ni bez zbytečného odkladu upozorní druhou Stranu.
Strany vyvinou nejvyšší možné úsilí, které po nich lze rozumně požadovat, aby se okolnosti vylučující odpovědnost odvrátily a překonaly.
Újmu podle předchozí věty nahradí Zhotovitel včetně případných regresních nároků třetích osob vůči Oprávněnému subjektu.
23.1 Bez předchozího písemného Objednatelova souhlasu Zhotovitel nesmí své pohledávky za Objednatelem postoupit na třetí osobu ani nesmí tyto pohledávky třetí osobě zastavit, a to ani částečně.
K provádění jednotlivých úkonů při plnění této Smlouvy, v rozsahu, jak určuje Metodika řízení projektu, Strany pověřují vedoucí projektu určené v Chartě projektu.
24.1.2 Kontaktní osobou za Zhotovitele je:
24.2 Kontaktní osoby a jejich kontaktní údaje mohou Strany změnit jednostranným písemným oznámením, které doručí druhé Straně na adresu uvedenou v záhlaví této Smlouvy, nebo podle Charty projektu.
24.3 Všechna oznámení nebo sdělení doručovaná v souvislosti s plněním předmětu této Smlouvy se považují za účinná okamžikem jejich doručení druhé Straně.
24.3.2 e-mailové zprávy okamžik, ve kterém poštovní server příjemce zprávy přijme odesílatelovu e-mailovou zprávu;
24.3.3 doručení poštou třetí (3) pracovní den po odeslání doporučenou poštou.
Trvání a zánik Smlouvy
25.1 Tato Smlouva se uzavírá na dobu neurčitou.
Takovou část určí Objednatel.
Tyto licence zahrnují také Objednatelovo právo realizovat podporu provozu a rozvoje Aplikace vlastní činností nebo prostřednictvím třetí osoby a s použitím zdrojových kódů.
25.4 I po zániku této Smlouvy Stranám trvají práva a povinnosti, které jim vznikly v souvislosti s povinností poskytovat Služby v souladu s právním řádem; a v souvislosti s povinností mlčenlivosti; a v souvislosti s případnými sankcemi podle této Smlouvy a povinností k náhradě újmy a slibu odškodnění.
26.1 Strany mají právo tuto Smlouvu kdykoli písemně vypovědět, a to i bez udání důvodu.
26.2 Strany mají právo tuto Smlouvu písemně vypovědět s okamžitou platností, pokud druhá Strana pozbude podnikatelské oprávnění nezbytné pro plnění povinností podle této Smlouvy.
26.3 Zhotovitel má právo tuto Smlouvu písemně vypovědět s okamžitou platností, pokud:
26.3.1 je Objednatel déle než jeden (1) měsíc v prodlení s jakoukoli částkou, kterou má podle této Smlouvy zaplatit Zhotoviteli a ani do dvou (2) týdnů od dne doručení Zhotovitelovy písemné výzvy, nezjedná nápravu, Zhotovitel však nemá právo tuto Smlouvu vypovědět, pokud Objednatel takovou částku nezaplatí z důvodu uplatnění vad; nebo pokud
26.3.2 Objednatel opakovaně poruší svou významnou povinnost podle této Smlouvy a ani do jednoho (1) měsíce od dne doručení Zhotovitelovy písemné výzvy, nezjedná nápravu.
a dále má Objednatel právo tuto Smlouvu s okamžitou platností vypovědět, pokud:
26.5.3 Zhotovitel jiným než podstatným způsobem poruší svoji povinnost, z této Smlouvy, a ani ve lhůtě dvou (2) týdnů od dne doručení Objednatelovy písemné výzvy, nezjedná nápravu; a dále pokud
26.5.6 insolvenční soud vydá rozhodnutí o úpadku Zhotovitele; a dále pokud
26.5.8 insolvenční soud prohlásí konkurs na majetek Zhotovitele; nebo pokud
26.5.9 vyjma sloučení nebo splynutí, příslušný orgán Zhotovitele přijme rozhodnutí o povinném nebo dobrovolném zrušení Zhotovitele.
27.1 Tato Smlouva je úplnou dohodou Stran o předmětu této Smlouvy. Tato Smlouva nahrazuje všechny předchozí dohody Stran o předmětu této Smlouvy.
Odpověď obsahující dodatek nebo odchylku od původního návrhu, které podstatně nemění podmínky takového návrhu, není přijetím návrhu.
Spory z této Smlouvy rozhoduje Městský soud v Praze.
27.4 Pokud některá ze Stran neuplatní svá práva z této Smlouvy nebo taková práva uplatní opožděně, neznamená to, že se Strana takových svých práv vzdala.
Práva upravená v této Smlouvě lze uplatňovat souběžně.
27.5 Pokud soud nebo státní orgán rozhodne, že některé ustanovení této Smlouvy je neplatné nebo neúčinné, zůstávají ostatní ustanovení této Smlouvy, i tato Smlouva jako celek, platná a účinná.
27.6.6 Příloha č. 6, Metodika řízení projektu
27.6.8 Příloha č. 8, Vzor Požadavku na změnu
27.6.9 Příloha č. 9, Akceptační procedura
27.6.10 Příloha č. 10, Vzor Zápisu o odevzdání Dodávku Upgrade k Akceptační proceduře
27.6.11 Příloha č. 11, Vzor Zápisu o převzetí Dodávky Upgrade do užívání
27.6.12 Příloha č. 12, Bezpečnostní pravidla
27.6.13 Příloha č. 13, Obsah smlouvy o dílo
27.6.14 Příloha č. 14, Mešíční výkaz Služeb
27.7 Tato Smlouva byla sepsána ve dvou vyhotoveních s platností originálu v jazyce českém, z nichž každá Strana obdrží po jednom.
Tato Smlouva nabývá platnosti a účinnosti dnem, ve kterém tuto listinu podepíše poslední Strana.
Služby bez přivolání (Služby poskytuje Zhotovitel automaticky):
1.1 Služba hotline / Služba představuje dostupnost a schopnost Zhotovitele přebírat Hlášení Incidentů a požadavků na poskytnutí Expertní služby.
Samotné vyřešení Incidentu je poskytováno Službou vyřešení Incidentu a poskytnutí Expertní služby je zabezpečeno Službou Expertní služby.
v Pracovních dnech od 8.00 do 18.00
telefon: + 420 XXX
1.2 Služba pohotovost / Služba představuje dostupnost a schopnost Zhotovitele telefonicky přebírat Hlášení Incidentů kategorie A.
1.4 Služba nové verze z podnětu Zhotovitele / Poskytování nových verzí Aplikace s nezměněným funkčním rozsahem, vyvinutých z podnětu Zhotovitele za účelem zvýšení kvality Aplikace (rychlost zpracování, stabilita, úspora zdrojů).
Zhotovitel musí Objednatele informovat o provádění takovéto změny Aplikace, vyžádat si schválení Objednatele a dohodnout si Upgrade, ve kterém bude takováto změna zařazena a vypracovat příslušné části změnové dokumentace.
1.5 Služba návrhů na optimalizaci Aplikace / Identifikace potenciálních rizik v Aplikaci, ohrožujících její provoz nebo způsobujících výpadky resp. omezení dostupnosti funkcionalit Aplikace a předkládání návrhů z podnětu Zhotovitele na optimalizaci Aplikace s cílem zvyšování kvality, stability, bezpečnosti a dostupnosti Aplikace.
Samotná změna technologického prostředí se realizuje prostřednictvím Expertní služby nebo Služby Změnové řízení.
1.7 Služba měsíčního výkazu / Vypracovávání měsíčního výkazu poskytovaných Služeb ve smyslu Prílohy č. X (Mesačný výkaz Služieb) Zhotovitelem a jeho předložení Objednateli ke schválení.
Služby na přivolání (Služby poskytuje Zhotovitel na Objednatelovu výzvu):
2.1 Služba vyřešení Incidentu / Zahrnuje přešetření, vyřešení a zdokumentování vyřešení Incidentu, a to postupem jak je uvedeno v Postup poskytnutí služby vyřešení incidentu.
Incident kategorie A – 2 Pracovní hodiny od nahlášení
Incident kategorie B – 4 Pracovní hodiny od nahlášení
Incident kategorie C – 1 Pracovní den od nahlášení
Incident kategorie TA – 1 Pracovní den od nahlášení
Incident kategorie TB – 1 Pracovní den od nahlášení
Incident kategorie A – 8 Pracovních hodin od nahlášení
Incident kategorie C – do nejbližšího Upgrade
Incident kategorie TB – 5 Pracovních dní od nahlášení
Incident kategorie TC – 10 Pracovních dní od nahlášení
Oprávněná osoba Zhotovitel na riešenie sporných případů
2.1.1 Zhotovitel poskytne Službu postupem, jak následuje (tento postup dále jen „Postup poskytnutí služby vyřešení incidentu“):
Incident katogorie A ohlásí také na kontaktní údaje Služby pohotovost
V Hlášení Incidentu Objednatel uvede:
1. Kategorii Incidentu; a
V Redmine potvrdí převzetí Hlášení Incidentu a lhůtu na jeho vyřešení
Zhotovitel bezodkladně informuje Objednatele o vynucených změnách termínu vyřešení Incidentu a o příčinách takové změny
Dodá Dodávku Aplikace ve forme Patch nebo Upgrade v závislosti na kategorii Incidentu pokud taková Dodávka vznikne
Zajistí ověření vyřešení Incidentu v souladu s příslušnou Akceptační procedurou
Pokud Incident není vadou Aplikace nebo Dokumentace, Zhotovitel vyčíslí také náklady spojené s vyřešením Incidentu
2.2 Služba Změnové řízení / Provádění změn funkcionality Aplikace na základě požadavku na změnu.
Objednatel nebo Zhotovitel může navrhnout změnu funkcionality Aplikace formou Požadavku na změnu.
Vzor Požadavku na změnu tvoří Přílohu č. 8 (Vzor Požadavku na změnu).
Záměr ke změně funkcionality Aplikace – účel, cíl, rozsah Změny
Konzultace za účelem podrobné definice Změny
V Redmine, podle vzoru v Příloze č. 8, vypracování Požadavku na změnu,
Schválení úplnosti zadání Požadavku na změnu a definovaní termínu na vypracování Funkční specifikace změny, Analýzy dopadu změny a Časové a finanční kalkulace změny (tyto dokumenty dále jen „Změnová dokumentace“) a určení Upgrade, do kterého bude změna zařazena
3 Pracovní dny
Vypracování Změnové dokumentace
Odevzdaní vypracované Změnové dokumentace v termínu akceptovaném Objednatelem
V případě nedodržení termínu odevzdání může Objednatel
• zrušit Požadavek na změnu bez nároku Zhotovitele na případnou fakturaci již provedených prací na Změně
• uplatnit si smluvní pokutu
Do 14 dnů rozhodnutí Objednatele o provedení ve Změnové dokumentaci popsané změne (ve Změnové dokumentaci popsaná změna dále jen „Změna“)
8.1 Neakceptace předložené Změnové dokumentace a odevzdaní připomínek Zhotoviteli
Do 3 pracovních dní od jejich doručení Zhotovitel zapracuje Objednatelovy připomínky.
Pokud bez udání důvodu Zhotovitel nezapracuje připomínky, Objednatel má právo postupovat podle bodu7.
8.2 Akceptace předložené Změnové dokumentace a rozhodnutí, že se má Změna provést
Pokud Objednatel rozhodne, že se Změna má provést, specifikace změny se stává zadáním Změny Aplikace a Zhotovitel zařadí takovou Změnu do dohodnutého Upgrade.
Zhotovitel odpovídajícím způsobem upraví také všechny typy Dokumentace, které Změna zasahuje.
Realizace Změny v souladu se Změnovou dokumentací
Převzetí Dodávky Upgrade a provedení Akceptační procedury
2.3 Expertní služba / Služba, která není hlášením Incidentu ani není modifikací funkcionality Aplikace. Výsledkem této služby je např.:
2.3.4 změny konfigurace nebo nastavení technologického prostředí Objednatele.
Zadá požadavek na poskytnutí Expertní služby v Redmine.
V požadavku na Expertní službu Objednatel popíše Expertní službu, o kterou žádá.
V Redmine potvrdí převzetí požadavku na poskytnutí Expertní služby
Do 5 Pracovních dnů v Redmine navrhne způsob řešení a termín dodání Expertní služby
Pokud je k poskytnutí Expertní služby nevyhnutelný zásah do provozního prostředí, realizaci takového zásahu schvaluje oprávněna osoba Objednatele
Termín dodání Expertní služby se stanovuje jako závazný pro Zhotovitele
Dodá Expertní službu způsobem, který byl dohodnutý v návrhu řešení Expertní služby
Zajistí ověření dodání Expertní služby
V Redmine akceptuje dodání Expertní služby
V případě, že Objednatel neakceptuje dodání Expertní služby, je povinen předložit zdůvodnění
Celková výše Odměny / Celková Odměna za poskytování Služeb se skladá z měsíčního paušálního poplatku a měsíčního poplatku na základě kalkulace.
Odměna se vypočítá podle akceptovaných Človekodní v měsíčním výkazu poskytovaných Služeb.
2.1 Služby bez přivolání: Odměna
2.1.1 Služba hotline: Zahrnuto v měsíčním paušálním poplatku
2.1.2 Služba pohotovost: Zahrnuto v měsíčním paušálním poplatku
2.1.3 Služba poskytování konzultací v souvislosti s Incidenty: Zahrnuto v měsíčním paušálním poplatku
2.1.4 Služba nové verze z podnětu Zhotovitele: Zahrnuto v měsíčním paušálním poplatku
2.1.5 Služba návrhů na optimalizaci Aplikace: Zahrnuto v měsíčním paušálním poplatku
2.1.6 Služba návrhů na optimalizaci technologické platformy: Zahrnuto v měsíčním paušálním poplatku
2.1.7 Služba měšíčního výkazu: Zahrnuto v měsíčním paušálním poplatku
2.2.1 Služba vyřešení Incidentu: Vyřešení Incidentů, které jsou vadami Aplikace nebo Dokumentace, zahrnuto v měsíčním paušálním poplatku. Vyřešení Incidentů, které nejsou vadami Aplikace nebo Dokumentace, zahrnuto v měsíčním poplatku na základě kalkulace
2.2.2 Služba Změnové řízení: Zahrnuto v měsíčním poplatku na základě kalkulace
2.2.3 Expertní služba: Zahrnuto v mesíčním poplatku na základě kalkulace
3. Měsíční paušální poplatek / Měsíční paušální poplatek činí 1 / 12 ročního paušálního poplatku. Roční paušální poplatek činí 10% z celkové hodnoty Aplikace, což představuje XXX CZK bez DPH. Seznam předmětných součástí Aplikace, i s určením jejich hodnoty, které vstupují do celkové hodnoty Aplikace relevantní pro výpočet výše ročního paušálního poplatku, tvoří Přílohu č. 3 (Popis součástí Aplikace a Dokumentace).
Měsíční poplatek na základě kalkulace se vypočítá jako součin počtu akceptovaných Člověkodní příslušného typu aktivity v měsíčním výkazu poskytovaných služeb a příslušné ceny za Člověkoden:
Pro tento výpočet se bere v úvahu pouze ta část vypočteného měsíčního poplatku na základě kalkulace, která převyšuje limit XXX CZK bez DPH, který je již zahrnutý v měsíčním paušálním poplatku. Pokud se v daném měsíci limit nevyčerpal, převádí se nevyčerpaná část do následujícího měsíce, nejvýše však třikrát za sebou.
5. Přehodnocení hodnoty Aplikace / Celková hodnota Aplikace se přehodnocuje pravidelně k 1. 1. příslušného kalendářního roku, přičemž se hodnota jednotlivých součástí Aplikace upravuje (zvyšuje nebo snižuje) o rozsah funkcionality, který byl modifikovaný v průběhu předcházejícího kalendářního roku prostřednictvím Služby Změnové řízení. V rámci tohoto přehodnocování je Objednavatel oprávněn přehodnotit rovněž ostatní atributy výpočtu Odměny a má právo přihlížet ke kvalitě poskytování Služeb, k množství a závažnosti Incidentů a výši Odměny zaplacené Objednavatelem v předcházejícím kalendářním roce Zhotoviteli, a to i v souvislosti s jinými smluvními vztahy mezi Stranami.
Pro účely této smlouvy je za Aplikaci považován informační systém SYSTEM, který zajišťuje automatizaci procesu agendy AGENDA a je složen s následujících součástí:
Dílo dodáno na základě smlouvy o dílo XXX, ze dne DD.MM.RRRR mezi Objednatelem a Zhotovitelem, včetně Dodatku A, B
Definice rozsahu modulu se nachází ve funkční specifikaci v kapitole 3-5
Určeno pro byznys uživatele
Funkční specifikace – detailní popis všech byznys funkcionalit Aplikace s důrazem na byznys slovník (byznys uživatel musí rozumět, co a jak dodaná Aplikace umožňuje automatizovat), popis vzhledu všech obrazovek Aplikace (popis jednotlivých ovládacích prvků a funkcionalit, které zajišťují zpracování údajů) a popis všech tiskových výstupů Aplikace, s definicí jejich vzhledu, obsahu, formátování (popis dokladů, výpisů a tiskových sestav)
Popis byznys procesů – dokument, který doplňuje Funkční specifikaci – detailní popis jednotlivých životních situací Aplikace s důrazem na byznys slovník (byznys uživatel musí rozumět, jak Aplikace funguje ve všech situacích, které automatizuje)
Popis byznys rolí – dokument, který doplňuje Funkční specifikaci – popis byznys / uživatelských rolí Aplikace i s popisem jejich mapování na byznys procesy (byznys uživatel musí rozumět, který typ uživatele provádí příslušné procesy, a vědět, jak jsou mapovány atributy grafického uživatelského rozhraní na jednotlivé byznys role)
4. Popis parametrizace – dokument, který doplňuje Funkční specifikaci – popis parametrizace Aplikace (např. popis způsobu konfigurace produktů, popis nastavení účetních předpisů, popis konfigurace číselníků, popis konfigurace algoritmů,...) s důrazem na přesné hodnoty jednotlivých parametrů i s popisem projevu změny příslušné hodnoty parametru ve zpracování Aplikace (byznys uživatel musí rozumět a přesně vědět, jak je Aplikace parametrizovaná a jak reaguje na jednotlivé hodnoty parametrů, aby dokázal v produktivním provozu uskutečňovat případné změny podle potřeby), popis přenosu konfigurace parametrů z testovacího prostředí do prostředí produkce (Objednavatel musí být schopen konzistentně přenést „otestovanou“ konfiguraci parametrů z prostředí, kde si ji připraví, do prostředí produkce)
Popis UAT scénářů – UAT testovací scénáře, které jsou součástí Akceptační procedury
Určeno pro aplikačního architekta / systémového integrátora
Popis datových rozhraní – dokument, který doplňuje Funkční specifikaci – přesný popis datových rozhraní, která Aplikace zpřístupňuje pro jiné systémy, i s popisem mechanismu jejich volání, způsob validace jednotlivých datových položek (typ, hodnotová omezení, povinnost,...), chybových hlášení, popis nezbytných performance nastavení (rychlost zpracování / poskytnutí údajů, množství volání v čase,...), popis bezpečnostních nastavení (způsob autentizace a autorizace volající protistrany)
Popis rozhraní třetích stran – dokument, který doplňuje Funkční specifikaci – přesný popis služeb a rozhraní systémů třetích stran, které Aplikace při své činnosti využívá / volá (přesný popis datové struktury služby, početnost volání v čase, performance nastavení,...), popis chybových hlášení, popis bezpečnostních nastavení (obdobný obsah jako v předcházející součásti)
3. Popis výkonnostních parametrů – dokument, který doplňuje Funkční specifikaci – popis kritérií / parametrů výkonnosti, které má splňovat Aplikace (např. rychlost odezvy na otevření obrazovky, vygenerování tiskového výstupu, počet paralelně přihlášených uživatelů, maximální doba trvání uzávěrky nebo exportu,...)
Určeno pro bezpečnost
Popis bezpečnostních vlastností – dokument ve formátu .docx nebo .pdf, který doplňuje Funkční specifikaci – přesný popis bezpečnostních algoritmů, popis mechanismu uživatelských rolí a kontroly provádění operací jednotlivými uživateli, popis mechanismu stornování údajů v případě chyby, popis mechanismu auditování prováděných operací, popis aplikace GDPR požadavků, popis ochrany systémových uživatelů a mechanismus jejich přístupu k údajům v Aplikaci, popis logování změn, popis auditu oprávněnosti provádění operací, resp. popis jiných vlastností a parametrů Aplikace souvisejících s bezpečností a bezpečnostními standardy
Aktuální verze jednotlivých součástí Funkční specifikace se nacházejí umístěny na serveru SERVER v lokalitě LOKALITA.
Zdrojové kódy Aplikace – zdrojové kódy Aplikace, umístěné na datovém nosiči (např. CD / USB), ve formátu daného vývojového prostředí i s postupem kompilace do proveditelných kódů
Denní snímek zpracování – časový obraz, jak funguje zpracování Aplikace během dne, kdy se uživatelé mohou do Aplikace přihlásit, kdy se musí odhlásit, aby mohla být korektně provedena uzávěrka, či jiné background procesy, při kterých se s údaji nesmí manipulovat, přičemž tento obraz by měl být popsaný jak pro běžný provozní den, tak i pro den měsíční / čtvrtletní / roční uzávěrky
Provozní příručka administrátora – administrátorská provozní příručka Aplikace popisující činnosti, které musí uskutečňovat IT administrátor Aplikace (zálohování, povinné / volitelné background procesy, čištění logů / chybovníků, …) tak, aby si Aplikace udržovala předepsané výkonnostní parametry
Definice součástí Aplikace, pro které jsou poskytovány Služby
Seznam součástí Aplikace, pro které jsou poskytovány Služby a identifikace jejich hodnoty v CZK bez DPH, která vstupuje do základu pro výpočet ročního paušálního poplatku za Služby
Hodnota součásti v CZK bez DPH
Příloha č. 6 / Metodika řízení projektu
Charta projektu
1.1 Účelem Charty projektu je definice formálních řídících procesů a způsobu komunikace mezi stranami za účelem naplnění předmětu Smlouvy tak, aby provádění díla nebo poskytování služeb bylo v souladu se Smlouvou a touto Metodikou řízení projektu.
Osobám zúčastněným na provádění díla nebo poskytování služeb zpřístupňuje Charta projektu ty části Smlouvy, které jsou nezbytné k naplnění jejího předmětu.
Charta projektu určuje obsazení organizační struktury projektu, způsob komunikace, kontrolní a eskalační mechanizmy a strukturu projektového portálu, na kterém se archivuje veškerá dokumentace související s prováděním díla nebo poskytováním služeb.
Chartu projektu vypracují vedoucí projektu a schválí ji úvodní jednání Steering commitee.
2.1 Organizačními složkami Projektu jsou (1) Steering committee projektu (dále jen „SCP“) a (2) Projektové vedení projektu (dále jen „PVP“) a (3) pracovní týmy.
Pracovní týmy jsou dočasnými organizačními složkami projektu.
3.1 Pravomoci SCP / Steering committee projektu zejména:
3.1.1 schvaluje Chartu projektu; a dále
3.1.2 řeší eskalované otázky, které nebyly vyřešeny na úrovni PVP; a dále
3.1.3 řeší otázky s dopadem na rozsah prováděného díla nebo poskytovaných služeb; a dále
3.1.5 řeší otázky související s odměnou nebo strukturou odměny za poskytované služby nebo prováděné dílo; a dále
3.2 Členové SCP / Za Objednatele jsou členy SCP (1) sponzor projektu za byznys a (2) ředitel divize ISIT a (3) vedoucí projektu.
3.3 Zasedání SCP / SCP zasedá nejméně jednou za čtvrtletí.
SCP zasedá vždy při hodnocení významného milníku harmonogramu dodávek (např. zahájení nebo ukončení akceptační procedury).
SCP zasedá v sídle Objednatele.
3.4 Program zasedání SCP / Program zasedání SCP a podklady, které budou předmětem projednání, doručí členům SCP vedoucí projektu za Zhotovitele, a to alespoň 3 pracovní dny před zasedáním SCP.
Každý člen SCP má jeden hlas.
3.7 Rozhodnutí SCP s dopadem do smluvních podmínek / Pokud se rozhodnutí SCP týká smluvních podmínek, za jakých se provádí dílo nebo poskytují služby, zejména pokud má rozhodnutí SCP dopad do odměny, za kterou se provádí dílo nebo poskytují služby, Objednatel bez zbytečného odkladu po přijetí takového rozhodnutí, připraví dodatek k předmětné smlouvě.
4.1.1 kontroluje veškeré výstupy jednotlivých fází provádění díla nebo poskytování služeb; a dále
4.1.6 eskaluje na zasedání SCP.
4.3 Zasedání SCP / PVP zasedá jednou za týden, v sídle Objednatele nebo formou vzdálené komunikace.
4.4 Program zasedání PVP a podklady / Program zasedání PVP a podklady, které budou předmětem projednání, doručí členům PVP vedoucí projektu za Zhotovitele, a to alespoň 1 pracovní den před zasedáním PVP.
4.4.4 zjištěné problémy a způsob jejich řešení; a
4.4.7 vyhodnocení a další požadavky na součinnost Objednatele; a
4.4.9 požadavky na změnu; a
4.5 Právo přizvat odborníky a poradce / Pokud je jejich přítomnost pro efektivní průběh jednání účelná, obě strany mají právo k jednání PVP přizvat odborníky a poradce, nebo členy projektových týmů.
Pracovní týmy
5.1 Pracovní týmy / Pracovní týmy se skládají z pracovníků Objednatele nebo Zhotovitele a případně pracovníků třetích stran.
Na straně Zhotovitele členy pracovního týmu tvoří:
Úplný přehled obsazení jednotlivých projektových rolí a jejich komunikační matice určuje Charta projektu.Pravidla vzájemné komunikace
Vzájemná, řízená, komunikace projektových týmů zahrnuje zejména:
6.1.1 Projektová jednání (SCP, PVP, konzultace, workshopy, …)
6.1.4 Evidence požadavků na změnu
6.2 Projektové schůzky - program a podklady / Plán a seznam úkolů z projektových schůzek se vždy aktualizuje na následující schůzce.
Podklady se evidují a aktualizují na projektovém portálu.
6.3 Zápisy z projektových schůzek / Z každé projektové schůzky vyhotoví vedoucí projektu Objednatele písemný zápis, který následující pracovní den po projektové schůzce doručí vedoucímu projektu Zhotovitele.
6.4 Úpravy a doplnění zápisu z projektové schůzky / Úpravy a doplnění zápisu z projektové schůzky účastníci provedou do 2 pracovních dnů ode dne doručení zápisu.
7.1 Identifikace a evidence rizik / V průběhu provádění díla nebo poskytováni služeb všechny zúčastněné osoby identifikují a následně dokumentovaným způsobem řídí rizika, která mohou ovlivnit kvalitu výstupů nebo termíny pro provedení díla nebo poskytováni služeb.
7.2 Projednání rizik na zasedání PVP / Projednání a vyhodnocení rizik je povinným bodem jednání každého zasedání PVP.
Zasedání PVP stanoví opatření k eliminaci nebo minimalizaci rizik.
7.3 Eskalace / Pokud dojde k nedohodě nebo pokud je identifikováno riziko se závažností ovlivňující smluvní ujednání nebo harmonogram nebo odměnu, takové riziko eskaluje PVP na jednání SCP.
8.1 Základním nástrojem pro řízení kvality výstupů projektu je akceptační procedura.
8.1.1 Kontrola úplnosti předmětu díla nebo poskytování služeb tak, aby byl naplněn účel smlouvy
odezvy na aktivitu použivatele
když není možné vytisknout dokumentaci nebo sestavu pro klienta
Incident kategorie B znamená Incident v provozním prostředí pokud ku příkladu:
Incident kategorie C znamená Incident v provozním prostředí pokud ku příkladu:
Incident kategorie TA znamená Incident v akceptačním prostředí pokud ku příkladu:
Není možné změniť nektrerý parameter účtu klienta
Incident kategorie TC znamená Incident v akceptačním prostředí pokud ku příkladu:
Způsob / Změny ve způsobu účtování / poplatkování
Vliv změny na existující reporty, definice nových reportů / sestav
Objem nových údajů, požadavky na rychlost zpracování, odezvy systému
Nestandardní požadavky na bezpečnost údajů nebo auditování
Požadavky na nové / změny ve vstupech / výstupech vůči externím systémům
Ostatní požadavky na funkcionalitu, které má splňovat řešení požadavku
(název přílohy nebo napsat „bez příloh“)
Předběžná analýza dopadu změny (AA)
Příloha č. 9 / Akceptační procedura
Akceptační kritéria pro Dodávku Upgradu pro zahájení Akceptační procedury
Dodání inkrementální verze těch částí Aplikace ve formě proveditelných kódů, kterých se Upgrade týká
Dodání aktuální verze Funkční specifikace a Dokumentace těch částí Aplikace, kterých se Upgrade týká
Úspěšné uskutečnění instalace Upgradu na UAT prostředí podle instalačního postupu, přičemž instalaci provádí zaměstnanec Objednavatele za asistence zaměstnanců Zhotovitele
Akceptační kritéria pro Dodávku Upgrade pro provedení Akceptační procedury
Úspěšné ukončení UAT (realizací všech relevantních testovacích scénářů), přičemž UAT jsou ukončeny jako úspěšné v případě, že dodaný Upgrade obsahuje maximálně následující počty neuzavřených Incidentů:
Incident kategorie TA: 0 (žádný)
incident kategorie TB: 3 (tři)
Incident kategorie TC: 10 (deset)
Úspěšné provedení byznys kritických scénářů v UAT prostředí, přičemž žádný byznys kritický scénář nebude vykazovat Incident kategorie TA, TB nebo TC
Akceptační proceduru Dodávky Upgradu je možné ukončit i v případě, že počet v jednom čase nevyřešených Incidentů z prostředí UAT, které jsou vadami Aplikace nebo Dokumentace, dosáhne nebo překročí následující počty nevyřešených Incidentů:
Incident kategorie TA: 5 (pět)
incident kategorie TB: 10 (deset)
Incident kategorie TC: 30 (třicet)
Akceptační kritéria pro Dodávku Patche
Dodání aktuální verze Funkční specifikace a Dokumentace těch částí Aplikace, kterých se Patch týká, přičemž pokud to je pro vyřešení Incidentu / incidentů účelné, tyto části je možné dodat i v nejbližším Upgradu
Pokud Patch nevyřešil všechny v něm zařazené Incidenty, je na rozhodnutí Objednavatele, zda Akceptační proceduru označí jako úspěšnou
Příloha č. 10. / Vzor Zápisu o odevzdání Dodávky Upgrade k Akceptační proceduře
ZÁPIS O ODEVZDÁNÍ DODÁVKY UPGRADU K AKCEPTAČNÍ PROCEDUŘE
Seznam Částí díla nebo Požadavků na změnu zařazených do dodávky
Název prvku dodávky (Část díla nebo Požadavek na změnu
Číselné označení Požadavku na změnu
Objednatel i Zhotovitel berou na vědomí skutečnost, že podepsáním tohoto Zápisu se zahájí provádění Akceptační procedury.
Příloha č. 11. / Vzor Zápisu o převzetí Dodávky Upgrade do užívání
ZÁPIS O PŘEVZETÍ DODÁVKY UPGRADU DO UŽÍVÁNÍ
Název prvku dodávky (Část díla nebo Požadavek na změnu)
Podpisem tohoto zápisu Objednatel úspěšně ukončuje provádění Akceptační procedury.
Stručný popis vady funkcionality Díla / Nedostatku dokumentace
1.1 Pro účely této Přílohy mají následující výrazy a slovní spojení níže uvedený význam:
Bezpečnostní incident znamená jakékoli narušení důvěrnosti, integrity nebo dostupnosti Informačních aktiv.
Prostředí Oprávněného subjektu znamená prostory, ve kterých Oprávněný subjekt vykonává svou podnikatelskou činnost a informačně-komunikační systémy, které Oprávněný subjekt užívá a které obsahují Informační aktiva.
2.1.1 nemá záznam v rejstříku trestů;
Objednatel je oprávněn požadovat, aby se taková osoba dále nepodílela na realizaci prací vyplývajících z předmětu této Smlouvy a to přímo ani nepřímo a je oprávněn požadovat po Zhotoviteli zajištění adekvátní náhrady.
2.4.1 musí být seznámeni s těmito bezpečnostními pravidly,
3.3 Volný pohyb Osob Zhotovitele v Prostředí Oprávněného subjektu je povolen pouze v případě, že dané osobě byla vystavena osobní přístupová karta.
3.4 V případě ztráty přístupové karty nebo v případě podezření ze ztráty přístupové karty je Zhotovitel povinen bezodkladně informovat Objednatele.
3.5 Bez zbytečného odkladu po ukončení prací vyplývajících z této Smlouvy nebo po ukončení této Smlouvy, nebo pokud již není další fyzický přístup Osob Zhotovitele do Prostředí Oprávněného subjektu potřebný, Objednatel zajistí, že všechny Osoby Zhotovitele vrátí Objednateli zapůjčené přístupové karty.
3.6 Bez předchozího písemného souhlasu Objednatele Osoba Zhotovitele nesmí z Prostředí Oprávněného subjektu prostřednictvím paměťového média odnést žádné Informační aktiva.
Identifikace a autentizace Osob Zhotovitele v Prostředí Oprávněného subjektu
4.2 Běžné pracovní úkony provádí Zhotovitel pod neprivilegovanými účty, účty s administrátorskými oprávněními používá pouze v nezbytných případech.
4.3 Osoby Zhotovitele nesmí přistupovat k internetu, pokud pracují pod účtem s administrátorskými oprávněními anebo s aplikacemi, které jsou pod administrátorskými oprávněními spuštěny.
4.5 Sdílené účty používá Zhotovitel pouze s předchozím písemným souhlasem Objednatele.
6.1 Práce s Informačními aktivy je omezena pouze na místa, které vylučují odpozorování citlivých informací neautorizovanými osobami.
Specificky pak je zakázáno pracovat s Informačními aktivy v prostředcích hromadné dopravy, na veřejných místech a na místech, kde hrozí odpozorování z průmyslových kamer.
6.2 Po ukončení prací vyplývajících z této Smlouvy Zhotovitel bez zbytečného prodlení vrátí anebo odstraní veškerá Informační aktiva uložená v prostředí Zhotovitele, pakliže držení těchto informací není vyžadováno zákony České republiky.
Odstranění Informačních aktiv musí být provedeno způsobem, který znemožňuje jejich opětovné obnovení.
6.3 Bez předchozího písemného souhlasu Objednatele nesmí Zhotovitel poskytnout přístup k Informačním aktivům žádným třetím stranám, které nejsou oprávněné podílet se na plnění této Smlouvy.
6.4 Zhotovitel je povinen zajistit adekvátní zabezpečení výpočetní techniky, na které jsou uloženy, zpracovávány nebo přes které jsou přenášeny Informační aktiva.
6.4.1 jsou používány nástroje pro šifrování disků, složek anebo souborů, tak aby byl vyloučen neautorizovaný přistoupit k Informačním aktivům,
6.4.4 je prostředí internetu odděleno firewallem, který je připojen k dohledu a Osoby Zhotovitele při vzdáleném přístupu využívají výhradně šifrovaného VPN připojení zamezující neautorizovaný odposlech a změnu přenášené komunikace.
6.5 Jsou-li Informační aktiva přenášena Zhotovitelem mimo prostory Oprávněného subjektu, je Zhotovitel povinen důsledně dbát na fyzickou bezpečnost těchto aktiv a mít tato Informační aktiva stále pod dohledem.
Zhotovitel je povinen dodržovat bezpečnostní a provozní pokyny výrobce hardwaru, na kterém jsou Informační aktiva zpracovávána.
7.1 Zhotovitel je povinen seznámit se a jednat v souladu se standardem klasifikace Informačních aktiv, pokud mu ho Objednatel poskytne.
7.5 Zhotovitel nesmí žádným způsobem manipulovat s auditními záznamy.
7.10 Na poskytnutém pracovním místě jsou Osoby Zhotovitele po čas fyzické nepřítomnosti povinny zajistit:
7.10.2 adekvátní fyzickou bezpečnost veškerých Informačních aktiv;
7.10.3 logické uzamčení přístupu k Informačním aktivům tak, aby nemohlo dojít k neautorizovanému přístupu k těmto Informačním aktivům.
7.11 Osoby Zhotovitele nejsou bez předchozího písemného souhlasu Objednatele oprávněni instalovat zařízení umožňující vzdálený odposlech anebo pořizovat jakýkoliv audio anebo video záznam.
8.3 V případě krizového řízení je Osoba Zhotovitele povinna bezodkladně uposlechnout pokynů krizového manažera Objednatele.
Příloha 13 / Obsah smlouvy o dílo
Výrazy začínající velkými písmeny / Všechna slova a slovní spojení, která začínají velkými písmeny, jejichž význam neurčuje tato smlouva o dílo (dále jen „Smlouva“), mají význam jako ve smlouvě, o poskytování služeb podpory provozu a rozvoje informačního systému - Service level agreement, jejímž předmětem je údržba a rozvoj Aplikace (dále jen „SLA“).
Předmět smlouvy / Za podmínek této Smlouvy, za úplatu, na vlastní náklady a nebezpečí, Zhotovitel provede pro Objednatele dílo, jehož přesný popis je uveden ve Změnové dokumentaci (dále jen „Dílo“).
Termín provedení Díla / Dílo provede Zhotovitel do termínu, který je uveden ve Změnové dokumentaci.
Cena / Za řádně zhotovené Dílo Objednatel zaplatí Zhotoviteli Cenu, která je uvedena ve Změnové dokumentaci (dále jen „Cena“).
Ostatní náklady na zhotovení Díla / Cena zahrnuje veškeré náklady, které Zhotoviteli vzniknou v souvislosti se zhotovením Díla.
Cena zahrnuje také výdaje na plnění třetích stran, které Zhotovitel použil při zhotovování Díla, zejména náklady na plnění subdodavatelů, a to včetně autorů a jiných externích poskytovatelů licencí atd.
Na akceptaci Díla se v souladu s SLA použije Akceptační procedura.
Vady Díla / Dílo má vadu, pokud nemá vlastnosti určené touto Smlouvou a Změnovou dokumentaci.