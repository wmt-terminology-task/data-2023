Statické a kontextové vícejazyčné embeddingy mají komplementární přednosti.
Statické embeddingy, i když jsou méně expresivní než kontextové jazykové modely, se dají lépe párovat mezi jazyky.
V tomto článku kombinujeme přednosti statických a kontextových, čímž docílíme vyšší kvality vícejazyčných kontextových embedingů.
Z modelu XLM-R extrahujeme statické embeddingy pro 40 jazyků, validujeme jejich kvalitu pomocí indukce dvojjazyčných slovníků a pak je zarovnáváme pomocí nástroje VecMap.
Výsledkem jsou vysoce kvalitní, vysoce vícejazyčné statické embeddingy.
Poté aplikujeme nový přístup pokračujícího pre-training modelu XLM-R, kde využíváme tyto statické embeddingy pro lepší zarovnání reprezentačního prostoru XLM-R. Náš postup dosazuje pozitivních výsledků pro sémanticky náročných úloh.
Statické embeddingy a kód pokračujícího pre-training jsou veřejně dostupné.
Na rozdíl od většiny předchozí práce náš přístup pokračujícího pre-training nevyžaduje paralelní text.
Technické termíny mohou vyžadovat zvláštní zacházení, pokud je cílová skupina dvojjazyčná, v závislosti na kulturních a vzdělávacích normách dané společnosti.
Zejména některé překladové situace mohou vyžadovat „zachování termínů“, tj.
ponechání technických termínů zdrojového jazyka v cílovém jazyce výstupu, aby vznikla plynulá a srozumitelná věta.
Ukazujeme, že standardní model strojového překladu založený na Transformeru lze snadno přizpůsobit k dosažení tohoto cíle, aniž by přitom trpěla kvalita jeho výstupu obecně.
Představujeme anglicko-hindský model, který je natrénovat k uposlechnutí signálu „zachování“, tj.
za běhu zajistí, že vybrané termíny nebudou přeloženy.
Navrženou metodu vyhodnocujeme automatickými metrikami (BLEU pro překlad obecně, F1 pro zachování termínů), i ručně (celková kvalita výstupních vět).
CorefUD je kolekce existujících korpusů s anotací koreference, které jsme převedli na jednotné anotační schéma.
Ve své současné verzi 1.0 CorefUD celkem obsahuje 17 korpusů pro 11 jazyků a v porovnání s verzí 0.2 obsahuje přepracovaný formát souborů a opravy řady chyb.
Předkládáme přehled o stavu výzkumu v oblasti strojového překladu s nízkými zdroji.
V současnosti se na světě mluví asi 7 000 jazyky a téměř všem jazykovým párům chybí významné zdroje pro trénování modelů strojového překladu.
Vzrůstá zájem o výzkum zabývající se problémem vytváření užitečných překladatelských modelů, když je k dispozici velmi málo přeložených trénovacích dat.
Předkládáme shrnutí této aktuální oblasti na vysoké úrovni a poskytujeme přehled osvědčených postupů.
V této kapitole uvádíme hlavní úspěchy české velké výzkumné infrastruktury LINDAT/CLARIAH-CZ.
Poskytujeme krátký popis infrastruktury a její historii a stručný popis jejího vědeckého, technologického a infrastrukturního rozsahu.
Zaměřujeme se na technologické inovace již implementované v úložišti a v nabídkách služeb a nastiňujeme některé budoucí plány.
Náš článek se zaměřuje na vývoj vícejazyčného zdroje dat pro morfologickou segmentaci.
Představujeme přehled 17 existujících datových zdrojů relevantních pro segmentaci ve 32 jazycích a analyzujeme rozmanitost způsobů, jakými jsou v nich jednotlivé jazykové jevy zachyceny.
Nechali jsme se inspirovat úspěchem Universal Dependencies a navrhujeme harmonizované schéma pro reprezentaci segmentaci a převádíme data z těchto zdrojů do jednotného schématu.
Harmonizované verze zdrojů dostupné pod bezplatnými licencemi jsou publikovány jako kolekce s názvem UniSegments 1.0.
Tento článek představuje přehled výsledků soutěže (společné úlohy) ve vícejazyčné automatické analýze koreference, která byla přidružená k workshopu CRAC 2022.
Účastníci soutěže měli vyvinout trénovatelné systémy schopné identifikovat zmínky o entitách a shlukovat tyto zmínky na základě identické koreference.
Jako zdroj trénovacích a vyhodnocovacích dat byla použita veřejná část CorefUD 1.0, která obsahuje 13 korpusů pro 10 jazyků.
Jako hlavní vyhodnocovací metrika bylo použito skóre CoNLL, které se používalo v dřívějších soutěžích zaměřených na koreferenci.
5 účastnických týmů vyvinulo celkem 8 systémů na predikci koreference; kromě toho jsou k dispozici výsledky baseline systému, který je založen na transformerech a byl poskytnut organizátory na začátku soutěže.
Vítězný systém překonal baseline o 12 procentních bodů (průměr CoNLL skóre přes korpusy jednotlivých jazyků).
Cílem této kapitoly je ukázat, že dobře navržená a teoreticky podložená korpusová anotace významně přispívá k využití korpusu pro testování lingvistické teorie a pro její další rozvoj.
Data našich analýz pocházejí z korpusové rodiny Prague Dependency Treebank; jde o  jednojazyčná česká data a o paralelní anglicko-česká data, která  se týkají základní syntaktické úrovně popisu jazyka a anotace struktury diskurzu.
Konkrétní případové studie se týkají tří výzkumných otázek, a to (i) sémantické relevance informační struktury věty, (ii) vztahu mezi fokalizátory a diskurzními konektory vzhledem k sémantice diskurzních vztahů a (iii) vztahu mezi primárními a sekundárními spojovacími výrazy.
V příloze jsou uvedeny a rozebrány údaje o měření mezianotátorské shody.
V poslední době bylo vyvinuto mnoho korpusů, které obsahují více anotací různých jazykových jevů, od morfologických kategorií slov přes syntaktickou stavbu vět až po diskurz a koreferenční vztahy v textech.
Probíhají diskuse o vhodném anotačním schématu pro velké množství různorodých informací.
V našem příspěvku vyjadřujeme přesvědčení, že vícevrstvé anotační schéma nabízí pohled na jazykový systém v jeho komplexnosti a v interakci jednotlivých jevů a že existují minimálně dva aspekty, které vícevrstvé anotační schéma podporují: (i) Vícevrstvé anotační schéma umožňuje použít anotaci jedné vrstvy k návrhu anotace další vrstvy (vrstev) jak koncepčně, tak ve formě předanotačního postupu nebo pravidel kontroly anotace.
(ii) Vícevrstvé anotační schéma představuje spolehlivý základ pro korpusové studie založené na vlastnostech napříč vrstvami.
Tyto aspekty jsou demonstrovány na případu Pražského závislostního korpusu.
Jeho více-rovinné anotační schéma obstálo ve zkoušce času a dobře poslouží i pro složité textové anotace, ve kterých se s výhodou používají dřívější morfosyntaktické anotace.
Kromě odkazu na předchozí projekty, které využívají toto anotační schéma, uvádíme několik aktuálních výzkumů.
SynSemClass lexicon 4.0 zkoumá s ohledem na kontextově založenou slovesnou synonymii, sémantickou „ekvivalenci“ českých, anglických a německých sloves a jejich valenční chování v paralelních česko-anglických a německo-anglických jazykových zdrojích.
SynSemClass 4.0 je vícejazyčná ontologie typu události založená na třídách synonymních významů sloves, doplněná sémantickými rolemi a odkazy na existující sémantické lexikony.
Slovník je nejen obohacen o další množství tříd, ale v rámci hierarchizace obsahu byly některé třídy sloučeny.
V porovnání se starou verzí obsahuje slovník nově  definice tříd a definice rolí.
Kromě již použitých odkazů na položky PDT-Vallex, EngVallex, CzEngVallex, FrameNet, VerbNet, PropBank, Ontonotes a English WordNet pro české a anglické záznamy jsou nové odkazy na německé jazykové lexikální zdroje, jako je Woxikon, E-VALBU a GUP, využívány pro německé slovesné záznamy.
Německá část lexikonu byla vytvořena v rámci projektu Multilingual Event-Type-Anchored Ontology for Natural Language Understanding (META-O-NLU) dvěma spolupracujícími týmy - týmem Univerzity Karlovy, Matematicko-fyzikální fakulty, Ústavu formální a aplikované lingvistiky, Praha (ÚFAL), Česká republika a týmem Německého výzkumného centra pro umělou inteligenci (DFKI) Speech and Language Technology, Berlín, Německo.
Představujeme rozšíření ontologie typu události SynSemClass, původně koncipované jako dvojjazyčný česko-anglický zdroj.
Do tříd představujících koncepty ontologie jsme přidali německé záznamy.
Vzhledem k tomu, že jsme měli jiný výchozí bod než původní práce (neoznačený paralelní korpus bez odkazů na valenční lexikon a samozřejmě různé existující lexikální zdroje), bylo náročné přizpůsobit pokyny pro anotaci, datový model a nástroje použité pro původní verzi.
Popisujeme proces a výsledky práce v takovém nastavení.
Dále ukazujeme další kroky k úpravě procesu anotace, datové struktury a formáty a nástroje nezbytné k tomu, aby přidání nového jazyka v budoucnu bylo plynulejší a efektivnější a případně aby různé týmy mohly pracovat na rozšíření SynSemClass do mnoha jazyků současně.
představujeme nejnovější verzi, která obsahuje výsledky přidání němčiny, volně dostupné ke stažení i pro online přístup.
Představujeme NomVallex, ručně anotovaný valenční slovník českých substantiv a adjektiv.
Slovník je vytvořený v teoretickém rámci Funkčního generativního popisu a je založený na korpusových datech.
Obsahuje celkem 1027 lexikálních jednotek v celkovém počtu 570 lexémů, přičemž zahrnuje následující slovnědruhové a derivační kategorie: deverbální a deadjektivní substantiva, a deverbální, desubstantivní, deadjektivní a primární adjektiva.
Valenční vlastnosti lexikálních jednotek zachycuje v podobě valenčního rámce, který pro každé valenční doplnění uvádí funktor a množinu možných morfematických vyjádření, a dokládá je pomocí příkladů, které se vyskytly v použitých korpusech.
NomVallex je koncipován jako lexikografický zdroj umožňující výzkum valence derivačně příbuzných lexikálních jednotek, proto v relevantních případech poskytuje odkaz od určité lexikální jednotky k odpovídající lexikální jednotce jejího základového slova, obsaženého buď v NomVallexu, nebo – v případě sloves – ve slovníku VALLEX, čímž propojuje až tři slovní druhy, konkrétně substantivum – sloveso, adjektivum – sloveso, substantivum – adjektivum nebo substantivum – adjektivum – sloveso.
NomVallex umožňuje srovnání valenčního chování velkého počtu českých substantiv a adjektiv s valencí jejich základových slov, což je jeden z předpokladů ke zkoumání teoretické otázky dědičnosti valence a k popisu systémového a nesystémového valenčního chování.
Universal Dependencies je mezinárodní komunitní projekt a sbírka morfosyntakticky anotovaných dat (treebanků) pro více než 100 jazyků.
Tato sbírka je neocenitelným zdrojem pro různé jazykovědné studie od gramatických konstrukcí v jednom jazyku po jazykovou typologii, dokumentaci ohrožených jazyků a historického vývoje jazyka.
V tomto tutoriálu nejdříve rychle představím hlavní principy UD, potom ukážu vlastní data a různé nástroje, které jsou k dispozici pro práci s nimi: parsery, dávkové procesory, vyhledávače a prohlížeče.
Tato práce se zaměřuje na detekci zdrojů v českých článcích publikovaných na zpravodajském serveru Českého veřejnoprávního rozhlasu.
Hledáme zejména přiřazení ve větách a rozeznáváme přiřazené zdroje a jejich větný kontext(signály).
Zorganizovali jsme crowdsourcingovou anotační úlohu, jejímž výsledkem byl datový soubor 2 167 článků s ručně rozpoznanými signály a zdroji.
Zdroje byly navíc zařazeny do kategorií jmenovaných a nejmenovaných zdrojů.
Vstupní data, jednotlivé experimentální anotace a úplný a podrobný přehled naměřených výsledků souvisejících s experimentem zabývajícím se vlivem automatické před-anotace na kvalitu a efektivitu anotačního úsilí.
Tento článek představuje analýzu anotace pomocí automatické před-anotace pro úkol anotace závislostní syntaxe.
Porovnává úsilí anotátorů, kteří používají před-anotovanou verzi (s vysoce přesným parserem), a úsilí vytvořené plně ruční anotací.
Cílem experimentu je posoudit výslednou kvalitu anotace při použití před-anotace.
Kromě toho hodnotí vliv automatických lingvisticky založených (pravidlově formulovaných) kontrol a jiné anotace na stejných datech, kterou mají anotátoři k dispozici, a jejich vliv na kvalitu a efektivitu anotace.
Experiment potvrdil, že pre-anotace je účinným nástrojem pro rychlejší manuální syntaktickou anotaci, která zvyšuje konzistenci výsledné anotace bez snížení její kvality.
Studie se zabývá českými konverzními dvojicemi, v nichž podstatné jméno i sloveso mají dějový význam (test 'zkoušet.n' - testovat 'zkoušet').
V návaznosti na předchozí výzkum prototypických případů deverbální a denominální konverze v češtině je směr v těchto dvojicích určován na základě toho, zda sloveso tvoří svůj vidový protějšek změnou kmenotvorné přípony (což je charakteristické pro deverbální směr), nebo zda sufixální protějšek není k dispozici (typické pro denominální slovesa).
Analýza provedená na korpusovém vzorku 1 300 podstatných jmen s dějovým významem a přímo souvisejících sloves ukazuje, že dvojice založené na domácích kořenech mají většinou rysy deverbálního tvoření, zatímco denominální směr se uplatňuje v menší skupině domácích dvojic a v datech s cizími kořeny jasně převažuje.
Denominální směr přisuzovaný dvojicím s cizími kořeny je v souladu s typologickou hypotézou, že slovesa jsou přejímána do češtiny spíše jako podstatná jména a následně se v cílovém jazyce mění na slovesa.
Studie se zabývá anglickými konverzními dvojicemi podstatných a sloves, které mají formálně i významově blízké protějšky v češtině.
Cílem studie je prozkoumat, jak se tato substantiva a slovesa, která jsou v angličtině a češtině spojena podobnými sémantickými vztahy, chovají v jazycích, které mají odlišnou morfologickou strukturu a v jejichž slovotvorných systémech hraje konverze odlišnou roli.
Dvojice substantiv a sloves, extrahované z Britského národního korpusu a z korpusu SYN2000, jsou popisována jako dvoučlenná paradigmata a zkoumány spolu s vybranými deriváty.
Data ukazují, že v českých dvojicích jsou pro vyjadřování konkrétních významů preferována substantiva před slovesy a většina sloves je používána jako denominální formace, často odlišně od anglických protějšků.
Tato práce představuje korpus ParlaMint obsahující přepisy ze zasedání 17 evropských národních parlamentů s půl miliardou slov.
Korpusy jsou jednotně kódovány, obsahují bohatá metadata o 11 tisících mluvčích a jsou lingvisticky anotovány podle Universal Dependencies a s pojmenovanými entitami.
Vzorky korpusů a konverzních skriptů jsou k dispozici v úložišti projektu na GitHub a kompletní korpusy jsou otevřeně k dispozici prostřednictvím úložiště CLARIN.SI ke stažení, stejně jako prostřednictvím NoSketch Engine a KonText a rozhraní Parlameter pro on-line průzkum a analýzu.
Tento článek je zasazen do kontextu projektu SSHOC a jeho cílem je prozkoumat, jak mohou jazykové technologie pomoci při podpoře a usnadnění vícejazyčnosti v sociálních a humanitních vědách (SSH).
Přestože většina výzkumných pracovníků v oblasti SSH vytváří kulturně a společensky relevantní práce ve svých místních jazycích, metadata a slovníky používané v oblasti SSH k popisu a indexování výzkumných dat jsou v současné době většinou v angličtině.
Zkoumáme proto přístupy zpracování přirozeného jazyka a strojového překladu s cílem poskytnout zdroje a nástroje na podporu vícejazyčného přístupu k obsahu SSH a jeho vyhledávání v různých jazycích.
Jako případové studie vytváříme a poskytujeme jako volně dostupná data soubor vícejazyčných metadatových konceptů a automaticky extrahovanou vícejazyčnou terminologii Data Stewardship.
Tyto dvě případové studie umožňují také vyhodnotit výkonnost nejmodernějších nástrojů a odvodit soubor doporučení, jak je nejlépe použít.
Přestože nejsou přizpůsobeny konkrétní doméně, použité nástroje se ukázaly být platným přínosem pro překladatelské úlohy.
Nicméně ověření výsledků experty na danou doménu, kteří ovládají daný jazyk, je nevyhnutelnou fází celého pracovního postupu.
Prezentace jazykových nástrojů systému Elitr a generování scénářů THEaiTRE pro účastníky EUROSAI kongresu.
Hackování jazykového modelu GPT-2 Sestavení webové aplikace Vytváří se scénář divadelní hry Představení hry na jevišti Demo nástroje
Prezentace interaktivního generování scénářů divadelních her pro zaměstnance společnosti Novartis.
Experimentujeme s adaptací generativních jazykových modelů pro generování dlouhých souvislých vyprávění v podobě divadelních her.
Protože plně automatické generování celých her není v současné době proveditelné, vytvořili jsme interaktivní nástroj, který umožňuje lidskému uživateli poněkud nasměrovat generování a zároveň minimalizovat zásahy.
Pro generování dlouhých textů sledujeme dva přístupy: ploché generování se sumarizací kontextu a hierarchický dvoufázový přístup text-to-text, kdy je nejprve vygenerována synopse a poté použita k podmiňování generování konečného scénáře.
Naše předběžné výsledky a diskuse s divadelními profesionály ukazují zlepšení oproti základnímu generování, ale také identifikují důležitá omezení našeho přístupu.
Představujeme volně dostupné online demo THEaiTRobot, dvojjazyčný nástroj s otevřeným zdrojovým kódem pro interaktivní generování scénářů divadelních her, ve dvou verzích.
THEaiTRobot 1.0 používá jazykový model GPT-2 s minimálními úpravami.
THEaiTRobot 2.0 používá dva modely vytvořené doladěním GPT-2 na cíleně shromážděných a zpracovaných datových souborech a několika dalších komponentách, které hierarchicky generují scénáře divadelních her (název → synopse → skript).
Podkladový nástroj se používá v projektu THEaiTRE pro generování scénářů divadelních her, které pak na jevišti hraje profesionální divadlo.
Představujeme velký a různorodý český korpus pro opravu gramatických chyb s cílem přispět ke stále nedostatkovým datovým zdrojům v této doméně pro jiné jazyky než angličtinu.
Korpus pro gramatickou opravu chyb pro češtinu (GECCC) nabízí čtyři domény, které pokrývají distribuci chyb od esejů s vysokou hustotou chyb napsaných nerodilými mluvčími až po texty webových stránek, kde jsou chyby mnohem méně časté.
Porovnáváme několik českých GEC systémů, včetně několika na bázi architektury Transformer, a nastavujeme tak silnou baseline pro budoucí výzkum.
V neposlední řadě také provádíme meta-evaluaci běžných GEC metrik pomocí ručního hodnocení na našich datech.
Nový český GEC korpus zveřejňujeme pod licencí CC BY-SA 4.0 na adrese http://hdl.handle.net/11234/1-4639.
V ParlaMint I, projektu podporovaném CLARIN-ERIC v době pandemie, byla v roce 2021 vyvinuta a vydána sada srovnatelných a jednotně anotovaných vícejazyčných korpusů pro 17 národních parlamentů.
Pro roky 2022 a 2023 byl projekt rozšířen na ParlaMint II, opět s finanční podporou CLARIN-ERIC, s cílem rozšířit stávající korpusy o nová data a metadata; aktualizovat schéma XML; přidat korpusy pro 10 nových parlamentů; poskytnout více scénářů aplikace a provést další experimenty.
Dokument informuje o těchto plánovaných krocích, včetně některých, které již byly podniknuty, a nastiňuje budoucí plány.
Ve většině modelů kombinujících jazyk a vizuální informaci (Vision-Language, VL) je porozumění struktuře obrazu umožněno přidáním informací o poloze objektů v obraze.
V naší případové studii se věmnujeme modelu VL modelu LXMERT a zkoumáme použití jakým způsobem poziční informaci používá a studujeme její vliv na úspěšnost v úloze odpovídání otázek o obrázcích.
Ukazujeme, že model není schopen poziční informaci využít pro přiřazování textů k obrázkům, pokud se texty liší polohou objektů.
A to i přesto, že další experimenty ale ukazují, že PI je v modelech skutečně přítomna.
Představujeme dvě strategie, jak se s tímto problémem vypořádat: (i) předtrénování s přidanou informací o poloze a (ii) kontrastní učení s porovnáváním napříč modalitami.
Tímto způsobem může model správně klasifikovat, zda se obrázky s podrobnými výroky PI shodují.
Kromě 2D informací o objektech na obrázku, přidáváme hloubku objektu pro lepší lokalizaci v prostoru.
Přestože se nám podařilo zlepšit vlastnosti modelu, na kvalitu odpovídání otázek to má jen zanedbatelný vliv.
Naše výsledky tak poukazují na důležitý problém multimodálního modelování: pouhá přítomnost informace detekovatelné klasifikátorem není zárukou, že tato informace je k dispozici napříč modalitami.
V tomto článku popisujeme naše předložení k Simultaneous Speech Translation na IWSLT 2022.
Zkoumáme strategie využití offline modelu v simultánním prostředí bez nutnosti upravovat původní model.
V našich experimentech ukazujeme, že náš online algoritmus je téměř na stejné úrovni jako offline nastavení, přičemž je 3× rychlejší než offline, pokud jde o latenci na testovací sadě.
Náš systém zpřístupňujeme veřejnosti.
Sumarizace schůzek se primárně zaměřuje spíše na aktuální téma než na plynulost nebo koherenci.
Je to náročný a zdlouhavý úkol, i když se shrnutí schůzek vytváří ručně.
Výsledná shrnutí se liší v cílech, stylu a jsou nevyhnutelně velmi subjektivní kvůli člověku, který je ve smyčce.
Pro vytvoření adekvátních a informativních shrnutí je rovněž nezbytné uvědomění si kontextu schůzky.
Práce se zabývá paradigmatickým systémem české flexe z perspektivy distribuční sémantiky.
Využíváme rozsáhlé morfologické zdroje a korpusy k získání modelů distribuční sémantiky češtiny a zkoumáme chování vybraných morfosémantických vlastností českých podstatných a přídavných jmen.
Prezentace shrnuje dosavadní práci našeho grantového týmu START na tématu kompetice ve slovotvorbě.
Prezentují se jak jazykové zdroje, tak metodologie používané v rámci dané výzkumné oblasti.
Práce se zabývá hranicí mezi flektivní a derivační morfologií v češtině, zvláště pak z perspektivy distribuční sémantiky.
Využíváme rozsáhlé morfologické zdroje a korpusy k získání modelů distribuční sémantiky češtiny a zkoumáme kolekci 24 typů morfologických kontrastů reprezentujících jak kanonickou flexi a kanonickou derivaci, tak různé typy mezních případů.
Představujeme soubor dat Eyetracked Multi-Modal Translation (EMMT), který obsahuje záznamy monokulárních očních pohybů, zvuková data a data 4elektrodového nositelného elektroencefalogramu (EEG) 43 účastníků, kteří se věnovali překladu z angličtiny do češtiny, a to na základě psaného textu a doprovodných obrázků.
Data sledování očí jsou velmi užitečným zdrojem informací pro studium kognice a zejména porozumění jazyku u lidí.
V tomto článku popisujeme naše systémy pro sdílenou úlohu CMCL 2022 o předpovídání informací o sledování očí.
Popisujeme naše experimenty s předem připravenými modely, jako jsou BERT a XLM, a různé způsoby, jak jsme tyto reprezentace použili k predikci čtyř funkcí sledování očí.
Spolu s analýzou účinku použití dvou různých druhů předtrénovaných vícejazyčných jazykových modelů a různých způsobů sdružování reprezentací na úrovni tokenů také zkoumáme, jak kontextové informace ovlivňují výkon systémů.
Nakonec také zkoumáme, zda faktory, jako je rozšíření jazykových informací, ovlivňují předpovědi.
Naše příspěvky dosáhly průměrného MAE 5,72 a umístily se na 5. místě ve sdíleném úkolu.
Průměrný MAE ukázal další snížení na 5,25 při hodnocení po úkolu.
Ve hře Shannon je cílem uhodnout další písmeno ve větě na základě předchozího kontextu.
Od té doby se stal široce známým myšlenkovým experimentem, na kterém jsou založeny koncepty v psycholingvistice, počítačové lingvistice a zpracování přirozeného jazyka.
Tuto hru rozšiřujeme o volitelnou extra modalitu ve formě obrázků a provádíme experiment na lidských účastnících.
Zjistili jsme, že přítomnost obrázku výrazně zvyšuje důvěru a přesnost uživatelů ve všech POS.
To zahrnuje determinanty (a, an, the), které by jinak měly být predikovány výhradně z předchozího (levého) kontextu věty.
Není jasné, zda, jak a kde velké předem trénované jazykové modely zachycují jemné lingvistické rysy, jako je nejednoznačnost, gramatika a složitost vět.
Prezentujeme výsledky automatické klasifikace těchto znaků a porovnáváme jejich životaschopnost a vzorce napříč typy reprezentace.
Ukazujeme, že datové sady založené na šablonách s artefakty na úrovni povrchu by neměly být používány pro sondování, měla by být provedena pečlivá srovnání se základními hodnotami a že grafy t-SNE by se neměly používat k určení přítomnosti rysu mezi reprezentacemi hustých vektorů.
Také ukazujeme, jak mohou být prvky vysoce lokalizovány ve vrstvách těchto modelů a ztratit se v horních vrstvách.
Při trénování systémů pro generování textu z dat na konkrétní doméně dochází k nadměrnému přizpůsobování modelů reprezentaci dat a opakování chyb v trénovacích datech na výstupu.
Zkoumáme, jak se obejít bez dotrénovávání jazykových modelů na datasetech pro tuto úlohu a zároveň přitom využít schopností těchto modelů pro povrchovou realizaci.
Inspirováni sekvenčními přístupy navrhujeme generovat text transformací krátkých textů pro jednotlivé položky pomocí posloupnosti modulů natrénovaných na obecných textových operacích: řazení, agregaci a kompresi odstavců.
Modely pro provádění těchto operací trénujeme na syntetickém korpusu WikiFluent, který pro tento účel vytváříme z anglické Wikipedie.
Naše experimenty na dvou významných datasetech pro převod RDF trojic na text — WebNLG a E2E — ukazují, že náš přístup umožňuje generování textu z RDF trojic i při absenci trénovacích dat.
Efektivní modely strojového překladu jsou komerčně důležité, protože mohou zvýšit rychlost překladu a snížit náklady a emise uhlíku.
V poslední době je velký zájem o neautoregresivní (NAR) modely, které slibují rychlejší překlad.
Paralelně s výzkumem modelů NAR proběhly úspěšné pokusy o vytvoření optimalizovaných autoregresních modelů v rámci sdíleného úkolu WMT o efektivním překladu.
V tomto článku poukazujeme na nedostatky v metodice hodnocení v literatuře o modelech NAR a poskytujeme spravedlivé srovnání mezi nejmodernějším modelem NAR a autoregresivními příspěvky ke sdílenému úkolu.
Zastáváme důsledné hodnocení modelů NAR a také důležitost porovnávání modelů NAR s jinými široce používanými metodami pro zlepšení efektivity.
Provádíme experimenty s modelem NAR založeným na konekcionisticko-temporální klasifikaci (CTC) implementovaným v C++ a porovnáváme jejich čas s autoregresivními modely AR.
Naše výsledky ukazují, že ačkoli jsou modely NAR rychlejší na GPU, s malými velikostmi dávek, jsou téměř vždy pomalejší za reálnějších podmínek použití.
V budoucí práci požadujeme realističtější a rozsáhlejší hodnocení modelů NAR.
Úspěch hlubokého učení NLP je často popisován tak, že o jazyku nic nepředpokládáme a necháváme data mluvit sama za sebe.
Ačkoli je to na mnoha úrovních diskutabilní, jedna věc je neobyčejně podezřelá: většina nejmodernějších NLP modelů předpokládá existenci diskrétních tokenů a používá segmentaci na podslova, která kombinuje pravidla s jednoduchými statistickými heuristikami.
Vyhnout se explicitní segmentaci vstupu je obtížnější, než se zdá.
První část přednášky představí neurální neuronovou editační vzdálenost, novou interpretovatelnou architekturu založenou na dobře známé Levenshteinově vzdálenosti, kterou lze použít pro čistě znakové úlohy, jako je transliterace nebo detekce kognátů.
Ve druhé části přednášky si přiblížíme neuronový strojový překlad na úrovni znaků.
Představíme, jak inovace v oblasti trénování a návrhu architektur mohou zlepšit kvalitu překladu.
I přes tento pokrok se ukazuje, že metody na úrovni znaků ve strojovém překladu stále zaostávají za modely na bázi podslov téměř ve všech ohledech, které lze měřit.
Navrhujeme model neuronová editační vzdálenost pro párování řetězců a převod řetězců na základě naučené editační vzdálenosti.
Upravili jsme původní MT algoritmus tak, aby využíval diferencovalnou ztrátovou funkci, což nám umožňuje integrovat ji do neuronové sítě poskytující kontextovou reprezentaci vstupu.
Hodnotíme detekci kognatů, transliteraci a konverzi grafémů na fonémy a ukazujeme, že v jednom teoretickém rámci připravovat modely, kde jde proti sobě intepretovatelnost a přesnost.
Pomocí kontextových reprezentací, které jsou ale hůře interpretovatelné, dosahuje stejné přesnosti jako nejlepší metody pro párování řetězců.
Pomocí statických embedingů a mírně odlišné ztrátové funkce dokážeme vynutit interpretabilitu na úkor poklesu přesnosti.
V článku prezentuje přehled literatury a empirický průzkum, který kriticky hodnotí předchozí práci v oblasti strojového překladu na úrovni znaků.
Navzdory tvrzením v literatuře, že systémy na úrovni znaků jsou srovnatelné se systémy, které pracují na úrovni podslov, prakticky nikdy se nepoužívají v soutěžních systémech WMT.
Empiricky ukazujeme, že i s nedávnými inovacemi v modelování zpracování přirozeného jazyka na úrovni znaků se systémy strojového překladu na úrovni znaků stále obtížně vyrovnávají svým protějškům na bázi podslov.
Strojový překlad na úrovni znaků nevykazuje ani lepší doménovou robustnost, ani lepší morfologické zobecnění, přestože to bývá často hlavní motivace pro jejich vývoj.
Systémy zpracovávající vstup po znacích naopak vykazují velkou robustnost vůči šumu a že kvalita překladu neklesá ani s klesající mírou ořezávání během dekódování.
Nalezení rodokmenu výzkumného tématu je klíčové pro pochopení předchozího stavu umění a postupujícího vědeckého posunu.
Záplava odborných článků ztěžuje nalezení nejvhodnější předchozí práce.
Výzkumníci tak tráví značné množství času sestavováním seznamu literatury.
Citace hrají zásadní roli při objevování relevantní literatury.
Nicméně ne všechny citace jsou vytvořeny stejně.
Většina citací, které noviny obdrží, poskytuje podkladové a kontextové informace citujícím dokumentům.
V těchto případech není citovaný dokument ústředním tématem citujících listin.
Některé dokumenty však vycházejí z daného papíru, čímž se dále posouvá hranice výzkumu.
V těchto případech hraje dotčený citovaný dokument v citujícím dokumentu stěžejní roli.
Podstata citace, kterou prvně jmenovaný obdrží od druhého, je tedy významná.
V této práci probíráme naše výzkumy směřující k objevení významných citací daného dokumentu.
Dále ukazujeme, jak můžeme využít významné citace k sestavení výzkumné linie prostřednictvím významného citačního grafu.
Účinnost naší myšlenky demonstrujeme dvěma případovými studiemi v reálném životě.
Naše experimenty přinášejí slibné výsledky, pokud jde o současný stav klasifikace významných citací, předčí ty předchozí s relativním náskokem 20 bodů, pokud jde o přesnost.
Předpokládáme, že takový automatizovaný systém může usnadnit vyhledávání příslušné literatury a pomoci identifikovat tok znalostí pro určitou kategorii papírů.
Nalezení rodokmenu výzkumného tématu je klíčové pro pochopení předchozího stavu umění a postupujícího vědeckého posunu.
Záplava odborných článků ztěžuje vyhledávání nejvýznamnějších předchozích prací a způsobuje, že výzkumníci tráví značné množství času sestavováním seznamu literatury.
Citace hrají významnou roli při objevování relevantní literatury.
Nicméně ne všechny citace jsou vytvořeny stejně.
Většina citací, které redakce obdrží, slouží k poskytování kontextuálních a podkladových informací citujícím listinám a nejsou ústředním tématem těchto listin.
Některé práce jsou však pro citující noviny stěžejní a inspirují nebo brzdí výzkum v citujících novinách.
Z toho vyplývá, že podstata citace, kterou prvně jmenovaný obdrží od druhého, je významná.
V tomto rozpracovaném dokumentu diskutujeme o naší předběžné myšlence vytvořit rodokmen pro daný výzkum prostřednictvím identifikace významných citací.
Předpokládáme, že takový automatizovaný systém může usnadnit vyhledávání příslušné literatury a pomoci identifikovat tok znalostí alespoň pro určitou kategorii papírů.
Distálním cílem této práce je zjistit skutečný dopad výzkumné práce nebo zařízení mimo přímá citační čísla.
Speciální zasedání SummDial o sumarizaci dialogů a setkání více stran se konalo prakticky v rámci konference SIGDial 2021 dne 29. července 2021.
SummDial @ SIGDial 2021 si kladl za cíl spojit komunity zabývající se řečí, dialogem a sumarizací, aby se podpořilo vzájemné opylování myšlenek a podpořily diskuse/spolupráce při pokusu o tento zásadní a aktuální problém.
Když pandemie omezila většinu našich osobních interakcí, současný scénář donutil lidi přejít na virtuální, což vyústilo v zahlcení informacemi z častých dialogů a setkání ve virtuálním prostředí.
Shrnutí by mohlo pomoci snížit kognitivní zátěž účastníků, nicméně sumarizace projevů více stran přináší vlastní soubor výzev.
Speciální zasedání SummDial si kladlo za cíl využít komunitní zpravodajství k nalezení efektivních řešení a zároveň brainstorming o budoucnosti intervencí umělé inteligence na zasedáních a dialozích.
O výsledcích zvláštního zasedání informujeme v tomto článku.
Speciální sekci SummDial jsme uspořádali pod záštitou projektu H2020 European Live Translator (ELITR) financovaného EU.
Tento výstup představuje tři podrobné případové studie pro každou z hlavních tematických oblastí úkolu SSHOC 3.1 "Vícejazyčné terminologie", jejichž cílem je prozkoumat přístupy NLP a MT s ohledem na poskytování zdrojů a nástrojů pro podporu vícejazyčného přístupu k obsahu SSH v různých jazycích a zlepšení vyhledávání pro nerodilé mluvčí.
Soubor vícejazyčných metadatových konceptů, vícejazyčných slovníků a automaticky extrahovaných vícejazyčných terminologií byl dodán jako volně dostupná data, plně odpovídající zásadám FAIR prosazovaným v rámci EOSC, která lze nalézt prostřednictvím VLO a dalších služeb CLARIN a SSHOC.
Rozpoznávání ručně psané hudby je náročná úloha, které může vést ke zlepšení dostupnosti archivních rukopisů nebo usnadnění hudební kompozice.
Moderních metody strojového učení však nelze na tuto úlohu snadno aplikovat kvůli omezené dostupnosti kvalitních trénovacích dat.
Ruční anotace takových dat je drahá, a proto není v potřebném měřítku proveditelná.
Tento problém již byl v jiných oblastech vyřešen trénováním  na automaticky generovaných syntetických datech.
V tomto článku používáme stejný přístup k rozpoznávání ručně psané hudby a představujeme metodu generování syntetických snímků ručně psaných hudebních zápisů a ukazujeme, že trénování na těchto datech vede k výborným výsledkům.
Nedávný výbuch falešných informací na sociálních média vedla k intenzivnímu výzkumu automatických modelů fake news detection a ověřovačů faktů.
Falešné zprávy a dezinformace, vzhledem ke své zvláštnosti a rychlému šíření, představovaly mnoho zajímavé výzvy v oblasti zpracování přirozeného jazyka (NLP) a komunity Machine Learning (ML).
Přípustná literatura ukazuje, že neotřelé informace zahrnují moment překvapení, což je hlavní charakteristika pro zesílení a viralita dezinformací.
Román a emocionální informace přitahuje okamžitou pozornost čtenáře.
Emoce jsou prezentace určitého pocitu nebo sentimentu.
Sentiment pomáhá jedince, který by vyjadřoval své emoce prostřednictvím výrazu a proto spolu tyto dvě věci souvisejí.
Tedy novinka v novince a následně zjištění emočního stavu a pocitu čtečka vypadá jako tři klíčové ingredience, těsně spojené s dezinformacemi.
V tomto dokumentu navrhujeme hluboký multiúkol učící se model, který společně provádí detekci novot, emocí rozpoznávání, předpovídání nálad a odhalování dezinformací.
Náš navrhovaný model dosahuje nejmodernějších parametrů (SOTA) pro detekci falešných zpráv na třech srovnávacích datasetech, viz.
ByteDance, Fake News Challenge(FNC), a Covid-Stance s 11,55%, 1,58% a 21,76% zlepšením přesnosti, respektive.
Navrhovaný přístup také ukazuje na účinnost rámec jednoho úkolu se ziskem přesnosti 11,53, 28,62, a 14,31 procentního bodu u výše uvedených tří souborů údajů.
Zdrojový kód je dostupný na https://github.com/Nish-19/MultitaskFake-News-NES
Falešné zprávy nebo dezinformace jsou informace nebo příběhy záměrně vytvořené s cílem oklamat nebo uvést čtenáře v omyl.
V dnešní době se platformy sociálních médií staly zralým důvodem k dezinformacím a během několika minut je rozšířily, což vedlo k chaosu, panice a potenciálním zdravotním rizikům mezi lidmi.
Rychlé šíření a plodný nárůst šíření falešných zpráv a dezinformací vytváří časově nejkritičtější výzvy pro komunitu zpracování přirozeného jazyka (NLP).
Z příslušné literatury vyplývá, že přítomnost momentu překvapení v příběhu je silnou hnací silou rychlého šíření dezinformací, které přitahuje okamžitou pozornost a vyvolává ve čtenáři silné emocionální podněty.
Falešné příběhy nebo falešné informace jsou psány, aby vzbudily zájem a aktivovaly emoce lidí, aby je šířili.
Falešné příběhy mají tedy vyšší úroveň novosti a emočního obsahu než pravdivé příběhy.
Z toho vyplývá, že novost zpravodajského příspěvku a rozpoznání emočního stavu čtenáře po přečtení příspěvku jsou dva klíčové úkoly, které úzce souvisejí s odhalováním dezinformací.
Předchozí literatura nezkoumala detekci dezinformací vzájemným učením pro detekci novot a rozpoznávání emocí podle našeho nejlepšího vědomí.
Naše současná práce tvrdí, že společné učení novosti a emocí z cílového textu je pádným argumentem pro odhalování dezinformací.
V tomto dokumentu navrhujeme hluboký víceúčelový vzdělávací rámec, který společně provádí detekci novot, rozpoznávání emocí a detekci dezinformací.
Náš hluboký multitask model dosahuje nejmodernějších výkonů (SOTA) pro detekci falešných zpráv na čtyřech srovnávacích datasetech, viz.
ByteDance, FNC, Covid-Stance a FNID s přesností 7,73%, 3,69%, 7,95% a 13,38%.
Z hodnocení vyplývá, že náš víceúkolový vzdělávací rámec zlepšuje výkon oproti jednoúkolovému rámci pro čtyři datové soubory o 7,8 %, 28,62 %, 11,46 % a 15,66 % celkového zisku přesnosti.
Tvrdíme, že textová novinka a emoce jsou dva klíčové aspekty, které je třeba zvážit při vývoji automatického mechanismu detekce falešných zpráv.
Zdrojový kód je dostupný na adrese https://github.com/Nish-19/Misinformation-Multitask-Attention-NE.
Jednou z časově nejkritičtějších výzev pro komunitu zpracování přirozeného jazyka (NLP) je boj proti šíření falešných zpráv a dezinformací.
Stávající přístupy k odhalování dezinformací využívají modely neurální sítě, statistické metody, jazykové znaky, strategie ověřování faktů atd.
Zdá se však, že hrozba falešných zpráv s příchodem humorných a neobvykle kreativních jazykových modelů sílí.
Z příslušné literatury vyplývá, že jedním z hlavních rysů virality falešných zpráv je přítomnost momentu překvapení v příběhu, který přitahuje okamžitou pozornost a vyvolává ve čtenáři silné emocionální podněty.
Při této práci tuto myšlenku zužitkujeme a navrhujeme jako dva úkoly související s automatickou detekcí dezinformací detekci textových novinek a předvídání emocí.
Pro detekci novot používáme znovu účelové textové obnosy a k třídění falešných informací využíváme modely trénované na rozsáhlých datových souborech obnosů a emocí.
Naše výsledky korelují s myšlenkou, protože dosahujeme nejmodernějších výsledků (SOTA) ve čtyřech rozsáhlých souborech dezinformačních dat (7,92%, 1,54%, 17,31% a 8,13% zlepšení z hlediska přesnosti).
Doufáme, že naše současná sonda bude motivovat komunitu k dalšímu výzkumu odhalování dezinformací v tomto směru.
Zdrojový kód je dostupný na GitHub.2
Představujeme model AggGen (vyslovuje se "again"), který do neuronových systémů pro převod dat na text znovu zavádí dvě explicitní fáze plánování vět: řazení a agregaci vstupů.
Na rozdíl od předchozích prací využívajících plánování vět je náš model stále end-to-end: AggGen provádí plánování vět současně s generováním textu tím, že se učí latentní zarovnání (prostřednictvím sémantických faktů) mezi vstupní reprezentací a cílovým textem.
Experimenty na datech ze soutěží WebNLG a E2E ukazují, že díky použití zarovnání na základě faktů je náš přístup interpretovatelnější, expresivnější, odolnější vůči šumu a snadněji kontrolovatelný, přičemž si zachovává výhody end-to-end systémů z hlediska plynulosti.
Náš kód je k dispozici na adrese https://github.com/XinnuoXu/AggGen.
V této práci popisujeme naše systémové předkládání úkolu SemEval 2021 11: NLP Contribution Graph Challenge.
Vyzkoušíme všechny tři dílčí úkoly výzvy a podáme zprávu o výsledcích.
Cílem dílčího úkolu 1 je identifikovat přispívající věty v dané publikaci.
Dílčí úkol č. 2 vyplývá z dílčího úkolu č. 1, jehož cílem je vyjmout vědecký termín a predikovat věty z označených přispívajících vět.
Závěrečný dílčí úkol 3 spočívá ve vyjmutí trojic (předmět, predikát, objekt) z frází a jejich kategorizaci do jedné nebo více definovaných informačních jednotek.
Sdíleným úkolem NLPContributionGraph organizátoři formalizovali vytvoření odborně zaměřeného grafu nad odbornými články NLP jako automatizovaný úkol.
Mezi naše přístupy patří klasifikační model založený na BERT pro identifikaci přispívajících vět ve výzkumné publikaci, analýza závislosti založená na pravidlech pro extrakci frází, následovaná modelem podle CNN pro klasifikaci informačních jednotek a soubor pravidel pro extrakci trojice.
Kvantitativní výsledky ukazují, že pátou, pátou a sedmou příčku získáváme ve třech fázích hodnocení.
Naše kódy jsou dostupné na https://github.com/HardikArora17/SemEval-2021-INNOVATORS.
Tento článek obsahuje popis sdílených úloh na WAT 2021 podle našeho tým "NLPHut".
Zúčastnili jsme se úlohy multimodálního překladu angličtina→hindština, úlohy multimodálního překladu angličtina→malajština a úlohy vícejazyčného překladu z indických jazyků.
Použili jsme nejmodernější model Transformeru s jazykovými značkami v různých nastaveních pro překladatelskou úlohu a navrhli jsme nové "regionálně specifické" generování titulků využívající kombinaci obrazových CNN a LSTM pro hindštinu a malajalamštinu.
Náš příspěvek v angličtině→malajálamštině Multimodální překladatelské úlohy (překlad pouze textu a titulků) a na druhém místě v úloze multimodálního překladu angličtina→hindština (překlad pouze textu a titulků).
Naše příspěvky si vedly dobře také v indických vícejazyčných překladových úlohách.
Článek poskytuje stručný přehled možných metod, jak zjistit, že referenční překlady byly ve skutečnosti vytvořeny posteditací strojového překladu.
Využity byly dvě metody založené na automatických metrikách: 1. rozdíl BLEU mezi podezřelým MT a některým jiným dobrým MT a 2. rozdíl BLEU s využitím dalších referencí.
Tyto dvě metody odhalily podezření, že oficiální reference z WMT 2020 je ve skutečnosti posteditovaný strojový překlad.
Toto podezření bylo potvrzeno při manuální analýze zjištěním konkretních dokladů o posteditačním postupu.
Také byla vytvořena typologie posteditačních změn, kde jsou uvedeny některé chyby nebo změny provedené posteditorem, nebo také chyby převzaté ze strojového překladu.
Představujeme vítězný systém z Multilingual Lexical Normalization (MultiLexNorm) Shared Task na W-NUT 2021 (van der Goot et al., 2021a), který vyhodnocuje lexikálně-normalizační systémy na 12 datasetech sociálních médií v 11 jazycích.
Naše řešení zakládáme na předtrénovaném jazykovém modelu ByT5 (Xue et al., 2021a), který dále trénujeme na syntetických datech a poté dotrénováváme na autentických normalizačních datech.
Náš systém dosahuje nejlepších výsledků s velkým náskokem v intrinsic hodnocení a také nejlepších výsledků v extrinsic vyhodnocení prostřednictvím syntaktické analýzy.
Zdrojový kód je uvolněn na https://github.com/ufal/multilexnorm2021 a natrénované modely na https://huggingface.co/ufal.
Klasifikace předmětných článků je důležitým problémem Schosimilar Document Processing to address the huge information overload in the scholarly space.
Tento dokument popisuje přístup našeho týmu CUNI-NU pro Biocreative VII-Track 5 challenge: Litcovid multilabel topic classification for COVID-19 literatura [1].
Cílem dotčeného úkolu je automatizovat manuální nakládání s biomedicínskými předměty do sedmi různých značek, konkrétně pro datové úložiště LitCovid.
Naše nejlepší model používá dokument SPECTER [2] zápatí pro reprezentaci abstraktních, a tituly vědeckých články následované mechanismem Dual-Attention [3] do perform multilabel kategorizace.
Dosáhli jsme významného lepší výkon než základní metody.
Děláme náš kód dostupný na https://github.com/Nid989/ CUNI-NU-Biocreative-Track5
Adaptovali jsme na češtinu čtyři klasické metriky srozumitelnosti na základě dat InterCorp (paralelní korpus s ručním zarovnáním vět)a CzEng 2.0 (velký paralelní korpus procházených webových textů) a algoritmu optimize.curve z knihovny SciPy.
Adaptované metriky jsou: Flesch Reading Ease, Flesch-Kincaid Grade Level, Coleman-Liau Index a Automated Readability Index.
Popisujeme podrobnosti postupu a předkládáme uspokojivé výsledky.
Kromě toho diskutujeme citlivost těchto metrik na textové parafráze a korelaci skóre srozumitelnosti s empiricky pozorovaným porozuměním čtenému a také adaptaci Flesch Reading Ease na češtinu z ruštiny.
Přestože přístupy založené na neuronových sítích výrazně zvýšily plynulost strojově generovaného textu, jsou náchylné k chybám v přesnosti, jako je vynechávání částí vstupu (opomenutí) nebo generování výstupu, který nemá oporu v žádném vstupu (halucinace).
Tento problém se projevuje zejména při menším množství trénovacích dat, generování delších textů nebo šumu v trénovacích datech.
Všechny tyto podmínky jsou pro úlohy generování přirozeného jazyka (NLG) velmi časté.
V této přednášce ukážu několik příkladů přístupů zaměřených na vytváření přesnějších výstupů v rámci systému NLG nebo na odhalování chyb ve výstupech systému NLG.
Konkrétně se zaměřím na neuronové architektury sequence-to-sequence s předtrénovanými jazykovými modely a jejich rozšíření.
Budu se zabývat především generováním textu ze strukturovaných dat, ale uvedu i srovnání se situací při sumarizaci nebo generování dialogových odpovědí.
V posledních desetiletích stále větší počet vystupujících umělců a technologů přivedl roboty na středové pódium při jejich vystoupeních.
AI si přisvojila role komediálních improvizátorů, vypravěčů, herců, tanečníků a choreografů, čímž narušila tradiční obousměrnou lidskou herecko-lidskou diváckou interakci.
Předložením této přednášky se snažíme zpochybnit myšlenku, že živé představení je specificky lidskou činností, a prozkoumat různé formy interakce mezi člověkem a umělou inteligencí v divadle.
Jaký příběh Al vypráví?
Jaké emoce to může vyvolat?
Myslíte si, že umělá inteligence je schopna vytvořit příjemný divadelní scénář?
Může se robot stát dramatikem?
Existuje dokonalý divadelní večer, který vyprodukuje autonomní stroj?
Šestý ročník workshopu Search-Oriented Conversational AI (SCAI 2021) byl uspořádán jako diskusní platforma o konverzační umělé inteligenci pro inteligentní přístup k informacím.
Workshop byl koncipován jako multidisciplinární a spojil výzkumné pracovníky a odborníky z praxe napříč obory zpracování přirozeného jazyka (NLP), vyhledávání informací (IR), strojového učení (ML) a interakce člověk-počítač (HCI).
Workshop zahrnoval čtyři sekce, na nichž zazněly pozvané přednášky, samostatnou posterovou sekci a sekci, na níž se diskutovalo o výsledcích soutěže v konverzačním zodpovídání otázek (SCAI-QReCC).
Představujeme experimenty s automatickým odhalováním nekonzistentního chování na základě kontextu u dialogových systémů orientovaných na úkoly.
Obohacujeme data bAbI/DSTC2 (Bordes et al., 2017) o automatickou anotaci nekonzistencí v dialogu a ukazujeme, že nekonzistence korelují s neúspěšnými dialogy.
Předpokládáme, že použití omezené historie dialogů a předvídání dalšího tahu uživatele může zlepšit klasifikaci nekonzistencí.
Zatímco obě hypotézy se potvrzují pro dialogový model založený na memory networks, neplatí pro trénování jazykového modelu GPT-2, který nejvíce těží z použití úplné historie dialogu a dosahuje 99% přesnosti.
Předtrénované jazykové modely založené na attention, jako je GPT-2, přinesly značný pokrok v modelování dialogů "end-to-end".
Pro dialog zaměřený na úkoly však představují také značná rizika, jako je nedostatečná podloženost fakty nebo rozmanitost odpovědí.
Abychom tyto problémy vyřešili, zavádíme modifikované trénovací cíle pro dotrénování jazykového modelu a využíváme masivní augmentaci dat pomocí zpětného překladu, abychom zvýšili rozmanitost trénovacích dat.
Dále zkoumáme možnosti kombinace dat z více zdrojů s cílem zlepšit výkonnost na cílové datové sadě.
Naše příspěvky pečlivě vyhodnocujeme pomocí lidských i automatických metod.
Náš model podstatně překonává základní model na datech MultiWOZ a vykazuje výkon konkurenceschopný se současným stavem techniky při automatickém i lidském hodnocení.
Předtrénované jazykové modely založené na attention, jako je GPT-2, přinesly značný pokrok v end-to-end modelování dialogů.
Pro dialog zaměřený na úkoly však představují také značná rizika, jako je nedostatečná korespondence s databází nebo nedostatek rozmanitosti odpovědí.
Abychom tyto problémy vyřešili, zavádíme pro doladění jazykového modelu modifikované trénovací cíle a využíváme masivní rozšíření trénovacích dat pomocí zpětného překladu, čímž zvyšujeme jejich rozmanitost.
Dále zkoumáme možnosti kombinace dat z více zdrojů s cílem zlepšit výkonnost na cílové datové sadě.
Naše příspěvky pečlivě vyhodnocujeme pomocí ručních i automatických metod.
Náš model dosahuje nejlepších výsledků na datové sadě MultiWOZ a vykazuje konkurenceschopný výkon při lidském hodnocení.
Naše kniha „The Reality of Multi-Lingual Machine Translation“ pojednává o výhodách a nebezpečích používání více než dvou jazyků v systémech strojového překladu.
I když se kniha zaměřuje na konkrétní úkol zpracování sekvencí a víceúkolového učení (multi-task learning), cílí i poněkud mimo oblast zpracování přirozeného jazyka.
Strojový překlad je pro nás ukázkovým příkladem aplikací hlubokého učení, kde jsou lidské dovednosti a schopnosti učení brány jako laťka, kterou se mnozí snaží dosáhnout a překonat.
Dokumentujeme, že některé z výdobytků pozorovaných v mnohojazyčném překladu mohou vyplývat z jednodušších důvodů, než je předpokládaný přenos znalostí napříč jazyky.
V první, spíše obecné části vás kniha provede motivací pro mnohojazyčnost, univerzálností hlubokých neuronových sítí zejména v úlohách typu sequence-to-sequence až ke komplikacím tohoto učení.
Obecnou část uzavíráme varováním před příliš optimistickým a neopodstatněným vysvětlením zlepšení, které neuronové sítě demonstrují.
Ve druhé části se plně ponoříme do mnohojazyčných modelů, se zvlášť pečlivým zkoumáním učení přenosem (transfer learning) jako jednoho z přímočařejších přístupů využívajících další jazyky.
Zkoumány jsou současné vícejazyčné techniky, včetně masivních modelů, a diskutovány jsou praktické aspekty nasazení mnohojazyčných systémů.
Závěr knihy zdůrazňuje otevřený problém strojového porozumění a připomíná dva etické aspekty budování rozsáhlých modelů: inkluzivnost výzkumu a jeho ekologický dopad.
V mediálním průmyslu se zaměření globálního zpravodajství může přes noc změnit.
Existuje přesvědčivá potřeba být schopni vyvinout nové systémy strojového překladu v krátkém časovém období, aby bylo možné efektivněji pokrýt rychle se vyvíjející příběhy.
Jako součást stroje s nízkými zdroji překladatelského projektu GOURMET jsme náhodně vybrali jazyk, pro který musel být systém postaveno a vyhodnoceno za dva měsíce (únor a březen 2021).
Vybraný jazyk byl Paštština, indoíránský jazyk používaný v Afghánistánu, Pákistánu a Indii.
V tomto období jsme dokončili celý proces vývoje systému neuronového strojového překladu: procházení dat, čištění, zarovnání, vytváření testovacích sad, vývoj a testování modelů a jejich poskytování uživatelským partnerům.
V tomto článku popisujeme rychlý proces vytváření dat a experimenty s transferovým učením a přípravou na paštskou angličtinu.
Zjišťujeme, že začínáme od existujícího velký model předem proškolený na 50 jazycích vede k mnohem lepším výsledkům BLEU než předtrénování na jeden vysoce zdrojový jazykový pár s menším modelem.
Uvádíme také lidské hodnocení naše systémy, což naznačuje, že výsledné systémy fungují lépe než volně dostupné komerční systém při překladu z angličtiny do paštštiny a podobně při překlad z paštštiny do angličtiny.
V tomto příspěvku popisujeme, jak byla korpusová platforma TEITOK integrována s korpusovými platformami KonText a PML-TQ v LINDAT, aby poskytla vizualizaci dokumentů pro stávající i budoucí zdroje v LINDAT.
TEITOK je online platforma pro vyhledávání, prohlížení a úpravy korpusů, kde jsou soubory korpusu ukládány jako anotované soubory TEI / XML.
Integrace TEITOK také znamená, že zdroje LINDAT budou k dispozici ve formátu TEI / XML a lze je vyhledávat v CWB nad rámec stávajících nástrojů ústavu.
Ačkoli integrace popsaná v tomto článku je specifická pro LINDAT, tato metoda by měla být použitelná pro integraci TEITOK nebo podobných nástrojů do existující korpusové architektury.
Deep Universal Dependencies (hluboké univerzální závislosti) je sbírka treebanků poloautomaticky odvozených z Universal Dependencies.
Obsahuje přídavné hloubkově-syntaktické a sémantické anotace.
Verze Deep UD odpovídá verzi UD, na které je založena.
Mějte však na paměti, že některé treebanky UD nebyly do Deep UD zahrnuty.
Představujeme GEM, živý benchmark pro generování přirozeného jazyka (NLG), jeho evaluaci a metriky.
Měření pokroku v oblasti NLG se opírá o neustále se vyvíjející ekosystém automatizovaných metrik, datových sad a standardů lidské evaluace.
Vzhledem k tomuto pohyblivému cíli se nové modely často stále vyhodnocují na odlišných anglocentrických korpusech s dobře zavedenými, ale chybnými metrikami.
Tato nesouvislost ztěžuje identifikaci omezení současných modelů a příležitostí k pokroku.
GEM toto omezení řeší a poskytuje prostředí, v němž lze modely snadno aplikovat na široký soubor úloh a v němž lze testovat evaluační strategie.
Pravidelné aktualizace benchmarku pomohou výzkumu NLG stát se více mnohojazyčným a rozvíjet úlohu spolu s modely.
Tento článek slouží jako popis dat pro sdílenou úlohu 2021 na souvisejícím workshopu GEM.
V tomto článku představujeme metodu pro vytváření slovotvorných sítí pomocí přenosu informací z jiného jazyka.
Navrhovaný algoritmus využívá existující slovotvornou síť a paralelní texty a vytváří síť s nízkou precision a středním recallem v jazyce, pro který nemusí být k dispozici manuální anotace.
Recall výsledné sítě pak rozšířujeme tím, že ji využijeme k natrénování metody strojového učení a výsledný model aplikujeme na větší slovník, čímž získáme výsledek s obdobnou precision, ale vyšším recallem.
Přístup je vyhodnocován proti existujícím slovotvorným sítím ve francouzštině, němčině a češtině.
Představujeme pilotní experimenty na dělení a identifikaci českých složených slov.
Vytvořili jsme algoritmus měřící jazykovou podobnost dvou slov založený na nalezení nejkratšího cesta skrze matici vzájemných odhadovaných korespondencí mezi dvěma fonologicky přepsanými řetězci.
Dále jsme vytvořili nástroj pro splitting neboli dělení složených slov (Czech Compound Splitter) pomocí frameworku Marian Neural Machine Translator, který byl vytrénován na datové sadě obsahující 1 164 ručně anotovaných sloučenin a zhruba 280 000 synteticky vytvořených kompozit.
Ve splittingu kompozit dosáhlo první řešení přesnosti 28 % a druhé řešení 54 % na validačním datové sadě.
V úloze identifikace kompozit dosáhl Czech Compound Splitter přesnosti 91%.
Jazykové domény vyžadující velmi pečlivé používání terminologie jsou hojné a odrážejí významnou část překladatelského průmyslu.
V této práci představujeme metriku pro hodnocení kvality a konzistentnosti překladu terminologie se zaměřením na lékařskou (a konkrétně COVID-19) doménu pro pět jazykových párů: angličtinu do francouzštiny, čínštiny, ruštiny a korejštiny, a dále češtinu do němčiny.
Uvádíme popisy a výsledky zúčastněných systémů, vyjadřujeme nutnost dalšího výzkumu jak pro adekvátnější zacházení s terminologií, tak pro správnou formulaci a vyhodnocení úlohy.
Popisujeme pilotní experiment zaměřený na harmonizaci různorodých datových zdrojů, které obsahují anotace související s koreferencí.
Převedli jsme 17 existujících korpusů 11 jazyků do společného anotačního schématu, založeného na Universal Dependencies, a zveřejnili jsme podmnožinu této kolekce pod názvem CorefUD 0.1 v repozitáři LINDAT-CLARIAH-CZ (http://hdl.handle.net/11234/1-3510).
CorefUD je kolekce existujících korpusů s anotací koreference, které jsme převedli na jednotné anotační schéma.
Ve své současné verzi 0.1 CorefUD celkem obsahuje 17 korpusů pro 11 jazyků.
CorefUD je kolekce existujících korpusů s anotací koreference, které jsme převedli na jednotné anotační schéma.
Ve své současné verzi 0.2 CorefUD celkem obsahuje 17 korpusů pro 11 jazyků a v porovnání s verzí 0.1 obsahuje kvalitnejší automatickou morfo-syntaktickou anotaci.
Předkládáme empirickou studii, která srovnává hlavy zmínek anotovaných ručně ve čtyřech koreferenčních datových sadách (pro nizozemštinu, angličtinu, polštinu a ruštinu) na jedné straně a hlavy vyplývající z automaticky predikovaných závislostních syntaktických stromů na straně druhé.
Tento dokument popisuje náš systém účasti na argumentačním textu chápajícím sdílený úkol pro AI Debater na NLPCC 2021 (http://www.fudan-disc.com/sharedtask/AIDebater21/tracks.html).
Úkoly jsou motivovány k rozvoji autonomního diskusního systému.
Počáteční pokus provedeme s trackem-3, konkrétně extrakcí argumentačních dvojic z recenzního posudku a vyvrácením, kdy extrahujeme argumenty z recenzního posudku a jejich odpovídající vyvrácení z autorových odpovědí.
Ve srovnání s víceúkolovou základnou organizátorů zavádíme dvě významné změny: i) používáme vkládání tokenu ERNIE 2.0, které dokáže lépe zachytit lexikální, syntaktické a sémantické aspekty informací v tréninkových datech, ii) provádíme dvojí učení pozornosti, abychom zachytili dlouhodobé závislosti.
Náš navrhovaný model dosahuje nejmodernějších výsledků s relativním zlepšením skóre F1 o 8,81% oproti základnímu modelu.
Náš kód zveřejníme na adrese https://github.com/guneetsk99/ArgumentMining_SharedTask.
Náš tým ARGUABLY je jedním z třetích oceněných týmů v Tracku 3 společného úkolu.
Lexikálně omezený strojový překlad umožňuje uživateli manipulovat s výstupní větou vynucením přítomnosti nebo nepřítomnosti určitých slov a frází.
Přestože současné přístupy dokáží vynutit, aby se v překladu objevily specifikované termíny, často se snaží, aby povrchová forma omezeného slova souhlasila se zbytkem vygenerovaného výstupu.
Ruční analýza ukazuje, že 46% chyb ve výstupu základního omezeného modelu překladu z angličtiny do češtiny souvisí s gramatickou shodou.
Zkoumáme mechanismy, které umožňují neuronových strojový překlad k určení správné inflexe omezujících slov specifikovaných pomocí lemmat.
Zaměřujeme se zejména na metody založené na tréninku modelu s omezeními, které jsou součástí vstupu.
Naše experimenty na anglicko-českém jazykovém páru ukazují, že tento přístup zlepšuje překlad s omezením pomocí termínů a to jak v automatickém i ručním hodnocení, snížením počtu chyb v gramatické shodě.
Náš přístup tak odstraňuje inflexní chyby, aniž by zaváděl nové chyby nebo snižoval celkovou kvalitu překladu.
Neuronové sítě jsou nejmodernější metodou strojového učení pro mnoho problémů v NLP.
Jejich úspěch ve strojovém překladu a dalších úlohách NLP je fenomenální, ale jejich interpretovatelnost je náročná.
Chceme zjistit, jak neuronové sítě reprezentují význam.
Za tímto účelem navrhujeme prozkoumat rozložení významu ve vektorovém prostoru reprezentace slov v neuronových sítích trénovaných pro úlohy NLP.
Dále navrhujeme zvážit různé teorie významu ve filosofii jazyka a najít metodologii, která by nám umožnila tyto oblasti propojit.
Dataset MultiWOZ (Budzianowski et al.,2018) je často užíván na poměřování schopností generovat odpověď z kontextu v případě dialogových systému zaměřených na úkoly.
V této práci identifikujeme nekonzistence v předzpracování dat a reportování tří metrik založených na evaluačním korpusu, tj., BLEU skóre, míry Inform a míry Success, v kontextu tohoto datasetu.
Poukazujeme na několik problémů benchmarku MultiWOZ jako je neuspokojivé předzpracování dat, nedostatečné nebo nedostatečně specifikované evaluační metriky, nebo neohebná databáze.
Ve spravedlivých podmínkách jsme znovu vyhodnotili 7 end-to-end a 6 policy optimization modelů a ukázali jsme, že jejich původně reportovaná skóre nemohou být přímo srovnávána.
Abychom ulehčili porovnávání budoucích systémů, zveřejňujeme naše soběstačné standardizované evaluační skripty.
Rovněž dáváme základní doporučení pro budoucí vyhodnocování založená na evaluačním korpusu.
Se stále rostoucím tempem výzkumu a velký objem vědecké komunikace, stipendisty čeká nelehký úkol.
Nejen musí udržují krok s rostoucí literaturou v svých vlastních a souvisejících oborů, musí vědci stále častěji také vyvracet pseudovědu a dezinformace.
Tyto potřeby motivovaly rostoucí zaměření na výpočetní metody pro zlepšení vyhledávání, sumarizace a analýzy odborných dokumentů.
Nicméně různé oblasti výzkumu vědeckého zpracování dokumentů zůstávají roztříštěné.
K dosažení širší komunitě NLP a AI/ML, společné úsilí v této oblasti a umožnit sdílený přístup k publikovanému výzkumu, my uspořádal 2. seminář o zpracovávání dokumentů (SDP) v rámci programu NAACL 2021 jako virtuální událost (https://sdproc.org/2021/).
The SDP workshop sestával z výzkumné dráhy, tři pozvané rozhovory a tři sdílené úkoly (LongSumm 2021, SCIVER a 3C).
Program byl zaměřen na NLP, získávání informací a dolování dat pro vědecké dokumenty s důrazem na identifikaci a řešení otevřených výzev.
Seznámení uchazečů o různé projekty našimi zkušenostmi s koordinací projektu ELITR.
Představil jsem výzkumný projekt ELITR a současný stav poznání v oblasti strojového překladu a překladu mluvené řeči.
Představení dvou aktuálních aplikovaných projektů ELITR a Bergamot a projektu základního výzkumu NEUREM3, realizovaných na ÚFALu.
542 / 5000 Translation results Tento článek představuje systém automatického překladu řeči zaměřený na živé titulkování konferenčních prezentací.
Popisujeme celkovou architekturu a klíčové komponenty zpracování.
Důležitější je, že vysvětlujeme naši strategii budování komplexního systému pro koncové uživatele z mnoha jednotlivých komponent, z nichž každá byla testována pouze v laboratorních podmínkách.
Systém je funkčním prototypem, který je rutinně testován v rozpoznávání anglické, české a německé řeči a současně je prezentován přeložený do 42 cílových jazyků.
Příspěvek popisuje praktické zkušenosti z testování systému pro simultánní překlad mluvené řeči z projevu řečníků a tlumočníků.
Tato testovací sada strojového překladu obsahuje 2223 českých vět shromážděných v rámci projektu FAUST (https://ufal.mff.cuni.cz/grants/faust, http://hdl.handle.net/11234/1-3308).
Každá původní věta obsahující šum byla normalizována (clean1 a clean2) a nezávisle na sobě přeložena do angličtiny dvěma překladateli.
Proč a jakým způsobem integruje datový repozitář LINDATu služby podporující a využívající přímé citování dat.
Informace o centrálním repozitáři LINDAT/CLARIAH-cz, obzvláště z hlediska FAIR aspektů
Technická zprava shrnuje pravidla pro zařazení německých synonym do synonymního slovníku SynSemClass.
SynSemClass lexicon 3.5 zkoumá s ohledem na kontextově založenou slovesnou synonymii, sémantickou „ekvivalenci“ českých, anglických a německých sloves a jejich valenční chování v paralelních česko-anglických a německo-anglických jazykových zdrojích.
SynSemClass 3.5 je vícejazyčná ontologie typu události založená na třídách synonymních významů sloves, doplněná sémantickými rolemi a odkazy na existující sémantické lexikony.
Kromě již použitých odkazů na položky PDT-Vallex, EngVallex, CzEngVallex, FrameNet, VerbNet, PropBank, Ontonotes a English WordNet pro české a anglické záznamy jsou nové odkazy na německé jazykové lexikální zdroje, jako je Woxikon, E-VALBU a GUP, využívány pro německé slovesné záznamy.
Německá část lexikonu byla vytvořena v rámci projektu Multilingual Event-Type-Anchored Ontology for Natural Language Understanding (META-O-NLU) dvěma spolupracujícími týmy - týmem Univerzity Karlovy, Matematicko-fyzikální fakulty, Ústavu formální a aplikované lingvistiky, Praha (ÚFAL), Česká republika a týmem Německého výzkumného centra pro umělou inteligenci (DFKI) Speech and Language Technology, Berlín, Německo.
V článku prezentujeme výsledky automatického srovnání valenčních rámců vzájemně propojených adjektivních a slovesných lexikálních jednotek, obsažených ve valenčních slovnících NomVallex a VALLEX.
Rozlišujeme devět derivačních typů deverbálních adjektiv a zkoumáme, zda vykazují systémové valenční chování, nebo spíše nesystémové valenční chování.
K projevům nesystémového valenčního chování patří změny v počtu valenčních doplnění a především nesystémové formy aktantů, zvláště nesystémová předložková skupina.
Představujeme metodu pro rozšíření pokrytí Slovníku českých diskurzních konektorů (CzeDLex) pomocí anotační projekce.
Využíváme dva jazykové zdroje: (i) Penn Discourse Treebank 3.0 jako zdroj ručně anotovaných diskurzních vztahů v angličtině a (ii) Pražský česko -anglický závislostí korpus 2.0 jako překlad anglických textů do češtiny a propojení mezi tokeny v obou jazycích.
Přestože byl CzeDLex původně extrahován z velkého českého korpusu, vedla prezentovaná metoda k přidání řady nových konektorů a nových užití (diskurzních typů) pro již přítomné položky ve slovníku.
CzeDLex 1.0 je první produkční verze slovníku českých diskurzních konektorů, navazující na 3 předchozí verze vývojové.
Slovník obsahuje konektory částečně automaticky extrahované z Pražského diskurzního korpusu 2.0 (PDiT 2.0) a z dalších zdrojů.
Všechna slovníková hesla byla ručně zkontrolována, přeložena do angličtiny a doplněna dalšími lingvistickými informacemi.
Předkládáme experimenty zaměřené na predikci významu explicitních mezivětných diskurzních vztahů v češtině a angličtině, s využitím hlubokého učení (BERT) pro predikci významů a anotační projekce z angličtiny do češtiny pro zvětšení množství trénovacích dat pro češtinu.
Pokoušíme se osvětlit rozličné způsoby, kterými jazyky udávají datum a čas, a možnosti, které máme, když se příslušné konstrukce snažíme jednotně zachytit ve formalismu Universal Dependencies.
Probíráme příklady z několika jazykových rodin a navrhujeme jejich anotaci.
Doufáme, že tento (nebo podobný) návrh by se mohl v budoucnosti stát součástí anotačních pravidel UD, což by přispělo k větší konzistenci treebanků UD.
Současné anotace mají ke konzistenci daleko, jak přehledně ukazujeme v dodatcích k této studii.
Universal Dependencies (UD, univerzální závislosti) je mnohojazyčná kolekce korpusů, morfologicky a syntakticky anotovaných v jednotném stylu.
Představujeme volitelnou rovinu hloubkově-syntaktické anotace v UD, zvanou Enhanced Universal Dependencies (rozšířené univerzální závislosti).
Podáváme přehled rozšířených anotací ve verzi 2.8 a zvažujeme dvě možná budoucí pokračování: poloautomatické přidávání známých typů rozšíření do nových jazyků a přidávání nových typů rozšíření.
Představuji Universal Dependencies, mezinárodní komunitní projekt, v jehož rámci vznikla morfologická a syntaktická anotační pravidla aplikovatelná na všechny přirozené jazyky světa.
Probírám modely pro automatickou syntaktickou analýzu a jejich využití v digitálních humanitních studiích: v lingivistice, výuce jazyků, dokumentaci ohrožených jazyků, jazykové typologii a historickém vývoji jazyků.
Deep Universal Dependencies (hluboké univerzální závislosti) je sbírka treebanků poloautomaticky odvozených z Universal Dependencies.
Obsahuje přídavné hloubkově-syntaktické a sémantické anotace.
Verze Deep UD odpovídá verzi UD, na které je založena.
Mějte však na paměti, že některé treebanky UD nebyly do Deep UD zahrnuty.
Popisujeme druhou soutěž IWPT v automatické analýze prostého textu do struktur Enhanced Universal Dependencies.
Uvádíme podrobnosti o mírách použitých při vyhodnocení, jakož i o datových sadách použitých pro učení a vyhodnocení.
Srovnáváme přístupy jednotlivých týmů, které se soutěže zúčastnily, a rozebíráme výsledky, mimo jiné i ve srovnání s výsledky prvního ročníku této soutěže.
Příspěvek přináší diskusi o homonymii českých podstatných jmen s různým nebo kolísavým rodem.
Lemata s tímto typem homonymie jsou v novém vydání slovníku MorfFlex považována za různá.
Ukazujeme, že rozdělení paradigmat podle rodu je nejen zbytečné, ale také nepraktické.
Proto tomuto druhu hononymie říkáme „umělé“.
Příručka snadných jazyků v Evropě popisuje historické pozadí, principy a postupy Easy Language ve 21 evropských zemích.
Pojem Easy Language odkazuje na upravené formy standardních jazyků, jejichž cílem je usnadnit čtení a porozumění.
EngVallex 2.0 je aktualizovaná verze slovníku EngVallex.
Jedná se o anglický protějšek valenčního slovníku PDT-Vallex, který používá stejný pohled na valenci, valenční rámečky a popis povrchové formy slovních argumentů.
EngVallex obsahuje také odkazy na PropBank (anglický predicate-argument lexicon).
Slovník EngVallex je plně propojen s anglickou stranou PCEDT paralelního treebanku, což je ve reanotovaný PTB korpus ve stylu anotace Prague Dependency Treebank.
EngVallex je k dispozici ve formátu XML a také ve formě k online vyhledávání s příklady z PCEDT.
EngVallex 2.0 je stejný datový soubor jako EngVallex ve vydání PCEDT 3.0, ale vydává se samostatně na základě benevolentnější licence, čímž se předejde nutnosti pro uživatele získat LDC licenci, která je vázána na PCEDT 3.0 jako celek.
Práce se zabývá tvorbou agentních jmen v češtině, zejména kompeticí mezi osmi nejfrekventovanějšími agentními příponami.
Na základě metod strojového učení je v práci vyčíslen vliv různých formálně-lingvistických vlastností na výslednou volbu přípony při tvorbě agentního substantiva.
Tento článek popisuje projekt ParlaMint z hlediska jeho cílů, úkolů, účastníků, výsledků a aplikačního potenciálu.
Projekt vytvořil jazykové korpusy ze zasedání národních parlamentů 17 zemí, celkem téměř půl miliardy slov.
Korpusy jsou rozděleny na subkorpusy související s COVID (od listopadu 2019) a referenční korpusy (do října 2019).
Korpusy jsou jednotně kódovány podle schématu ParlaMint se stejnými lingvistickými anotacemi podle Universal Dependencies.
Ukázky korpusů a konverzních skriptů jsou dostupné z GitHub úložiště projektu.
Kompletní korpusy je volně dostupné ke stažení přes repozitář CLARIN.SI a přes concordancery NoSketch Engine a KonText i přes rozhraní Parlameter pro procházení a analýzu.
ParlaMint je vícejazyčný soubor srovnatelných korpusů parlamntních debat.
Obsahuje parlamentní data těchto zemí: Belgie, Bulharsko, Česko, Dánsko, Francie, Chorvatsko, Island, Itálie, Litva, Lotyšsko, Maďarsko, Nizozemí, Polsko, Slovinsko, Španělsko, Turecko, UK.
ParlaMint je vícejazyčný soubor srovnatelných  korpusů parlamntních debat.
Obsahuje parlamentní data těchto zemí: Belgie, Bulharsko, Česko, Dánsko, Chorvatsko, Island, Itálie, Litva, Lotyšsko, Maďarsko, Nizozemí, Polsko, Slovinsko, Španělsko, Turecko, UK.
ParlaMint.ana je vícejazyčný soubor srovnatelných lingvisticky anotovaných korpusů parlamntních debat.
Obsahuje parlamentní data těchto zemí: Belgie, Bulharsko, Česko, Dánsko, Chorvatsko, Island, Itálie, Litva, Lotyšsko, Maďarsko, Nizozemí, Polsko, Slovinsko, Španělsko, Turecko, UK.
ParlaMint.ana je vícejazyčný soubor srovnatelných lingvisticky anotovaných korpusů parlamntních debat.
Obsahuje parlamentní data těchto zemí: Belgie, Bulharsko, Česko, Dánsko, Francie, Chorvatsko, Island, Itálie, Litva, Lotyšsko, Maďarsko, Nizozemí, Polsko, Slovinsko, Španělsko, Turecko, UK.
Tento článek zkoumá nedávné pokroky v analýze Index Thomisticus Treebank, který zahrnuje středověké latinské texty Tomáše Akvinského.
Výzkum se zaměřuje na dva typy proměnných.
Na jedné straně zkoumá, jaký vliv má větší soubor dat na výsledky parsování, na druhé straně jsou analyzovány výkony nových parserů s ohledem na méně aktuální nástroje.
Termínem srovnání pro určení efektivního pokroku v parsování jsou výsledky při parsování Index Thomisticus Treebank popsané v předchozí práci.
Nejprve je nejvýkonnější parser z těch, kterých se týkala tato studie, testován na větším souboru dat, než byl ten původně použitý.
Poté jsou vyhodnoceny i některé kombinace parserů, které byly vyvinuty v téže studii, přičemž je posouzeno, že více trénovacích dat vede k přesnějším výkonům.
Nakonec, abychom prozkoumali, jaký vliv mají nově dostupné nástroje na výsledky parsování, trénujeme, testujeme a vyhodnocujeme dva neuronové parsery vybrané mezi těmi, které dosáhly nejlepších výsledků ve sdílené úloze CoNLL 2018.
Naše experimenty dosahují dosud nejvyšší dosažené míry přesnosti v automatickém syntaktickém rozboru Index Thomisticus Treebank a latiny celkově.
Měkké aspekty projektu THEaiTRE (humanitní vědy, PR, diskuse, diváci...)
Hackování jazykového modelu GPT-2 Sestavení webové aplikace Vytváří se scénář divadelní hry Představení hry na jevišti
Nástroj THEaiTRobot 1.0 umožňuje uživateli interaktivně generovat scénáře pro jednotlivé divadelní scény.
Nástroj je založen na jazykovém modelu GPT-2 XL.
Při vytváření skriptu tímto způsobem jsme narazili na řadu problémů.
Některé problémy se nám podařilo vyřešit různými úpravami, ale některé z nich je třeba vyřešit v budoucí verzi.
THEaiTRobot 1.0 byl použit k vytvoření první hry THEaiTRE, "AI: Když robot píše hru".
Představujeme první verzi systému pro interaktivní tvorbu divadelních scénářů.
Systém je založen na základním modelu GPT-2 s několika úpravami, se zaměřením na konkrétní problémy, se kterými jsme se setkali v praxi.
Popisujeme i další problémy, se kterými jsme se setkali, ale plánujeme je řešit až v budoucí verzi systému.
Předložený systém byl použit k vytvoření scénáře divadelní hry, která měla premiéru v únoru 2021.
Informujeme o AI: Když robot píše hru, divadelní hře s převážně uměle vytvořeným scénářem.
Popisujeme nástroj THEaiTRobot 1.0, který byl použit ke generování scénáře.
Diskutujeme o různých problémech, se kterými se v procesu setkáváme, včetně těch, které jsme do určité míry vyřešili, i těch, které plánujeme vyřešit v budoucí verzi systému.
V únoru 2021 jsme zinscenovali první divadelní hru, pro kterou bylo 90% scénáře automaticky generováno systémem umělé inteligence.
Systém THEaiTRobot je založen na jazykovém modelu GPT-2, který vytvořilo konsorcium OpenAI a který je doplněn o automatický překlad.
Model jsme museli různě upravovat, zejména abychom se vyhnuli opakování a zapomínání kontextu, a abychom se drželi omezeného souboru postav.
Jako vstup do systému jsme použili krátké úvodní výzvy (scénické nastavení a prvních pár řádků dialogu), připravené dramaturgem, které THEaiTRobot rozšířil do celých scén.
Scénář byl následně posteditován a uveden na scénu.
Recenze většinou zaznamenaly, že AI neumí napsat dobrou hru (zatím), ale uznaly, že představení bylo hlavně zajímavé a zábavné.
Se svým přístupem jsme čelili mnoha omezením.
Mohli jsme generovat pouze jednotlivé scény nezávisle, s omezeným počtem postav a s charaktery, které se často náhodně zaměňují a slučují.
Systém také nevidí za text scénáře, chybí mu porozumění vztahu scénáře k tomu, co se děje na jevišti.
V současné době pracujeme na nové verzi systému, která by měla některé problémy zlepšit a zároveň dále minimalizovat množství lidského vlivu.
Měl by také do procesu začlenit koncept dramatických situací.
Projekt THEaiTRE souvisí s dalšími podobnými pokusy, jako je hra Životní styl Richarda a rodiny, muzikál Za plotem, krátký film Sluneční jaro nebo představení divadelní skupiny Improbotics, které do jisté míry využívají automaticky generovaný obsah.
Naše hra mezi těmito projekty vyniká tím, že je poměrně dlouhá (60 minut) a zároveň má velmi vysoký podíl automaticky generovaného obsahu (90%).
Panel sleduje české divadelní představení „AI: When a Robot Writes a Play“, které bylo napsáno s pomocí systému AI a – namluveno robotem – pojednává o hledání sounáležitosti v odcizeném světě.
S tvůrci hry a dalšími umělci pracujícími s umělou inteligencí prozkoumáme, do jaké míry mohou systémy umělé inteligence imitovat lidskou tvořivost a co tato imitace vypovídá o našem chápání umění a společnosti.
Kromě strachu z toho, že počítače nahradí člověka, chceme diskutovat o tom, jaké nové možnosti může umělec nabídnout umění a jak umělci mohou kriticky a originálně přemýšlet o nových technologiích.
R.U.R.
Karla Čapka byla první divadelní hra napsaná člověkem o robotech (a lidech).
Premiéru měl 25. ledna 1921.
O sto let později, se všemi současnými pokroky ve zpracování přirozeného jazyka a umělých neuronových sítích, jsme v našem projektu THEaiTRE tuto myšlenku otočili.
25. ledna 2021 budeme mít premiéru "AI: When a robot writes a play" ("AI: robot píše hru"), divadelní hru o lidech (a robotech), kterou napsala naše umělá inteligence THEaiTRobot.
Umožňují to počítačoví lingvisté, kteří pro tento unikátní výzkumný projekt spojují své síly s divadelními odborníky.
O co v tomto projektu jde a jak byl vyvinut?
Jakým výzvám jsme čelili?
Jak ten umělou inteligencí vytvořený scénář vypadá?
...a opravdu chceme, aby umělá inteligence vytvářela umění?
Invertování R.U.R.
s umělou inteligencí.
Čapkovo výročí.
Vytváření divadelních her.
Příklady výstupů.
Pohled divadelního experta.
Argument těžby se zaměřuje na struktury v přirozeném jazyce související s tlumočením a přesvědčováním, které jsou pro vědeckou komunikaci stěžejní.
Většina vědecké rozpravy zahrnuje interpretaci experimentálních důkazů a snahu přesvědčit ostatní vědce, aby přijali stejné závěry.
Různé studie o těžbě argumentů se sice zabývaly studentskými eseji a zpravodajskými články, ale těch, které se zaměřují na vědecký diskurz, je stále málo.
Tento dokument zkoumá stávající práci v oblasti argumentační těžby odborného diskurzu a poskytuje přehled o aktuálních modelech, datech, úkolech a aplikacích.
Určujeme řadu klíčových výzev, před nimiž stojí argumentační těžba ve vědecké oblasti, a navrhujeme některá možná řešení a budoucí směry.
V příspěvku představujeme novou architekturu pro obnovu diakritiky založenou na kontextualizovaných vektorových reprezentacích, konkrétně BERT, a vyhodnocujeme ji ve dvanácti jazycích s diakritikou.
Dále jsme provedli detailní chybovou analýzu v češtině, jazyce s bohatou morfologií a vysokou úrovní diakritizace.
Zejména jsme ručně anotovali všechny chybné predikce a ukázali jsme, že zhruba 44% z chybně určené diakritizace nepředstavují skutečné chyby, nýbrž z 19% paralelní přijatelné varianty nebo dokonce systémové opravy diakritizace indukované různými chybami v datech (25%).
Nakonec jsme také detailně kategorizovali skutečné chyby systému.
Zdrojový kód jsme vydali zde: https://github.com/ufal/bert-diacritics-restoration.
Citlivost modelů hlubokého neuronového učení k šumu na vstupu je známý a výrazný problém.
Při strojovém zpracování přirozeného jazyka se výkon modelu často zhoršuje při přirozeně se vyskytujícím šumu, například při překlepech a pravopisných chybách.
Aby se tomuto problém zabránilo, modely často využívají data s uměle vytvořenými chybami.
Ovšem množství a typ takto generovaného šumu bylo dosud určováno libovolně.
My proto navrhujeme modelovat chyby statisticky z korpusů pro opravy gramatiky.
Předkládáme pečlivou evaluaci několika současných nástrojů strojového zpracování textu co do robustnosti v několika jazycích a úlohách, včetně morfo-syntaktické analýzy, rozpoznávání pojmenovaných entit, neuronového strojového překladu, podmnožiny úloh v GLUE a porozumění textu.
Dále srovnáváme dva přístupy pro zamezení zhoršení výkonu: a) trénování modelů za použití dat se šumem zavedeným pomocí našeho modelu; a b) redukci vstupního šumu pomocí externího nástroje pro kontrolu gramatiky.
Zdrojový kód je vydán na adrese https://github.com/ufal/kazitext.
Tento dokument představuje výsledky sdílených úkolů z 8. workshopu o překladech do asijských jazyků (WAT2021).
WAT2021 se účastnilo 28 týmů a 24 týmů předložilo výsledky překladů pro lidské hodnocení.
Obdrželi jsme také 5 článků.
Zhruba 2100 výsledků překladů bylo odevzdáno na automatickém hodnotícím serveru a vybraná podání byla vyhodnocena ručně.
V debatě navazující na inscenaci „AI: Když robot píše hru‟ se probírá otázka, která stála u zrodu celého projektu THEaiTRE, zda AI dokáže napsat divadelní hru.
Jak to vidí experti z nejrůznějších oborů IT?
Jak to vidí divadelní tvůrci, kteří se s textem, jež AI z 90% vytvořila, museli potýkat?
Jak to má AI s kreativitou?
A k jakým horizontům se AI ubírá nejen v oblasti umění?
Automatické hodnocení kvality strojového překladu (MT) bylo zkoumáno po několik desetiletí.
Strojový překlad mluveného jazyka (SLT), zejména simultánní, musí zvážit další kritéria a nemá standardní postup hodnocení a široce využívanou sadu nástrojů.
Abychom zaplnili tuto mezeru, představujeme SLTev, open-source nástroj pro komplexní hodnocení SLT.
SLTev informuje o kvalitě, latenci a stabilitě výstupu kandidáta SLT na základě časově vyznačeného přepisu a překladu odkazu do cílového jazyka.
Pokud jde o kvalitu, spoléháme na SacreBLEU, která poskytuje MT hodnotící opatření, jako je chrF nebo BLEU.
Pro latenci navrhujeme dvě nové bodovací techniky.
V zájmu stability rozšiřujeme dříve definovaná opatření normalizovaným flickerem v naší práci.
Navrhujeme také nové zprůměrování starších metod.
V projektu IWSLT 2020 SHARED TASK byla použita předběžná verze programu SLTev.
Navíc se rozšiřuje sbírka testovacích datových souborů, které jsou přímo přístupné přes SLTev, pro hodnocení systémů srovnatelných napříč papíry.
Představujeme koncept rozšíření vícejazyčného slovesného slovníku, který bude zahrnovat také němčinu.
V tomto slovníku jsou zatím zahrnuta česká a anglická slovesa a seskupena podle významu a sémantických vlastností.
Položky jsou dále propojeny s externími lexikálními zdroji jako VerbNet a PropBank.
V tomto článku představujeme náš plán zahrnout také německá slovesa jako kandidáty propojené s existujícími anglickými a českými slovesy.
Také identifikujeme specifické německé lexikální zdroje, se kterými bude slovník provázán.
Cílem této pilotní studie malého rozsahu je poskytnout návrh na rozšíření již existujícího lexikálního zdroje o nový jazyk.
THEaiTRE Je výzkumný projekt oslavující sté výročí premiéry divadelní hry R.U.R od autora Karla Čapka, ve které bylo slovo „robot“ poprvé použito v roce 1921.
Na oslavu tohoto 100 let starého jubilea se spojil Institut formální a aplikované lingvistiky na Matematicko-fyzikální fakultě Univerzity Karlovy se Švandovým divadlem na Smíchově s organizátory Hackathons CEE Hacks, aby čelili svým robotům s novou výzvou, dosud nevídanou v plném rozsahu - aby umělá inteligence napsala scénář.
První fáze projektu vyvrcholila premiérou divadelní inscenace AI: Když robot píše hru s cílem vytvořit scénář složený z dialogů vytvořených umělou inteligencí.
V současné době se připravuje druhá fáze, která bude uspořádána na rok 2022, kdy bude představen další premiér s propracovanějším jazykovým modelem.
Tento projekt financovala Technologická agentura České republiky ve spolupráci s prg.ai a Divadelní fakultou Akademie múzických umění v Praze.
Rudolf Rosa promluví o technickém zázemí projektu (jak umělá inteligence vytváří scénář), David Košťák promluví o vytvoření tohoto konkrétního scénáře a Daniel Hrbek shrne proces tvorby hry.
Citace jsou pro vědecký diskurz klíčové.
Vedle poskytování dodatečných kontextů výzkumným dokumentům působí citace jako sledovatelé směru výzkumu v určité oblasti a jako důležité měřítko pro pochopení dopadu výzkumné publikace.
S rychlým růstem publikací ve výzkumu začínají být velmi důležitá automatizovaná řešení pro identifikaci účelu a vlivu citací.
Úloha 3C Citation Context Classification Task organizovaná v rámci druhého semináře o zpracovávání dokumentů Schopodobně @ NAACL 2021 je sdíleným úkolem pro řešení výše uvedených problémů.
V tomto příspěvku představujeme náš tým, IITP-CUNI@3C, který se hlásí ke sdíleným úkolům 3C.
Pro úkol A, citační kontextovou klasifikaci účelu, navrhujeme neurální víceúčelový vzdělávací rámec, který využívá strukturální informace výzkumných prací a vztah mezi citačním kontextem a citovaným dokumentem pro citační klasifikaci.
Pro úkol B, citační kontext ovlivňuje klasifikaci, používáme sadu jednoduchých funkcí pro klasifikaci citací na základě jejich vnímaného významu.
Dosahujeme srovnatelného výkonu s ohledem na systémy s nejlepšími výsledky v úkolu A a nahradili jsme většinovou základní linii v úkolu B velmi jednoduchými funkcemi.
S rychlým růstem publikací ve výzkumu nabývají na významu automatizovaná řešení, která mají řešit přetížení vědeckých informací.
Správné určení záměru citací je jedním z takových úkolů, který vyhledává aplikace od předpovídání vědeckého dopadu, hledání šíření myšlenek, přes sumarizaci textu až po vytvoření informativnějších citačních indexů.
V této probíhající práci využíváme informace z citovaného dokumentu a prokazujeme, že to pomáhá při efektivní klasifikaci citačních záměrů.
Navrhujeme neurální víceúčelový vzdělávací rámec, který využívá strukturální informace z výzkumných prací a vztah mezi citačním kontextem a citovaným dokumentem pro citační klasifikaci.
Naše počáteční experimenty se třemi datovými soubory pro klasifikaci referenčních citací ukazují, že se začleněním citovaných papírových informací (názvu) náš neurální model dosahuje na datovém souboru ACL-ARC nového stavu s absolutním nárůstem F1 skóre o 5,3% oproti předchozímu nejlepšímu modelu.
Náš přístup rovněž předčí podání v rámci 3C Shared task: Citation Context Classification s nárůstem o 8 % resp. 3,6 % oproti předchozímu nejlepšímu skóre Public F1-macro a Private F1-macro.
Uvádíme ParCzech 3.0, mluvený korpus záznamů jednání Poslanecké sněmovny Parlamentu České republiky z období od 25. listopadu 2013 do 1. dubna 2021.
Na rozdíl od předchozích mluvených korpusů češtiny zachováváme nejen ortografii, ale také všechna dostupná metadata (identitu mluvčích, pohlaví, hypertextové odkazy, příslušnosti, politické strany atd.)
a doplňujeme je automatickou morfologickou a syntaktickou anotací a rozpoznáním pojmenovaných entit.
Korpus je kódován ve formátu TEI, který umožňuje přímočaré a mnohostranné využití.
Díky bohatým metadatům a anotaci je korpus relevantní pro široké spektrum výzkumníků od inženýrů v oblasti rozpoznávání řeči až po teoretické lingvisty zkoumající rétorické vzorce z rozsáhlých materiálů.
AI: Když robot píše hru.
Oslava výročí Karla Čapka.
Jak je to uděláno.
Příklady výstupů.
Pohled dramaturga.
Tento článek představuje anglicko-německé a anglicko-hauské systémy z Edinburské univerzity pro sdílenou úlohu na WMT 2021 týkající se překladu zpráv.
En-De systémy budujeme ve třech fázích: korpusové filtrování, zpětný překlad a jemné ladění.
Pro En-Ha používáme iterativní zpětný překlad přístup na vrchol předtrénovaných modelů En-De a zkoumat mapování vkládání slovní zásoby.
Dialogové systémy orientované na úkoly obvykle vyžadují manuální anotaci dialogových slotů v trénovacích datech, jejichž získání je nákladné.
Navrhujeme metodu, která tento požadavek eliminuje: K identifikaci potenciálních kandidátů na sloty využíváme slabou supervizi z existujících modelů pro lingvistickou anotaci a poté automaticky identifikujeme doménově relevantní sloty pomocí clusterovacích algoritmů.
Dále používáme výslednou anotaci slotů k natrénování taggeru založeného na neuronové síti, který je schopen provádět tagování slotů bez lidského zásahu.
Tento tagger je trénován výhradně na výstupech naší metody, a není tedy závislý na žádných označených datech.
Náš model vykazuje špičkový výkon v označování slotů bez anotovaných trénovacích dat na čtyřech různých dialogových doménách.
Kromě toho jsme zjistili, že anotace slotů zjištěné naším modelem výrazně zlepšují výkonnost end-to-end modelu pro generování odpovědi v dialogu v porovnání s modelem, který anotace slotů vůbec nepoužívá.
Toto je rozpracovaný dokument o hodnotící analýze různých přístupů k nakládání s reprezentacemi faktů a postojů v lingvistice.
Cílem této srovnávací analýzy je najít nejvhodnější přístup pro vývoj schématu anotací za účelem vybudování slovníku postojových výrazů v dalších fázích projektu.
Mezi analyzovanými přístupy jsou Appraisal Theory, schéma vyvinuté Bednárkovou a také analýza sentimentu a techniky opinion miningu a argument miningu.
Výsledky tohoto článku by měly být považovány za první krok ve výzkumu rozlišování faktů a postojů v diplomatických projevech Rady bezpečnosti OSN.
Strojový překlad je úkol automatického překládání textu z jednoho jazyka do druhého.
V posledních letech tomuto oboru dominovala řešení založená na neuronových sítích.
V této prezentaci uvedu krátký úvod k tématu a zmíním několik postupů, které lze použít ke zlepšení konečné kvality překladu.
Podělím se také o své zkušenosti z účasti na jedné z nejdéle probíhajících mezinárodních strojově překladatelských soutěží.
V této práci ukazujeme, že automaticky generované otázky a odpovědi mohou být použity k hodnocení kvality strojových překladatelských systémů.
V návaznosti na nedávnou práci na hodnocení abstraktní sumarizace textu navrhujeme novou metriku pro systémové hodnocení strojového překladu, porovnáme ji s ostatními nejmodernějšími řešeními a prokážeme její robustnost provedením experimentů pro různé překladatelské směry.
V tomto dokumentu popisujeme naši účast ve WMT 2021 Metrics Shared Task.
Automaticky generované otázky a odpovědi používáme k hodnocení kvality systémů strojového překladu.
Naše experimenty jsou založeny na nedávno navržené metodě MTEQA.
Pokusy s vyhodnocovacími datovými soubory WMT20 ukazují, že na systémové úrovni dosahuje MTEQA výkonu srovnatelného s jinými nejmodernějšími řešeními, přičemž zohledňuje je velmi omezené informace z celého překladu.
In most of neural machine translation distillation or stealing scenarios, the highest-scoring hypothesis of the target model (teacher) is used to train a new model (student).
If reference translations are also available, then better hypotheses (with respect to the references) can be oversampled and poor hypotheses either removed or undersampled.
This paper explores the sampling method landscape (pruning, hypothesis oversampling and undersampling, deduplication and their combination) with English to Czech and English to German MT models using standard MT evaluation metrics.
We show that careful oversampling and combination with the original data leads to better performance when compared to training only on the original or synthesized data or their direct combination.
Testujeme přirozené očekávání, že použití strojového překladu (MT) v profesionálním překladu ušetří lidem čas.
Poslední takovou studii provedli Sanchez-Torron a Koehn (2016) s frázovým MT, čímž uměle snížili kvalitu překladu.
My se oproti tomu zaměřujeme na vysoce kvalitní neuronový strojový překlad (NMT), který převyšuje kvalitu frázového MT a také ho přijala většina překladatelských společností.
Prostřednictvím experimentální studie, do níž se zapojilo přes 30 profesionálních překladatelů pro anglicko-český překlad, zkoumáme vztah mezi výkonem NMT a časem a kvalitou post-editace.
Ve všech modelech jsme zjistili, že lepší systémy MT skutečně vedou k menšímu počtu změn vět v tomto průmyslovém prostředí.
Vztah mezi systémovou kvalitou a dobou post-editace však není jednoznačný a na rozdíl od výsledků frázového MT není BLEU stabilním prediktorem času post-editace či konečné výstupní kvality.
End-to-end neurální systémy automatického rozpoznávání řeči dosáhly v poslední době nejmodernějších výsledků, ale vyžadují velké datové sady a rozsáhlé výpočetní zdroje.
Přenosové učení bylo navrženo k překonání těchto obtíží i napříč jazyky, např. německý ASR trénovaný podle anglického modelu.
Experimentujeme s mnohem méně příbuznými jazyky, přičemž pro české ASR znovu používáme anglický model.
Pro zjednodušení převodu navrhujeme používat přechodnou abecedu, češtinu bez přízvuků, a dokládáme, že jde o vysoce efektivní strategii.
Technika je užitečná i na samotných českých datech, ve stylu tréninku „coarse-to-fine“.
Dosahujeme podstatného zkrácení doby tréninku a také word error rate (WER).
V článku zachycujeme výsledky pilotní studie zaměřené na intenzifikátory: absolutně, naprosto a úplně.
Vycházíme ze tří korpusů současné češtiny - psaného korpusu SYN2020, webového korpusu ONLINE-ARCHIVE a mluveného korpusu ORTOFON 1.
Na základě paralelní anotace náhodného vzorku všech vybraných intenzifikátorů sledujeme funkce a významy těchto výrazů v kontextu.Cílem studie je vymezit vlastnosti, které jsou relevantní pro slovnědruhové určení zkoumaných výrazů a připravit podklady pro jejich disambiguaci.
Tento článek představuje výsledky WMT21 Metrics Shared Task.
Účastníci byli požádáni o hodnocení výstupů překladatelských systémů soutěžících v překladatelské úloze WMT21 News pomocí automatických metrik pro dvě různé oblasti: zpravodajství a TED talks.
Všechny metriky byly hodnoceny podle toho, jak dobře korelují na úrovni systému a segmentu s lidským hodnocením.
Na rozdíl od předchozích ročníků jsme letos získali vlastní lidská hodnocení na základě expertního lidského hodnocení prostřednictvím vícerozměrných metrik kvality (MQM).
Toto nastavení mělo několik výhod: (i) ukázalo se, že expertní hodnocení je spolehlivější, (ii) byli jsme schopni vyhodnotit všechny metriky na dvou různých doménách s použitím překladů stejných systémů MT, (iii) během vývoje systému jsme přidali 5 dalších překladů pocházejících ze stejného systému.
Kromě toho jsme navrhli tři sady výzev, které hodnotí robustnost všech automatických metrik.
Předkládáme rozsáhlou analýzu toho, jak dobře metriky fungují na třech jazykových dvojicích: angličtina→němčina, angličtina→ruština a čínština→angličtina.
Dále ukazujeme vliv různých referenčních překladů metriky a porovnáváme naši expertní anotaci MQM s DA skóre získanými pomocí WMT.
Dokument prezentuje nový, sjednocený morfologický popis číslovek a zájmen, který byl zkompilován pro nejnovější vydání Pražských závislostních korpusů (Prague Dependency Treebank – Consolidated 1.0) a jeho nedílnou součást je morfologický slovník MorfFlex.
Na základě zkušeností s anotací skutečných dat a s užíváním morfologického slovníku byly navrženy konkrétní změny.
Pro oba slovní druhy byl navržen nový soubor podtypů, založený zejména na morfologickém kritériu a jeho kombinaci se sémantickými vlastnostmi a dalšími relevantními rysy, jako je ne/určitost u číslovek a posesivita, reflexivita a klitičnost u zájmen.
Každý podtyp má specifickou hodnotu na 2. pozici morfologické značky, která slouží také jako ukazatel použitelnosti dalších kategorií ve značce.
Představujeme neautoregresivní přístup k opravě gramatiky založený na znacích s automaticky generovanými transformacemi znaků.
Nedávno byla jako alternativa k současným systémům pro opravu gramatiky typu enkodér-dekodér navržena klasifikace korekčních oprav jednotlivých slov.
Ukazujeme, že náhrada celých slov může být neoptimální a může vést k explozi počtu pravidel pro opravy typu překlepů, diakritizační opravy a opravy v morfologicky bohatých jazycích, a proto navrhujeme metodu pro generování transformací znaků z korpusu pro opravu gramatiky.
Dále jsme natrénovali znakové transformační modely pro češtinu, němčinu a ruštinu a dosáhli jsme solidních výsledků a dramatického zrychlení ve srovnání s autoregresivními systémy.
Zdrojový kód je zveřejněn zde: https://github.com/ufal/wnut2021_character_transformations_gec.
Představujeme RobeCzech, jednojazyčnou RoBERTu, (jazykový model) trénovaný pouze na českých datech.
RoBERTa je robustně optimalizovaný přístup pro předtrénování založený na Transformeru.
V příspěvku ukazujeme, že RobeCzech výrazně překonává podobně velké vícejazyčné i české kontextualizované modely a zlepšuje současné výsledky v pěti vyhodnocovaných úlohách automatického jazykového zpracování, přičemž dosahuje nejlepších známých výsledků ve čtyřech z nich.
Model RobeCzech je veřejně dostupný zde: https://hdl.handle.net/11234/1-3691 a zde: https://huggingface.co/ufal/robeczech-base.
Nejmodernější kontextové vložení získáváme z velkých jazykových modelů dostupných pouze pro několik jazyků.
U ostatních se musíme naučit reprezentace pomocí mnohojazyčného modelu.
Probíhá diskuse o tom, zda lze vícejazyčné vložení sladit do prostoru sdíleného v mnoha jazycích.
Ortogonální strukturální sonda (Limisiewicz a Mareček, 2021) nám umožňuje odpovědět na tuto otázku pro specifické jazykové rysy a naučit se projekci založenou pouze na jednojazyčných komentovaných datových souborech.
Hodnotíme syntaktické (UD) a lexikální (WordNet) strukturální informace zakódované v mBERT kontextové reprezentaci pro devět různých jazyků.
Pozorujeme, že u jazyků úzce spjatých s angličtinou není nutná žádná transformace.
Vyhodnocená informace je zakódována ve sdíleném mezijazyčném vkládacím prostoru.
Pro ostatní jazyky je výhodné použít ortogonální transformaci naučenou samostatně pro každý jazyk.
Úspěšně aplikujeme naše zjištění na nulovou a málo natočenou analýzu přes jazyk.
Nejmodernější kontextové vložení získáváme z velkých jazykových modelů dostupných pouze pro několik jazyků.
U ostatních se musíme naučit reprezentace pomocí mnohojazyčného modelu.
Probíhá diskuse o tom, zda lze vícejazyčné vložení sladit do prostoru sdíleného v mnoha jazycích.
Ortogonální strukturální sonda (Limisiewicz a Mareček, 2021) nám umožňuje odpovědět na tuto otázku pro specifické jazykové rysy a naučit se projekci založenou pouze na jednojazyčných komentovaných datových souborech.
Hodnotíme syntaktické (UD) a lexikální (WordNet) strukturální informace zakódované v mBERT kontextové reprezentaci pro devět různých jazyků.
Pozorujeme, že u jazyků úzce spjatých s angličtinou není nutná žádná transformace.
Vyhodnocená informace je zakódována ve sdíleném mezijazyčném vkládacím prostoru.
Pro ostatní jazyky je výhodné použít ortogonální transformaci naučenou samostatně pro každý jazyk.
Úspěšně aplikujeme naše zjištění na nulovou a málo natočenou analýzu přes jazyk.
Vzhledem k nedávnému úspěchu předcvičených modelů v NLP byla velká pozornost věnována interpretaci jejich vyjádření.
Jedním z nejvýraznějších přístupů je strukturální sondování (Hewitt a Manning, 2019), kde se provádí lineární projekce slovních vložek s cílem přiblížit topologii závislostních struktur.
Při této práci zavedeme nový typ strukturálního sondování, kdy se lineární projekce rozloží na 1. izomorfní prostorovou rotaci, 2. lineární škálování, které určí a změří nejdůležitější rozměry.
Kromě syntaktické závislosti hodnotíme naši metodu na dvou neotřelých úkolech (lexikální hypernymie a pozice ve větě).
Společně cvičíme sondy pro více úkolů a experimentálně ukazujeme, že lexikální a syntaktické informace jsou v reprezentacích odděleny.
Díky ortogonálnímu omezení jsou navíc Strukturální sondy méně náchylné k memorování.
Vzhledem k nedávnému úspěchu předcvičených modelů v NLP byla velká pozornost věnována interpretaci jejich vyjádření.
Jedním z nejvýraznějších přístupů je strukturální sondování (Hewitt a Manning, 2019), kde se provádí lineární projekce slovních vložek s cílem přiblížit topologii závislostních struktur.
Při této práci zavedeme nový typ strukturálního sondování, kdy se lineární projekce rozloží na 1. izomorfní prostorovou rotaci, 2. lineární škálování, které určí a změří nejdůležitější rozměry.
Kromě syntaktické závislosti hodnotíme naši metodu na dvou neotřelých úkolech (lexikální hypernymie a pozice ve větě).
Společně cvičíme sondy pro více úkolů a experimentálně ukazujeme, že lexikální a syntaktické informace jsou v reprezentacích odděleny.
Díky ortogonálnímu omezení jsou navíc Strukturální sondy méně náchylné k memorování
Ačkoli mobilita a pohyb získaly v poslední době na významu v interakcionistickém výzkumu společenského jednání, není příliš známo, jaké důsledky má pohyb pro konkrétní vývoj interakčních epizod.
Prostřednictvím dvou veřejně přístupných videoklipů zachycujících situace „silniční zuřivosti“ popisujeme a analyzujeme stěžejní rysy práce rukou při eskalaci a úpadku emocionálně nabité interakce mezi účastníky silničního provozu.
Vyhýbáme se apriorně kognitivistickému postoji a v detailech ukazujeme, jak může být práce rukou sama o sobě konstituentem vzteku a že může vést k otevřenému konfliktu na hranici fyzického násilí.
Tento článek zkoumá možnosti a limity lokální analýzy textové koherence s ohledem na jevy globální koherence a vyšší výstavby textu.
Pandemie Covid-19 vyvolala globální poptávku po přesných a aktuálních informacích, které často pocházejí z angličtiny a je třeba je přeložit.
K natrénování systému strojového překladu pro tak úzké téma využíváme doménová trénovací data v jiných jazycích, a to jak z příbuzných, tak ze vzdálených jazykových rodin.
Experimentujeme s různými rozvrhy učení pomocí metody transfer learning a pozorujeme, že přenos prostřednictvím více než jednoho pomocného jazyka přináší největší zlepšení.
Porovnáváme výstupy s mnohojazyčným trénováním a nacházíme lepší výsledky při použití transfer learningu.
Popisujeme naše dva NMT systémy, které byly odeslány do soutěže WMT2021 v anglicko-českém překladu zpráv: CUNI-DocTransformer (document-level CUBBITT) a CUNI-Marian-Baselines.
První z nich vylepšujeme lepším předzpracováním segmentace vět a následným zpracováním pro opravu chyb v číslech a jednotkách.
Druhý z nich používáme při experimentech s různými variantami techniky backtranslation.
Představujeme příspěvek Charles-UPF pro sdílenou úlohu o hodnocení přesnosti generovaných textů na konferenci INLG 2021.
Náš systém dokáže automaticky detekovat chyby pomocí kombinace systému pro generování přirozeného jazyka založeného na pravidlech a předtrénovaných jazykových modelů.
Nejprve využíváme systém pro generování přirozeného jazyka založený na pravidlech, který generuje fakta odvozená ze vstupních dat.
Pro každou větu, kterou vyhodnocujeme, vybereme podmnožinu faktů, které jsou relevantní na základě měření sémantické podobnosti s danou větou.
Nakonec dotrénujeme předtrénovaný jazykový model na anotovaných datech spolu s relevantními fakty pro jemnou detekci chyb.
Na testovací sadě dosahujeme 69% výtěžnosti (recall) a 75% přesnosti (precision) s modelem natrénovaným na mixu dat anotovaných lidmi a syntetických dat.
Přednáška představuje výsledky na konferenci WMT21 o překladu s velmi malým množstvím zdrojů a bez paralelních dat a soutěží příspěvek, se kterým se účastil tým LMU Mnichov.
Dále se probíráme designová rozhodnutími, která museli účastníci soutěže udělat a spekulujeme o tom, jaké by mohly být budoucí směry ve strojovém překladu překladů s malými zdroji.
Představujeme závěry soutěžního ve strojovém překladu bez paralelních data nebo s velmi málo paralelními daty na WMT2021.
V rámci tohoto úkolu se komunita zabývala strojovým překladem s velmi málo paralelními daty  mezi němčinou a hornolužickou srbštinou, překladem bez paralelních dat mezi němčinou a dolnolužickou srbštinou a překladem s málo paralelními daty mezi ruštinou a čuvašštinou, všemi menšinovými jazyky s aktivními jazykovými komunitami pracujícími na zachování těchto jazyků.
Díky tomu se nám podařilo získat většinu digitálních dat dostupných pro tyto jazyky a nabídnout je účastníkům úkolu.
Soutěžního úkolu se účastnilo celkem šest týmů.
Článek představuje úkoly a výsledky a pojednává o osvědčených postupech do budoucna.
Představujeme naše systémy pro soutěžní úkol v strojovém překladu bez paralelní dat a s velmi málo paralelními data na WMT21: mezi němčinou a hornolužickou srbštinou, němčinou a dolnolužickou srbštinou a ruštinou a čuvašštinou.
Naše nízkozdrojové systémy (němčina↔hornolužická srbština, ruština↔čuvaština) jsou předtrénovány na párech příbuzných jazyků s dostatkem data.
Tyto systémy jsme dotrénovali pomocí dostupných autentických paralelních dat a dále vylepšili opakovaným zpětným překladem.
Německo↔dolnolužický systém je inicializován nejlepším hornolužickosrbským systémem a vylepšen opakovaným zpětným překladem pouze za použití jednojazyčných dat.
Pozorujeme, že různé druhy chyb, kterých se dopouštějí systémy pro generování přirozeného jazyka, jsou velmi málo reportovány v literatuře.
To je problém, protože chyby jsou důležitým ukazatelem toho, kde by se systémy měly ještě zlepšit.
Pokud autoři uvádějí pouze celkové metriky výkonnosti, zůstává výzkumná komunita v nevědomosti o konkrétních nedostatcích v nejmodernějších přístupech.
Vedle kvantifikace rozsahu nedostatečného vykazování chyb tento článek poskytuje doporučení pro identifikaci, analýzu a vykazování chyb.
Představujeme scénář divadelní hry AI: When a Robot Writes a Play (AI: Když robot píše hru), kterou napsala umělá inteligence v rámci projektu THEaiTRE.
Vysoký výkon velkých předcvičených jazykových modelů (LLM), jako je BERT (Devlin et al., 2019) na úkoly NLP, vyvolal otázky ohledně jazykových schopností BERT a v tom, jak se liší od lidských.
V tomto příspěvku přistupujeme k této otázce zkoumáním znalostí BERT o lexikálních sémantických vztazích.
Zaměřujeme se na hypernymii, vztah „je-a“, který spojuje slovo s nadřazenou kategorií.
Jednoduše používáme metodiku nabádání zeptejte se BERTe, co je hypernym daného slova.
Zjistili jsme, že v prostředí, kde jsou všechny hypernymy uhodnutelné pomocí výzvy, BERT zná hypernymy s přesností až 57%.
Navíc BERT s výzvou překonává ostatní modely bez dozoru pro hypernomické objevování i v neomezeném scénáři.
Předpovědi a výkon BERT jsou však zapnuty soubor dat obsahující neobvyklé hyponymy a hypernymy naznačují, že jeho znalosti o hypernymii jsou stále omezené.
BERTScore (Zhang et al., 2020), nedávno navržená automatická metrika kvality strojového překladu, používá BERT (Devlin et al., 2019), velký předškolený jazykový model pro hodnocení kandidátských překladů s ohledem na zlatý překlad.
BERTScore využívá sémantických a syntaktických schopností BERT a snaží se vyhnout chybám dřívějších přístupů, jako je BLEU, místo toho hodnotí kandidátské překlady na základě jejich sémantické podobnosti se zlatou větou.
BERT však není neomylný; zatímco jeho výkon v oblasti úkolů NLP obecně nastoluje nový stav, studie specifických syntaktických a sémantických jevů ukázaly, kde se výkon BERT odchyluje od výkonu lidí obecněji.
To přirozeně vyvolává otázky, kterými se v tomto dokumentu zabýváme: jaké jsou silné a slabé stránky BERTScore?
Souvisejí s známé slabiny na straně BERT?
Zjistili jsme, že BERTScore sice dokáže odhalit, když se kandidát liší od odkazu v důležitých obsahových slovech, ale je méně citlivý na menší chyby, zejména pokud je kandidát lexikálně nebo stylisticky podobný odkazu.
V tomto příspěvku uvádíme Uniformní reprezentaci významu (UMR), navrženou k anotaci sémantického obsah textu.
UMR je primárně založena na Abstract Meaning Representation (AMR), anotačním rámci původně určeném pro angličtinu, ale čerpá i z jiných významových reprezentací.
UMR rozšiřuje AMR do dalších jazyků, obzvláště morfologicky složité jazyky s omezenými jazykovými zdroji.
UMR také přidává do AMR funkce, které jsou kritické pro sémantiku a zlepšuje AMR navržením doprovodné dokumentární reprezentace, která zachycuje jazykové jevy jako je koreference a také časové a modální závislosti, které potenciálně přesahují hranice vět.
Slovní asociace je důležitou součástí lidského jazyka.
Existuje mnoho technik pro zachycení sémantických vztahů mezi slovy, ale jejich schopnost modelovat slovní asociace je zřídka testována v reálné aplikaci.
V tomto článku hodnotíme tři modely zaměřené na různé typy slovních asociací: model pro vkládání slov pro synonymii, bodový model vzájemných informací pro slovní spojení a model závislosti pro společné vlastnosti slov.
Kvalitu navrhovaných modelů testují lidé v angličtině a češtině v online verzi slovně-asociační hry „Codenames“.
Cílem naší práce je navrhnout vhodné morfologické značky pro popis indonéštiny v rámci Universal Dependencies a aplikovat tyto značky na existující indonéský závislostní korpus.
Dávat smysl jazyku není snadný úkol.
Tím spíš, že máme tak intimní zážitek -- stromy, se kterými se pravidelně setkáváme v každodenní komunikaci, nám mohou znesnadnit výhled na les.
V této situaci nám počítače mohou pomoci udělat krok zpět a podívat se na velké množství textu z odstupu padesáti tisíc stop.
Tento článek popisuje vyjádření týmu („ODIANLP“) k WAT 2020.
Účastnili jsme se úkolu English→Hindi Multimodal a Indic.
Pro úlohu překladu jsme použili nejmodernější model Transformeru a pro úlohu Hindi Image Captioning jsme použili Inception ResNetV2.
Naše podání dosahuje nejlepších výsledků ve směru English→Hindi Multimodal a Odia↔English.
Naše návrhy si vedly dobře i při vícejazyčných úkolech (Indic).
Příprava paralelních korpusů je náročným úkolem, zejména pro jazyky, které trpí nedostatečným zastoupením v digitálním světě.
Ve vícejazyčné zemi, jako je Indie, je potřeba takových paralelních korpusů přísná pro několik jazyků s nízkými zdroji.
V této práci poskytujeme rozšířený anglicko-odijský paralelní korpus OdiEnCorp 2.0 zaměřený zejména na systémy Neural Machine Translation (NMT), které pomohou přeložit angličtinu ↔ Odia.
OdiEnCorp 2.0 zahrnuje stávající anglicko-odijské korpusy a sbírku jsme rozšířili o několik dalších metod získávání dat: paralelní škrábání dat z mnoha webů, včetně Odia Wikipedia, ale také optické rozpoznávání znaků (OCR) pro extrakci paralelních dat ze skenovaných obrázků.
Náš přístup k extrakci dat založený na OCR pro vytváření paralelního korpusu je vhodný pro jiné jazyky s nízkými zdroji, které nemají online obsah.
Výsledný OdiEnCorp 2.0 obsahuje 98 302 vět a 1,69 milionu anglických a 1,47 milionu žetonů Odia.
Pokud je nám známo, OdiEnCorp 2.0 je největší Odia-anglický paralelní korpus pokrývající různé domény a je volně dostupný pro nekomerční a výzkumné účely.
V tomto článku představujeme první treebank Universal Dependencies (UD) pro spisovnou albánštinu, sestávající z 60 vět vybraných z albánské Wikipedie, anotovaných lematy, univerzálními značkami slovních druhů, morfologickými rysy a syntaktickými závislostmi.
Kromě představení treebanku jako takového probíráme vybrané jazykové jevy v albánštině, jejichž analýza v UD není na první pohled jasná, včetně jádrových argumentů, zacházení s nepřímými předměty, zájmenných příklonek, konstrukcí s genitivem, preartikulovaných adjektiv a způsobových sloves.
Představujeme PERIN, nový permutačně invariantní přístup k sémantickému parsingu věty na graf.
PERIN je všestranná, anotačně a jazykově nezávislá architektura pro univerzální modelování sémantických struktur.
Náš systém se zúčastnil shared tasku CoNLL 2020, Cross-Framework Meaning Representation Parsing (MRP 2020), kde byl hodnocen v pěti různých frameworcích (AMR, DRG, EDS, PTG a UCCA) napříč čtyřmi jazyky.
PERIN byl jedním z vítězů.
Zdrojový kód a předtrénované modely jsou k dispozici na adrese http://www.github.com/ufal/perin.
Mnohojazyčnost je kulturním úhelným kamenem Evropy a je pevně zakotvena v evropských smlouvách, včetně úplné jazykové rovnosti.
Jazykové bariéry ovlivňující obchodní, mezijazykovou a mezikulturní komunikaci jsou však stále všudypřítomné.
Jazykové technologie (LT) jsou mocným prostředkem k prolomení těchto bariér.
I když v posledním desetiletí vzniklo množství různých iniciativ, které vytvořily množství přístupů a technologií přizpůsobených specifickým potřebám Evropy, stále existuje obrovská míra roztříštěnosti.
Zároveň se umělá inteligence (AI) stala stále důležitějším konceptem v oblasti evropských informačních a komunikačních technologií.
Už několik let AI – včetně mnoha příležitostí, synergií, ale i mylných představ – zastiňuje všechna ostatní témata.
Představujeme přehled evropského prostředí jazykových technologí (LT), popisujeme programy financování, činnosti, akce a výzvy v jednotlivých zemích s ohledem na LT, včetně současného stavu v průmyslu a na trhu LT.
Představujeme stručný přehled hlavních činností souvisejících s LT na úrovni EU za posledních deset let a představujeme strategické pokyny s ohledem na čtyři klíčové rozměry.
S 24 oficiálními jazyky EU a mnoha dalšími jazyky může být mnohojazyčnost v Evropě a inkluzivní jednotný digitální trh umožněn pouze prostřednictvím jazykových technologií (LT).
Evropské LT podnikání ovládají stovky malých a středních podniků a několik velkých hráčů.
Mnohé z nich jsou světové, s technologiemi, které předčí globální hráče.
Evropské podnikání v LT je však také roztříštěné – v závislosti na národních státech, jazycích, vertikálech a odvětvích, což výrazně brzdí jeho dopad.
Projekt evropské jazykové sítě (European Language Grid, ELG) řeší tuto roztříštěnost tím, že stanoví ELG jako primární platformu pro LT v Evropě.
Skupina ELG je rozšiřitelná cloudová platforma, která umožňuje snadnou integraci přístupu ke stovkám komerčních i nekomerčních LT pro všechny evropské jazyky, včetně provozních nástrojů a služeb, jakož i datových souborů a zdrojů.
Jakmile bude plně funkční, umožní komerční i nekomerční evropské komunitě LT ukládat a nahrávat své technologie a soubory dat do systému ELG, zavádět je do sítě a propojovat s dalšími zdroji.
Skupina ELG podpoří vícejazyčný jednotný digitální trh směrem k prosperující evropské LT komunitě a vytvoří nová pracovní místa a příležitosti.
Kromě toho projekt ELG organizuje dvě otevřené výzvy až pro 20 pilotních projektů.
Zřizuje také 32 národních kompetenčních center a Evropskou radu LT pro osvětové a koordinační účely.
Strojový překlad:  Některé metody automatického simultánního převodu řeči dlouhé formy umožňují revize výstupů, přesnost obchodování pro nízkou latenci.
Zavádění těchto systémů uživatele čeká problém s prezentací titulků v omezeném prostoru, jako jsou dva řádky na televizní obrazovce.
The titulky musí být zobrazeny okamžitě, postupně a s dostatečný čas na čtení.
Poskytujeme algoritmus pro titulkování.
Dále navrhujeme způsob, jak odhadnout celková využitelnost kombinace automatického překladu a titulkování měřením kvality, latence a stabilitu na testovací sadě a navrhnout vylepšené opatření kvůli zpoždění překladu.
Tento abstrakt je pouze v angličtině:  This paper is an ELITR system submission for the non-native speech translation task at IWSLT 2020.
We describe systems for offline ASR, real-time ASR, and our cascaded approach to offline SLT and real-time SLT.
We select our primary candidates from a pool of pre-existing systems, develop a new end-to-end general ASR system, and a hybrid ASR trained on non-native speech.
The provided small validation set prevents us from carrying out a complex validation, but we submit all the unselected candidates for contrastive evaluation on the test set.
Zkoumáme vliv trénování modelů NMT na více cílových jazyků.
Předpokládáme, že integrace více jazyků a zvýšení jazykové rozmanitosti povedou k silnějšímu zastoupení syntaktických a sémantických rysů zachycených modelem.
Testujeme naši hypotézu na dvou různých architekturách NMT: široce používaná architektura transformátorů a architektura Attention Bridge.
Trénujeme modely na datech Europarl a kvantifikujeme úroveň syntaktických a sémantických informací objevených modely pomocí tří různých metod: úkoly lingvistického průzkumu SentEval, analýza struktur pozornosti týkající se inherentních informací o frázích a závislostech a strukturální sonda na kontextových reprezentacích slov .
Naše výsledky ukazují, že s rostoucím počtem cílových jazyků model Attention Bridge stále více získává určité jazykové vlastnosti, včetně některých syntaktických a sémantických aspektů věty, zatímco transformátorské modely jsou do značné míry nedotčeny.
Posledně uvedené platí také pro frázovou strukturu a syntaktické závislosti, které se při zvyšování jazykové rozmanitosti při výcviku překladu nejeví ve větných vyjádřeních.
To je docela překvapivé a může to naznačovat relativně malý vliv gramatické struktury na porozumění jazyku.
V posledních letech dominovaly hluboké neuronové sítě v oblasti zpracování přirozeného jazyka (NLP).
Modely trénované od konce do konce mohou dělat úkoly stejně zručně jako nikdy předtím a rozvíjet vlastní vyjádření jazyka.
Působí však jako černé skříňky, které je velmi těžké interpretovat.
To vyžaduje kontrolu, do jaké míry jsou jazykové koncepce v souladu s tím, co se modely učí.
Používají neuronové sítě morfologii a syntaxi stejně jako lidé, když mluví o jazyce?
Nebo si vyvinou vlastní způsob?
V naší přednášce pootevřeme neurální černou skříňku a zanalyzujeme vnitřní reprezentace vstupních vět s ohledem na jejich morfologické, syntaktické a sémantické vlastnosti.
Zaměříme se na embedinky slov i kontextové embedinky a sebepozornost modelů Transformer (BERT, NMT).
Ukážeme jak řízené, tak i neřízené postupy analýzy.
Tento článek představuje podrobnou analýzu první soutěže v end-to-end generování přirozeného jazyka (NLG) a na základě jejích výsledků naznačuje směr budoucího výzkumu.
Cílem této soutěže úkolu bylo posoudit, zda moderní end-to-end systémy NLG mohou generovat komplexnější výstup, jsou-li natrénovány z dat lexikálně bohatších, syntakticky složitějších a zahrnujících různé diskurzní jevy.
S použitím nových automatických a lidských metrik porovnáváme 62 systémů zaslaných do soutěže 17 institucemi, které zahrnují širokou škálu přístupů, včetně architektur strojového učení – kde většina implementací jsou modely typu sequence-to-sequence (seq2seq) – i systémů založených na gramatických pravidlech a šablonách.
Systémy založené na architektuře seq2seq ukázaly v této souteži velký potenciál pro NLG.
Zjistili jsme, že seq2seq systémy mají obecně vysoké skóre, pokud jde o metriky založené na překryvu slov a lidské hodnocení přirozenosti/plynulosti; vítězný systém Slug (Juraska et al., 2018) je založený na seq2seq.
Základní modely typu seq2seq však často nedokážou správně vyjádřit vstupný reprezentaci významu, pokud postrádají silný mechanismus sémantické kontroly použitý během dekódování.
Modely seq2seq mohou být navíc překonány ručně vytvořenými systémy z hlediska celkové kvality, jakož i složitosti, délky a rozmanitosti výstupů.
Tento výzkum ovlivnil, inspiroval a motivoval řadu nedávných studií mimo původní soutěž, které v článku rovněž shrnujeme.
Velkým problémem v evaluaci systémů pro generování textu z dat (D2T) je jak změřit sémantickou přesnost vygenerovaného textu, tj.
jeho věrnost vstupním datům.
Navrhujeme novou metriku pro evaluaci sémantické přesnosti D2T generování založené na neuronovém modelu předtrénovaném na úlohu automatické jazykové inference (NLI).
Pomocí modelu NLI kontrolujeme, zda generovaný text vyplývá (entailment) z dat a opačně, což nám dovoluje odhalit vynechané části dat nebo halucinované (daty nepodložené) části vygenerovaného textu.
Vstupní data pro model NLI převádíme do textu pomocí triviálních šablon.
Naše experimenty na dvou běžně užívaných datových sadách pro D2T ukazují, že naše metrika dokáže dosáhnout vysoké přesnosti při identifikaci chybných výstupů generátorů.
Tato práce představuje výsledky překladatelských úloh týkajících se zpravodajských textů a podobného úkolu překladů jazyků, obojí organizováno v rámci Conference on Machine Translation (WMT) 2020.
V úkolu týkajícím se zpravodajských textů byli účastníci požádáni o sestavení systémů strojového překladu pro kterýkoli z 11 jazykových párů, které budou hodnoceny na testovacích souborech sestávajících hlavně z reportáží.
Úloha byla také otevřena pro další testovací sady, aby se daly  zkoumat specifické aspekty překladu.
V další úloze účastníci sestavili systémy strojového překladu pro překládání mezi úzce příbuznými páry jazyků.
Přestože nové neuronové modely typu sequence-to-sequence neurální značně zlepšily kvalitu syntézy řeči, dosud neexistuje systém schopný rychlého trénování, rychlé inference a zároveň vysoce kvalitní syntézy.
Navrhujeme dvojici sítí typu učitel-student, která je schopna vysoce kvalitní syntézy spektrogramu rychleji než v reálném čase, s nízkými požadavky na výpočetní zdroje a rychlým trénováním.
Ukazujeme, že vrstvy typu self-attention nejsou pro generování vysoce kvalitní řeči nutné.
Jak v učitelské, tak ve studentské síti využíváme jednoduché konvoluční bloky s reziduálním propojením; používáme pouze jednu vrstvu attention v učitelském modelu.
Ve spojení s hlasovým kodérem MelGAN byla hlasová kvalita našeho modelu hodnocena signifikantně lépe než Tacotron 2.
Náš model může být efektivně trénován na jednom GPU a může běžet v reálném čase i na CPU.
Zdrojový kód i zvukové ukázky poskytujeme na našem úložišti na GitHubu.
V češtině – podobně jako v jiných slovanských jazycích – může mít klitické reflexivum funkci slovotvorného formantu, derivujícího lexikální reciproční slovesa, tedy  slovesa obsahující rys vzájemnosti již ve svém lexikálním významu.
V článku rozlišuji mezi lexikálními recipročními slovesy, u nichž rys vzájemnosti vyjadřuje klitické reflexivum (např. nenávidět se ← nenávidět, slíbit si ← slíbit), a lexikálními recipročními slovesy, u nichž má klitické reflexivum jinou funkci (např. oddělit se ← oddělit).
Lexikální reciproka prvního typu vytvářejí konstrukce, u nichž se participanty ve vztahu vzájemnosti vyjadřují typicky v subjektové pozici a v pozici nepřímého objektu, vyjádřeného instrumentálem.
Ukazuji však, že tato slovesa tvoří sémantické skupiny, které se do značné míry sémanticky překrývají s dalšími typy lexikálních recipročních sloves.
V tomto příspěvku se věnujeme způsobům vyjadřování vzájemnost v českých konstrukcích s kategoriálními slovesy.
Reciprocitu do těchto konstrukcí vnáší prediktivní substantiva, neboť ta představují jejich sémantické jádro.
Zaměřujeme se na reciproční konstrukce s kategoriálními slovesy, které vznikají odvozením syntaktickou operací reciprokalizace.
Ukazujeme, že komplexní mapování sémantických participantů na valenční doplnění  charakteristické pro reciprocitu se zachovává i v recipročních konstrukcích s kategoriálními slovesy.
Hlavní rozdíl mezi recipročními nominálními konstrukcemi a recipročními konstrukcemi s kategoriálním slovesem spočívá v morfosyntaktickém vyjádření reciprokalizovaných participantů.
Ukazujeme, že povrchové syntaktické změny v recipročních konstrukcích s kategoriálními slovesy jsou natolik pravidelné, že je lze popsat pomocí pravidel, a to  pravidel pro hlubokou a povrchovou tvorbu syntaktických struktury s kategoriálním slovesem a pravidel pro tvoření recipročních konatrukcí.
Nedávný pokrok v neuronovém strojovém překladu směřuje k větším sítím trénovaným na stále větším množství hardwarových zdrojů.
V důsledku toho jsou modely NMT nákladné na trénování, a to jak finančně, kvůli nákladům na elektřinu a hardware, tak ekologicky, kvůli uhlíkové stopě.
Zvláště to platí v transferu znalostí při trénování modelu "rodiče" před přenesením znalostí do požadovaného modelu "dítě".
V tomto článku navrhujeme jednoduchou metodu opakovaného použití již natrénovaného modelu pro různé jazykové páry, u nichž není nutné upravovat modelovou architekturu.
Náš přístup nepotřebuje samostatný model pro každou zkoumanou dvojici jazyků, jak je to typické v rámci přenosového učení u neuronového strojového překladu.
Abychom ukázali použitelnost naší metody, recyklujeme model Transformeru, který natrénovali jiní vyzkumníci a použijeme ho pro různé jazykové páry.
Naše metoda dosahuje lepší kvality překladu a kratších časů konvergence, než když trénujeme z náhodné inicializace.
Genderová zaujatost ve strojovém překladu se může projevit při výběru genderových modulací na základě falešných genderových korelací.
Například vždy překládat lékaře jako muže a sestry jako ženy.
To může být obzvláště škodlivé, protože modely se stávají populárnějšími a jsou zaváděny v rámci komerčních systémů.
Naše práce představuje největší důkaz tohoto jevu ve více než 19 systémech předložených WMT ve čtyřech různých cílových jazycích: češtině, němčině, polštině a ruštině.K dosažení tohoto cíle používáme WinoMT, nedávnou automatickou testovací sadu, která zkoumá genderovou korektnost a zkreslení při překladu z angličtiny do jazyků s gramatickým pohlavím.
Bývalí pracovníci WinoMT se starají o dva nové jazyky testované ve WMT: polštinu a češtinu.
Zjistili jsme, že všechny systémy důsledně používají nepravdivé korelace v datech spíše než smysluplné kontextové informace.
CLARIN je evropská výzkumná infrastruktura, která poskytuje přístup k digitálním jazykovým zdrojům a nástrojům z celé Evropy i mimo ni výzkumným pracovníkům v humanitních a sociálních vědách.
Tento dokument se zaměřuje na CLARIN jako platformu pro sdílení jazykových zdrojů.
Přibližuje nabídku služeb pro agregaci jazykových úložišť a návrh hodnot pro řadu komunit, které těží z větší viditelnosti svých údajů a služeb v důsledku integrace do CLARIN.
Zvýšená jemnost jazykových zdrojů slouží celé komunitě společenských a humanitních věd (SSH) a podporuje výzkumné komunity, které usilují o spolupráci založenou na virtuálních sbírkách pro určitou oblast.
Dokument se také zabývá širším prostředím platforem služeb založených na jazykových technologiích, které mají potenciál stát se silným souborem interoperabilních zařízení pro nejrůznější využití.
V této studii zkoumáme možné výhody využití informací z eye trackeru pro analýzu závislostní syntaxe na anglické části Dundee corpu.
Abychom toho dosáhli, zavedeme parsing jako úlohu značkování sekvencí a pak rozšiřujeme neurální model pro značkování sekvencí o rysy z eye trackeru.
Poté experimentujeme s různými nastaveními analyzátorů od lexikalizovaného parsingu po delexikalizovaný parser.
Naše experimenty ukazují, že u lexikalizovaného parseru, i když jsou zlepšení pozitivní, nejsou statisticky významná, zatímco náš delexikalizovaný parser statisticky významně překonává baseline, kterou jsme stanovili.
Analyzujeme také přínos různých rysů z eye trackeru k různým nastavením analyzátoru a zjišťujeme, že rysy z eye trackeru obsahují informace, které se svou povahou doplňují, což znamená, že rozšíření analyzátoru o různé rysy z eye trackeru seskupené dohromady poskytuje lepší výkon než jakýkoli jednotlivý prvek.
Představujeme náš příspěvek do společné úlohy SIGTYP 2020 v předpovídání typologických rysů.
Náš systém je patří do omezené části soutěže, neboť používá pouze databázi WALS.
Zkoumáme dva přístupy.
Jednodušší z nich je založen na odhadu korelace mezi hodnotami rysů u stejného jazyka pomocí podmíněných pravděpodobností a vzájemné informace.
Druhý přístup je založen na neuronovém prediktoru, který využívá vektorovou reprezentaci jazyků předpočítanou na rysech z WALS.
Ve výsledném systému oba přístupy kombinujeme s využitím jejich vlastního odhadu důvěryhodnosti předpovědi.
Na testovacích datech dosahujeme úspěšnosti 70,7 %.
Deep Universal Dependencies (hluboké univerzální závislosti) je sbírka treebanků poloautomaticky odvozených z Universal Dependencies.
Obsahuje přídavné hloubkově-syntaktické a sémantické anotace.
Verze Deep UD odpovídá verzi UD, na které je založena.
Mějte však na paměti, že některé treebanky UD nebyly do Deep UD zahrnuty.
Více než 50 let se výzkumníci pokouší naučit počítače číst hudební notaci, kterýžto obor se nazývá rozpoznávání notopisu (Optical Music Recognition, OMR).
Do tohoto oboru je však pro začínající výzkumníky stále obtížné proniknout, obzvlášť pokud nemají nezanedbatelné hudební znalosti: je málo materiálů do problematiky uvádějících, a navíc se sám obor průběžně nedokáže shodnout na tom, jak sebe sama definovat a jak vybudovat sdílenou terminologii.
V článku se těmto nedostatkům věnujeme: (1) formulujeme robustní definici OMR a vztahů k příbuzným oborům, (2) analyzujeme, jak OMR invertuje proces zapisování hudby, aby získalo z dokumentu popis hudební notace a hudební sémantiky, a (3) předkládáme taxonomii OMR, především novou taxonomii aplikací.
Dále diskutujeme, jak hluboké učení ovlivňuje současný výzkum OMR v kontrastu s předchozími přístupy.
Na základě tohoto článku by měl čtenář získat základní porozumění OMR: jeho cílům, jeho vnitřní struktuře, vztahům k ostatním oborům, stavu poznání a výzkumných příležitostí, které OMR poskytuje.
V tomto článku představujeme novou vyhlepšenou verzi vyhledávače a vizualizátoru slovotvorných sítí DeriSearch.
Slovotvorné sítě jsou datové sady zachycující derivační, kompoziční a jiné slovotvorné vztahy mezi slovy.
Jsou reprezentovatelné pomocí orientovaných grafů, ve kterých uzly představují slova a orientované hrany mezi nimi vyjadřují slovotvorné vztahy.
Některé sítě navíc obsahují další lingvistické anotace, například segmentaci slov na morfémy nebo identifikaci slovotvorných procesů.
Sítě pro morfologicky bohaté jazyky s produktivním odvozováním a skládáním mají velké komponenty souvislosti, které se obtížně vizualizují.
Například v DeriNetu 2.0, jedné ze sítí pro češtinu, je 1/8 slovníku obsažena v komponentách souvislosti velkých přes 500 slov.
V síti Word Formation Latin pro latinu je přes 10 000 slov (1/3 slovníku) v jediné komponentě.
S nedávným vydáním souboru slovotvorných sítí pro více jazyků Universal Derivations potřeba nástroje pro vyhledávání a vizualizaci takto komplexních dat dále vzrůstá.
Autoři se zabývají právními otázkami týkajícími se tvorby a používání jazykových modelů.
Článek začíná vysvětlením vývoje jazykových technologií.
Autoři analyzují technologický postup v rámci autorského práva, práv s ním souvisejících a práva na ochranu osobních údajů.
Autoři se věnují také komerčnímu využití jazykových modelů.
Hlavním argumentem autorů je, že právní omezení vztahující se na jazykové údaje obsahující materiály a osobní údaje chráněné autorským právem se obvykle nevztahují na jazykové modely.
Jazykové modely nejsou obvykle považovány za odvozená díla.
Vzhledem k široké škále jazykových modelů není tato pozice absolutní.
„Large Scale Colloquial Persian Dataset“ (LSCP) je hierarchicky uspořádán do asemantické taxonomie, která se zaměřuje na víceúčelové neformální porozumění perskému jazyku jako komplexní problém.
LSCP zahrnuje 120 milionů vět z 27 milionů příležitostných perských tweetů se svými závislostními vztahy ve syntaktické anotaci, tagy řeči, polaritu sentimentu a automatický překlad původních perských vět do pěti různých jazyků (EN, CS, DE, IT, HI).
Rozpoznávání jazyků v posledních letech významně pokročilo pomocí moderních metod strojového učení, jako je deep learning a měřítka s bohatými anotacemi.
Výzkum je však ve formálních jazycích s nízkými zdroji stále omezený.
Skládá se z významná mezera v popisu hovorového jazyka, zejména pro ty s nízkými zdroji, jako je perština.
Aby bylo možné tuto mezeru zacílit pro jazyky s nízkými zdroji navrhujeme „Large Scale Colloquial Persian Dataset“ (LSCP).
LSCP je hierarchicky uspořádán do a sémantická taxonomie, která se zaměřuje na víceúčelové neformální porozumění perskému jazyku jako komplexní problém.
To zahrnuje uznání několika sémantických aspektů ve větách na lidské úrovni, které přirozeně zachycuje z vět z reálného světa.
Věříme, že další vyšetřování a zpracování, stejně jako aplikace nových algoritmů a metod, může posílit obohacení počítačového porozumění a zpracování jazyků s nízkými zdroji.
Navrhovaný korpus se skládá ze 120 milionů vět vycházejících z 27 milionů tweetů anotovaných stromem analýzy, tagy řeči, polaritou sentimentu a překladem do pěti různých jazyků.
V této práci navrhujeme algoritmus pro indukci morfologických sítí pro perštinu a turečtinu.
Algoritmus využívá slovníky s morfematickou segmentací.
Výsledná síť zachycuje jak derivační, tak flektivní relace.
Algoritmus pro indukci sítě vychází buď z automaticky rozlišených afixů a kořenů, nebo z jednoduché klasifikační heuristiky.
Obě varianty jsou empiricky vyhodnoceny.
Pro perštinu používáme vlastní velký ručně segmentovaný slovník, pro turečtinu menší slovník publikovaný dříve.
Ručně anotovaná data jsou algoritmem využita pro inicializaci sítě, která je následně rozšířena o formy pozorované v korpusech.
Slovní formy, které nebyly přítomny v ručně anotovaných datech, segmentujeme řízenou i neřízenou verzí segmentačního nástroje Morfessor a nástrojem MorphSyn.
Experimentální výsledky ukazují, jak inicializace ručně segmentovanými daty ovlivňuje finální kvalitu vygenerovaných sítí.
V tomto článku je představena COSTRA 1.0, dataset komplexních transformací vět.
Dataset je určen ke studiu větných embeddingů nad rámec jednoduchých výměn slov nebo standardních parafrází.
COSTRA 1.0 obsahuje pouze věty v češtině, ale metoda konstrukce je univerzální a plánujeme ji použít i pro jiné jazyky.
Dataset obsahuje 4262 unikátních vět s průměrnou délkou 10 slov, ilustrujících 15 typů úprav, jako je zjednodušení, zobecnění nebo formální a neformální jazykové variace.
Doufáme, že s tímto datovým souborem bychom měli být schopni otestovat sémantické vlastnosti větných embeddingů a možná dokonce najít nějaké topologicky zajímavé '' kostry '' v prostoru větných embeddingů.
Předběžná analýza s využitím mnohojazyčných větných embeddingů LASER naznačuje, že nevykazuje požadované vlastnosti
V tomto článku představujeme nový dataset pro testování geometrických vlastností prostorů vět.
Zaměřujeme se zejména na to, jak jsou v rámci větných embeddingů interpretovány komplexní jevy, jako jsou parafrázy, časy nebo zobecnění.
Dataset je přímým rozšířením Costra 1.0, kterou jsme obohatili o další vět a jejich porovnání.
Ukazujeme, že dostupným předtrénovaným větným embeddingům chybí základní předpoklad, aby synonymní věty byly zanořeny blíže k sobě než věty s výrazně odlišným významem.
Na druhou stranu se zdá, že některé embeddingy respektují lineární pořadí větných jevů jako je styl (formálnost a jednoduchost jazyka) nebo čas (minulost do budoucnosti).
Porovnáváme dva základní přístupy k vícejazyčnému vyhledávání informací: překlad dokumentů (DT) a překlad dotazů (QT).
Naše experimenty jsou prováděny na datech CLEF eHealth 2013–2015, které obsahují anglické dokumenty a dotazy v několika evropských jazycích.
S použitím Statistického strojového překladu (SMT) a Neurálního strojového překladu (NMT) a trénujeme několik systémů strojového překladu pro překlad neanglických dotazů do angličtiny (QT) a anglických dokumentů do jazyků dotazů (DT).
Výsledky ukazují, že kvalita QT pomocí SMT je dostatečná k překonání výsledků vyhledávání s DT pro všechny jazyky.
NMT pak dále zvyšuje kvalitu překladu a kvalitu vyhledávání pro QT i DT pro většinu jazyků, QT ale stále poskytuje obecně lepší výsledky vyhledávání než DT.
Výzkumní pracovníci Univerzity Karlovy, Švandova divadla a Akademie múzických umění v Praze v současné době pracují na zajímavém výzkumném projektu, který spojuje umělou inteligenci a robotiku s divadlem.
Hlavním cílem jejich projektu je využít umělou inteligenci k vytvoření inovativního divadelního představení, které by mělo mít premiéru v lednu 2021.
Představujeme přístup k vícejazyčné syntéze řeči, který využívá koncepce meta-učení  – generování parametrů na základě kontextu – a produkuje přirozeně znějící vícejazyčnou řeč s využitím více jazyků a méně trénovacích dat než předchozí přístupy.
Náš model je založen na Tacotronu 2 s plně konvolučním enkodérem vstupního textu, jehož váhy jsou predikovány samostatnou sítí – generátorem parametrů.
Pro zlepšení klonování hlasu napříč jazyky náš model používá adversariální klasifikaci mluvčího s vrstvou obracející gradienty, která z enkodéru odstraňuje informace specifické pro daného mluvčího.
Provedli jsme dva experimenty, abychom náš model porovnali s baseliny používajícími různé úrovně sdílení parametrů napříč jazyky a přitom vyhodnotili: 1) stabilitu a výkonnost při trénování na malém množství dat, 2) přesnost výslovnosti a kvalitu hlasu při code-switchingu (změně jazyka uprostřed věty).
Pro trénování jsme použili dataset CSS10 a náš nový malý dataset založený na nahrávkách Common Voice v pěti jazycích.
Ukazujeme, že náš model efektivně sdílí informace napříč jazyky a podle subjektivní evaluace vytváří přirozenější a přesnější vícejazyčnou řeč než baseliny.
Ve svém projevu shrnu naše nedávné aktivity v překladu textu a řeči.
Začnu projektem EU ELITR (https://elitr.eu/), kde se zaměřujeme na vysoce mnohojazyčný živý překlad řeči, který upozorňuje na technické problémy (pravděpodobně je všechny znáte), ale dotknu se i toho, jak získat lepší vstupy od koncových uživatelů, aby byla možná lepší kvalita překladu (naše aktivita na "odchozím překladu" v projektu EU Bergamot, https://browser.mt/).
Na závěr požádám o spolupráci na svém celkovém úkolu základního výzkumu: správně určit význam a modelovat ho lidštějším způsobem.
Strojový překlad:  Projekt ELITR (European Live Translator) usiluje o vytvoření systému pro překlad řeči pro současné titulkování konferencí a on-line schůzky až do 43 jazyků.
Technologii testuje společnost Nejvyššího kontrolního úřadu ČR a prostřednictvím alfaview®, německého online konferenční systém.
Další cíle projektu mají posunout úroveň dokumentů a vícejazyčný strojový překlad, automatický rozpoznávání řeči a shrnutí setkání.
MorfFlex CZ 2.0 je český morfologický slovník, který původně vyvinul Jan Hajič jako slovník kontroly pravopisu a lemmatizace.
MorfFlex je seznam trojic lemma-značka-slovní forma.
Pro každou slovní formu je kompletní morfologická informace kódována poziční značkou.
Slovní formy jsou uspořádány do skupin (paradigma instancí nebo paradigmat ve zkratce) podle jejich formálního morfologického chování.
Paradigma (množina slovník forem) je identifikováno jedinečným lemmatem.
Kromě tradičních morfologických kategorií obsahuje popis také některé sémantické, stylistické a odvozené informace.
Bohatě anotovaný a žánrově diverzifikovaný jazykový zdroj, Prague Dependency Treebank - Consolidated 1.0 (PDT-C 1.0) je konsolidovaným vydáním stávajících PDT-korpusů s českými texty, jednotně anotovanými podle standardního anotačního schématu PDT.
Korpusy zahrnuté do vydání PDT-C: Prague Dependency Treebank (psané noviny a texty časopisů tří žánrů); Česká část Prague Czech-English Dependency Treebank (přeložené finanční texty, z angličtiny), Prague Dependency Treebank of Spoken Czech (mluvená data, včetně audia a přepisu a anotace rekonstrukce řeči); PDT-Faust (texty generované uživateli).
Rozdíl oproti samostatně publikovaným původním korpusům lze stručně popsat následovně: korpusy jsou publikovány v jednom balíčku, aby bylo umožněno jejich snadnější zpracování; data jsou doplněna o manuální lingvistickou anotaci na morfologické rovině a je přiložena nová verze morfologického slovníku; je přiložen společný valenční lexikon pro všechny čtyři původní části.
Dokumentace poskytuje dva nástroje pro procházení a úpravy  (TrEd a MEd) a korpus je také k dispozici online pro vyhledávání pomocí PML-TQ.
V článku analyzujeme adverbiální určení s časovým významem se zvláštním důrazem na jejich formální realizaci.
Tradiční klasifikace významů podle toho na jakou otázku adverbiální určení odpovídá (Kdy?, Od kdy?, Do kdy?, Jak dlouho?, Jak často?)
vyžaduje přesnější subkategorizaci.
Pro primární časové výrazy, které odpovídají na otázky Kdy?
a Jak dlouho?, je navržen systém subfunktorů, zatímco pro sekundární významy Od kdy?, Do kdy?, nejsou odpovídající funktory rozděleny na subfunktory.
Významy spojené s opakováním a frekvencí zde nejsou diskutovány, protože patří k popisu hranice mezi lexikonem a gramatikou.
Nekrolog věnovaný životu a dílu zesnulého profesora Petra Sgalla, zakladatele počítačové lingvistiky v Československu, člena Pražského lingvistického kroužku.
Analýza tzv. fokalizátorů, tj.
částic jako jsou anglické also, only, even, a jejich českých protějšků také, jenom, dokonce, vycházející z údajů anglicko-českého paralelního korpusu PCEDT, zaměřená na (i) za jakých podmínek lze o těchto fokalizátorech říci, že slouží jako diskurzní konektory, (ii) které konkrétní diskurzní vztahy jsou dotyčnými fokalizátory značeny.
Naše podrobná analýza dat z anglicko-českého anotovaného paralelního korpusu PCEDT potvrzuje hypotézu, že anglické částice also, only a even i jejich české ekvivalenty hrají v zásadě diskurzivní roli explicitních konektorů, i když jiným způsobem a v jiné míře.
Tento dokument shrnuje závěry tříleté studie o slovesných synonymech v překladu, založené na syntaktických i sémantických kritériích.
Primárními jazykovými zdroji jsou stávající české a anglické lexikální a korpusové zdroje, konkrétně valenční lexikony ve stylu Pražského závislostního korpusu, FrameNet, VerbNet, PropBank, WordNet a paralelní Pražský česko-anglický závislostní korpus.
Výsledný lexikon slovesných synonym (dříve nazývaný CzEngClass, nyní SynSemClass) a všechny související zdroje spojené se stávajícími lexikony  jsou veřejně a volně dostupné.
Projekt samotný sice předpokládá ruční práci s anotacemi, ale předpokládáme, že výsledný zdroj (spolu se stávajícími) použijeme jako nezbytný zdroj pro vývoj automatických metod rozšíření takového lexikonu nebo vytvoření podobných lexikonů pro další jazyky.
CzeDLex je elektronický slovník českých diskurzních konektorů s daty pocházejícími z velkého korpusu anotovaného diskurzními vztahy.
Jeho nová verze CzeDLex 0.6 přináší podstatně větší podíl ručně zpracovaných položek.
Struktura slovníku byla upravena, aby umožňovala výskyt primárních konektorů s více položkami pro jeden diskurzní typ.
Představujeme novou verzi slovníku a ukazujeme možnosti vyhledávání různých typů informací ve slovníku pomocí PML-Tree Query.
Mnohé lingvistické teorie a anotační projekty obsahují hloubkově-syntaktickou a/nebo sémantickou rovinu.
I když většina z těchto projektů mířila na více než jeden jazyk, žádný z nich se ani zdaleka neblíží počtu jazyků, které jsou pokryté projektem Universal Dependencies (UD).
Ve své přednášce nejprve proberu tzv. rozšířené univerzální závislosti (Enhanced Universal Dependencies, EUD), sadu sémanticky orientovaných rozšíření, která byla navržena v rámci projektu Universal Dependencies (ale v současné době jsou k dispozici pouze pro malý počet jazyků).
Představím také předběžná pozorování z právě probíhající soutěže v automatickém větném rozboru do EUD (https://universaldependencies.org/iwpt20/).
Ve druhé části představím další rozšíření, která navrhujeme v rámci projektu Deep UD a která přesahují rámec současných anotačních pravidel UD.
Zaměřím se na dva aspekty: jak tato rozšíření mohou být užitečná při porozumění přirozenému jazyku strojem a do jaké míry je můžeme získat z povrchově syntaktické anotace automaticky, pro mnoho typologicky odlišných jazyků.
Universal Dependencies (univerzální závislosti) je mezinárodní projekt a komunita, která se snaží poskytnout morfologicky a syntakticky anotovaná data pro mnoho jazyků v jednotném anotačním stylu.
Informujeme o českém grantovém projektu MANYLA, který byl jednou z hnacích sil UD.
Pražské tektogramatické grafy (PTG) představují reprezentaci pro zachycení významu, která má kořeny v tektogramatické rovině Pražského závislostního korpusu (PDT) a je teoreticky podložena Funkčním generativním popisem jazyka (FGP).
Ve své současné podobě byly PTG připraveny pro soutěž CoNLL 2020 v analýze významových reprezentací napříč formalismy (MRP).
Jsou automaticky generovány z pražských závislostních korpusů a uloženy v grafovém formátu založeném na JSONu.
Převod je částečně ztrátový; v tomto článku popisujeme, které části anotace byly do PTG zahrnuty a jak jsou v PTG reprezentovány.
Představujeme systém pro předpovídání rysů z World Atlas of Language Structures (WALS), který se účastnil soutěže pořádané u příležitosti typologického workshopu SIGTYP 2020.
Parlament České republiky se skládá ze dvou komor: Poslanecké sněmovny (dolní komora) a Senátu (horní komora).
V naší práci se zaměřujeme na agendu a dokumenty týkající se Poslanecké sněmovny.
Konkrétně věnujeme zvláštní pozornost stenografickým protokolům, které zaznamenávají schůze Poslanecké sněmovny.
Naším cílem je kontinuálně kompilovat protokoly do korpusu ParCzech kódovaného TEI a zpřístupnit ho uživatelsky přívětivějším způsobem, než tak činí Parlament ČR.
V první fázi kompilace ParCzech obsahuje protokoly z let 2013+, které zpřístupňujeme a prohledáváme ve webové platformě TEITOK.
Korpus ParCzech PS7 1.0 je úplně první část rodiny korpusů z Parlamentu České republiky.
ParCzech PS7 1.0 obsahuje stenoprotokoly z Poslanecké sněmovny sedmého volebního období z let 2013-2017.
Audio záznamy jsou přiloženy.
Přepisy jsou poskytnuty v původním HTML formátu a navíc zkonvertovány do TEI-odvozeném formátu pro korpusového správce TEITOK.
Korpus je automaticky obohacen o morfologii a jmenné entity programy MorphoDita a NameTag.
Ačkoli název této zprávy přebírá slovo „Manuál“ z předchozích verzí, její účel již primárně není sloužit jako návod pro anotátory.
Spíše se pokouší popsat současný stav morfologické anotace ve vydání Prague Dependency Treebank - Consolidated 1.0 (PDT-C 1.0) Věříme, že pokyny mohou být užitečné pro uživatele dat PDT-C 1.0, stejně jako pro přípravu nových.
Tento článek představuje úlohu parsingu (syntaktické analýzy) do rozšířených Universal Dependencies, popisuje data použitá pro trénování a vyhodnocení, jakož i evaluační metriky.
Stručně shrnujeme jednotlivé přístupy a probíráme výsledky úlohy.
Metoda stylometrie nejčastějšími slovy neumožňuje přímé srovnání původních textů a jejich překladů, tj.
Napříč jazyky.
Například v dvojjazyčné česko-německé textové sbírce obsahující paralelní texty (originály a překlady v obou směrech spolu s českými a německými překlady z jiných jazyků) by autoři neshlukovali mezi jazyky, protože seznamy četných slov pro jakékoli české texty jsou zjevně bude se více podobat německému textu a naopak.
Pokusili jsme se přijít s interlinguou, která by odstranila rysy specifické pro jazyk a případně zachovala jazykově nezávislé rysy signálu jednotlivého autora, pokud existují.
Každý jazykový protějšek jsme označili, lemmatizovali a analyzovali odpovídajícím jazykovým modelem v UDPipe, který poskytuje jazykové označení, které je do značné míry vícejazyčné.
Odstranili jsme výstup jazykově závislých položek, ale to samo o sobě moc nepomohlo.
V dalším kroku jsme transformovali lemma obou jazykových protějšků na sdílená pseudolemata na základě velmi hrubého česko-německého glosáře s 95,6% úspěšností.
Ukazujeme, že u stylometrických metod založených na nejčastějších slovech se můžeme obejít bez překladů.
Vzájemná provázanost přejímání slov a slovotvorby (specificky derivace) je demonstrována na příkladu přípon -ismus a -ita,  které jsou uváděny mezi nejběžnějšími příponami v přejatých substantivech v češtině.
Obě přípony odvozují abstraktní substantiva, nicméně v mnoha dalších ohledech se liší.
Přípona -ismus se kombinuje se základy, které vytvářejí větší derivační rodiny než základy kombinované s -ita, ale i substantiva na -ita většinou sdílejí svůj kořen s několika dalšími deriváty.
Analýzou vybraných derivátů a jejich vzájemných vztahů napříč velkého množství derivačních rodin ukazuji, že velikost a vnitřní struktura derivačních rodin může poskytnout informace o významu analyzovaných derivátů.
Význam přípon je popsán pomocí vzorců, do kterých jsou zahrnuty relevantní deriváty s explicitně vyznačenými derivačními vztahy.
S použitím těchto vzorců je možné vysvětlit sémantické nuance, které u přejaých slov v češtině zatím nebyly popsány.
Mezijazyčné vyhledávání informací (pro Elitr LangTools workshop při Eurosai 2020)
Nástroj Cross-Lingual Information Retrieval (CLIR) vám umožňuje vyhledávat v dokumentech v různých jazycích a pomocí vlastního jazyka zadávat vyhledávací dotaz i zobrazovat výsledky vyhledávání díky automatizovanému strojovému překladu.
V ukázce můžete vyhledávat v auditech a dalších dokumentech publikovaných českými a belgickými nejvyššími kontrolními institucemi.
Demo funguje v angličtině, němčině, francouzštině a češtině.
Tento deliverable reportuje přípravu workshopu LangTools na kongres EUROSAI 2020, zaměřeného na prezentaci jazykových technologií zástupcům nejvyšších kontrolních úřadů.
Představujeme projekt THEaiTRE, ve kterém se snažíme počítačově vygenerovat scénář divadelní hry.
Prezentujeme THEaiTRE, začínající výzkumný projekt zaměřený na automatické generování scénářů divadelních her.
Tento článek podává přehled související literatury a návrh přístupu, který plánujeme použít.
Konkrétně jde o generativní neuronové jazykové modely a metody hierarchického generování, s podporou automatické sumarizace a strojového překladu, doplněné o přístupy používající manuální lidské vstupy.
Mnohé studie zkoumaly reprezentace vznikající v neuronových sítích trénovaných pro úkoly NLP a zkoumaly, jaké jazykové informace na úrovni slov mohou být v reprezentacích zakódovány.
V klasickém sondování je klasifikátor trénován na reprezentacích k získání cílové jazykové informace.
Hrozí však, že si klasifikátor pouze zapamatuje jazykové popisky pro jednotlivá slova, místo toho, aby z vyjádření vytěžil jazykové abstrakce, čímž by vykázal falešně pozitivní výsledky.
I když bylo vynaloženo značné úsilí na minimalizaci problému s memorizací, úkol skutečně změřit množství memorizace odehrávající se v klasifikaci byl zatím podceněn.
V naší práci navrhujeme jednoduchou obecnou metodu měření memorizačního efektu, založenou na symetrickém výběru srovnatelných sad viděných a neviděných slov pro trénování a testování.
Naši metodu lze použít k explicitní kvantifikaci množství memorování, které se děje, aby bylo možné zvolit adekvátní nastavení a výsledky sondování bylo možné spolehlivěji interpretovat.
To dokládáme ukázkou naší metody na případové studii sondování slovních druhů v natrénovaném enkodéru neuronového strojového překladu.
Tento dokument představuje výsledky WMT20 Metriky sdíleného úkolu.
Účastníci byli dotázáni k hodnocení výstupů překladatelských systémů soutěžících v WMT20 News Translation s automatickými metrikami.
Deset výzkumů skupiny předložily 27 metrik, z nichž čtyři jsou „metriky“ bez odkazů.
Kromě toho jsme vypočítali  pět základních metrik, včetně SENT BLEU, BLEU, TER a CHR F us- SacreBLEU.
Všechny metriky dobře korelují na úrovni systému, dokumentu a segmentu s oficiálním prekladem.
Předkládáme rozsáhlou analýzu vlivu referenčních překladů o metrické spolehlivosti, jak dobře automatické metriky hodnotí lidské preklady a také upozorňujeme na velké nesrovnalosti mezi metrickým a lidským skóre při hodnocení  systémem MT.
Nakonec zkoumame, zda můžeme použít automatické metriky k označení nesprávného hodnocení lidí.
Čtení s porozuměním je značně studovaný úkol s obrovskými trénovacími datasety v angličtině.
Tato práce se zaměřuje na tvorbu systému čtení s porozuměním pro češtinu, aniž by byla potřeba ručně anotovaná česká trénovací data.
Nejprve jsme automaticky přeložili datasety SQuAD 1.1 a SQuAD 2.0 do češtiny, abychom vytvořili trénovací a validační data, která zveřejňujeme na http://hdl.handle.net/11234/1-3249.
Poté jsme natrénovali a vyhodnotili několik referenčních modelů založených na architekturách BERT a XLM-RoBERTa.
Náš hlavní příspěvek však spočívá v modelech mezijazykového přenosu.
Model XLM-RoBERTa, trénovaný na anglických datech a vyhodnocený na češtině, dosahuje velmi konkurenceschopných výsledků, jen přibližně o 2 procenta horší než model trénovaný na přeložených českých datech.
Tento výsledek je mimořádně dobrý, vezmeme-li v úvahu skutečnost, že model během trénování neviděl žádná česká data.
Mezijazykový přenos je velmi flexibilní a je pomocí něj možné vytvořit model v jakémkoli jazyce, pro který máme dostatek čistých dat.
Tento dokument představuje výsledky sdílených úkolů ze 7. workshopu o překladech do asijských jazyků (WAT2020).
WAT2020 se účastnilo 20 týmů a 14 týmů předložilo výsledky překladů pro lidské hodnocení.
Obdrželi jsme také 12 písemných podání k výzkumu, z nichž 7 bylo přijato s výjimkou.
Zhruba 500 výsledků překladů bylo odevzdáno na automatickém hodnotícím serveru a vybraná podání byla vyhodnocena ručně.
Popisujeme společný příspěvek Edinburské univerzity a Univerzity Karlovy do soutěže v česko-anglickém strojovém překladu - WMT 2020 Shared Task on News Translation.
Naše rychlé a kompaktní studentské modely destilují znalosti z většího, pomalejšího učitelského modelu.
Jsou navrženy tak, aby nabízely dobrý kompromis mezi kvalitou překladu a efektivitou inference.
Na česko-anglických testovacích sadách WMT 2020 dosahují rychlosti překladu přes 700 zdrojových slov za sekundu na jednom procesoru, což umožňuje neuronový strojový překlad na spotřebním hardwaru bez GPU.
Prezentuji způsob, jak využít stenografované záznamy jednání PSPČR pro účely trénování systémů rozpoznávání řeči.
V článku je uvedena metoda pro získání dat, zarovnání na úrovni slov a výběr spolehlivých částí nepřesného přepisu.
Konečně prezentuji systém rozpoznávání řeči natrénovaný na těchto i jiných datech.
Praxe tetování je součástí lidské kultury od počátku dějin.
Navzdory kulturním posunům směrem k dobrovolné povaze a společenské přijatelnosti tetování se v tomto textu zaměřujeme na některé případy tetování jako nedobrovolného „značkování“, což je způsob vykonávání naprosté fyzické kontroly nad člověkem, jako v případě lidských otroků.
Ve své empirické dimenzi vychází naše studie z Archivu vizuální historie nadace USC Shoah.
Rozpoznávání řeči a strojový překlad učinily v posledních desetiletích velký pokrok a vedly ke vzniku praktických systémů, které dovedou mapovat jednu jazykovou posloupnost na druhou.
Přestože jsou stále dostupnější data ve více modalitách jako je zvuk a video, nejmodernější systémy jsou ze své podstaty unimodální v tom smyslu, že jako vstup berou jedinou modalitu - ať už řeč nebo text.
Zkušenosti z toho, jak se učí lidé učí jazyk, ukazují, že různé modality nesou navzájem se dolňující se signály, které jsou často klíčové pro řešení mnoha jazykových úkolů.
V tomto článku popisujeme datovou sadu How2, rozsáhlou, kolekci videí s přepisy a jejich překlady.
Ukazujeme, jak lze tuto datovou sadu využít k vývoji systémů pro různé jazykové úlohy a představujeme řadu modelů.
V rámci řešení těchto úloh zjišťujeme, že budování multimodálních architektur, které by fungovaly lépe, než jejich unimodální protějšek, zůstává i nadále velkou výzvou.
To ponechává velký prostor pro zkoumání pokročilejších řešení, která plně využívají multimodální povahu datového souboru How2, a také obecného směřování multimodálního učení s využitím jiných multimodálních datových sad.
I když se při strojovém vyhodnocování překladů ve velké míře používají metriky se středem věty, výkonnost na úrovni dokumentů je pro profesionální použití přinejmenším stejně důležitá.
V tomto dokumentu upozorňujeme na podrobné hodnocení na úrovni dokumentů zaměřené na markables (výrazy nesoucí většinu významu dokumentu) a negativní dopad různých markable error fenomenů na překlad.
Pro anotační experiment dvou fází jsme vybrali české a anglické dokumenty přeložené systémy, které byly předány do WMT20 News Translation Task.
Tyto dokumenty jsou z domén News, Audit a Lease.
Ukazujeme, že kvalita a také druh chyb se mezi doménami výrazně liší.
Tento systematický rozptyl je v protikladu k automatickým výsledkům hodnocení.
Zkoumáme, které specifické značení je problematické pro systémy MT, a zakončíme analýzou vlivu značených chybových typů na výkonnost MT měřenou lidmi a automatickými hodnotícími nástroji.
Strojový překlad z angličtiny:  V tomto dokumentu předkládáme naše podání k úkolu překládat nenarozené projevy pro IWSLT 2020.
Naším hlavním příspěvkem je navržený systém rozpoznávání řeči, který se skládá z akustického modelu a modelu foném-tographeme.
Jako mezičlánek používáme telefony.
Dokazujeme, že navrhovaný ropovod překonává komerčně využívané automatické rozpoznávání řeči (ASR) a zavádí jej na dráhu ASR.
Doplňujeme toto ASR o běžně dostupné systémy MT, abychom se zapojili také do skladby pro překlad řeči.
Přednáška pojednává o vztahu implicitnosti diskurzních vztahů a dalších faktorů, jako je jejich frekvence, specifičnost jejich sémantiky, a o  signálech spoluvytvářejících význam implicitního diskurzního vztahu (konfrontace: slovosled, dlouhé a krátké tvary zájmen, přízvuk; přípustka: intonace).
Představujeme velký soubor plenárních zasedání českého parlamentu.
Korpus se skládá z přibližně 1200 hodin řečových dat a odpovídajících textových přepisů.
Celý korpus byl segmentován na krátké zvukové segmenty, takže je vhodný jak pro trénink, tak pro hodnocení systémů automatického rozpoznávání řeči (ASR).
Zdrojovým jazykem korpusu je čeština, což z něj činí cenný zdroj pro budoucí výzkum, protože v českém jazyce je k dispozici pouze několik veřejných datových souborů.
Vydání dat doplňujeme experimenty dvou základních systémů ASR trénovaných na prezentovaných datech: tradičnější přístup implementovaný v Kaldi ASR toolkit, který kombinuje skryté Markovovy modely a hluboké neurální sítě (NN), a moderní ASR architekturu implementovanou v Jasper toolkit, který využívá NN v podobě end-to-end.
UDPipe 2 je nástroj pro tokenizaci, tagging, lemmatizaci a závislostní parsing CoNLL-U souborů.
Předtrénované jazykové modely jsou k dispozici pro téměř všechny UD korpusy a dosahují úspěšnosti srovnatelné s nejlepšími známými výsledky.
UDPipe 2 je svobodný software licencovaný pod Mozilla Public License 2.0 a jazykové modely jsou k dispozici pro nekomerční použití pod licencí CC BY-NC-SA, nicméně původní data použitá k vytvoření modelů mohou v některých případech ukládat další licenční omezení.
Představujeme náš příspěvek k shared tasku EvaLatin, což je první hodnotící kampaň věnovaná hodnocení nástrojů zpracování přirozeného textu pro latinu.
Předložili jsme systém založený na UDPipe 2, jednom z vítězů soutěže CoNLL 2018 Shared Task, dále The 2018 Shared Task on Extrinsic Parser Evaluation a také SIGMORPHON 2019 Shared Task.
Náš systém získal s velkým náskokem první místo jak v lemmatizaci tak v značkování v režimu otevřené modality, kde jsou povoleny další trénovací data, v kterémžto případě využíváme všechny latinské korpusy Universal Dependencies.
V režimu uzavřené modality, kdy jsou povoleny pouze EvaLatin trénovací data, dosahuje náš systém nejlepších výsledků v lemmatizaci a značkování klasických textů a zároveň dosahuje druhého místa v nastavení napříč žánry a napříč časem.
V ablačních experimentech hodnotíme vliv BERT a XLM-RoBERTa kontextualizovaných embeddingů a také kódování různých druhů latinských korpusů.
Zavádíme novou symetrickou míru (zvanou θpos), která využívá asymetrickou míru KLcpos3 (Rosa a Žabokrtský, 2015), abychom porovnali konzistenci anotace mezi různými anotovanými treebanky téhož jazyka, jestliže jsou anotované podle téhož anotačního schématu.
Pro tuto míru můžeme nastavit práh a říct, že dva treebanky lze považovat za harmonické, pokud jde o jejich anotaci, jestliže θpos nepřekročí daný práh.
Při stanovování prahové hodnoty posuzujeme vliv (i) různých velikostí dat a (ii) různého žánrového složení dat.
Naše odhady vycházejí z dat z různých jazykových rodin, takže práh není tolik závislý na vlastnostech jednotlivých jazyků.
Užití navržené míry demonstrujeme na treebancích z vydání 2.5 Universal Dependencies (Zeman et al., 2019): tam, kde je více než jeden treebank pro daný jazyk, uvádíme míru konzistence pro každý pár treebanků.
Navržená míra může být nicméně využita pro vyhodnocení konzistence i v jiných anotačních schématech než Universal Dependencies.
Uživatelské rozhraní vytvářené pro potřeby Centra vizuální historie Malach zpřístupňuje několik velkých kolekcí a databází orálně historických pramenů k výzkumu dějin 20. století, se zvláštním zřetelem na problematiku holokaustu.
Neurální sítě trénované na zpracování přirozeného jazyka zachycují syntaxi, i když není poskytována jako signál dohledu.
To naznačuje, že syntaktická analýza je nezbytná pro podcenění jazyka v systémech umělé inteligence.
Tento přehledný dokument se zabývá přístupy k hodnocení množství syntaktických informací obsažených v reprezentacích slov pro různé architektury neuronových sítí.
Shrnujeme především výzkum anglických jednojazyčných dat o úkolech jazykového modelování a vícejazyčných dat pro systémy neurálního strojového překladu a vícejazyčné jazykové modely.
Popisujeme, které předcvičené modely a znázornění jazyka jsou nejvhodnější pro přenos do syntaktických úloh.
Tato práce se zaměřuje na analýzu formy a rozsahu syntaktické abstrakce zachycené BERT extrahováním označených stromů závislosti ze sebepozornosti.
Předchozí práce ukázaly, že jednotlivé hlavy BERT mají tendenci kódovat konkrétní typy vztahů závislosti.
Rozšiřujeme tato zjištění explicitním porovnáním vztahů BERT s anotacemi Universal Dependencies (UD), což ukazuje, že se často neshodují jedna ku jedné.
Navrhujeme metodu pro identifikaci vztahu a syntaktickou stavbu stromu.
Náš přístup vytváří podstatně více konzistentních stromů závislosti než předchozí práce, což ukazuje, že lépe vysvětluje syntaktické abstrakce v BERT.
Zároveň ji lze úspěšně aplikovat jen s minimální mírou dohledu a dobře zobecňuje napříč jazyky.
Prezentace je věnována implicitnosti diskurzních vztahů, jako je například podspecifikované užití konektivních prostředků nebo sémantická signalizace.
CzeDLex 0.7 je třetí vývojová verze slovníku českých diskurzních konektorů.
Slovník obsahuje konektory částečně automaticky extrahované z Pražského diskurzního korpusu 2.0 (PDiT 2.0) a z dalších zdrojů.
Nejfrekventovanější slovníková hesla (pokrývající více než 95% diskurzních vztahů anotovaných v PDiT 2.0) byla ručně zkontrolována, přeložena do angličtiny a doplněna dalšími lingvistickými informacemi.
Existující modely vícejazyčných větných vektorových reprezentací (embeddingů) vyžadují rozsáhlé paralelní datové zdroje, které nejsou k dispozici pro všechny jazyky.
Navrhujeme novou metodu neřízeného učení pro získání vícejazyčných větných embeddingů pouze z jednojazyčných dat.
Nejprve pomocí neřízeného strojového překladu vytvoříme syntetický paralelní korpus a použijeme jej k doladění předtrénovaného cross-lingválního maskovaného jazykového modelu (XLM) a k odvození vícejazyčných větných reprezentací.
Kvalita reprezentací je hodnocena na dvou úlohách dolování paralelních dat se zlepšením F1 skóre až o 22 bodů oproti standardnímu XLM.
Dále pozorujeme, že jeden syntetický dvojjazyčný korpus je schopen vylepšit výsledky i pro jiné jazykové páry.
Tento článek představuje popis soutěžních systémů Univerzity Karlovy pro úlohu WMT20 ve strojovém překladu mezi němčinou a lužickou srbštinou při nedostatku dat.
Provedli jsme experimenty s trénováním na syntetických datech a předtrénováním na příbuzných jazykových párech.
V plně neřízeném režimu jsme dosáhli 25,5 a 23,7 BLEU při překladu z a do lužické srbštiny.
Ve volnějším režimu jsme použili transfer learning z německo-českých paralelních dat a dosáhli 57,4 BLEU a 56,1 BLEU, což je zlepšení o 10 BLEU bodů oproti baseline natrénované pouze na malém množství dostupných německo-lužickosrbských paralelních vět.
Mnohojazyčné kontextové embedinky, jako vícejazyčný BERT (mBERT) a XLM-RoBERTa, se osvědčily pro mnoho vícejazyčných úloh.
Předchozí práce zkoumala mnohojazyčnost reprezentací nepřímo s využitím nulového transferového učení na morfologických a syntaktických úkolech.
Místo toho se zaměřujeme na jazykovou neutralitu mBERTu s ohledem na lexikální sémantiku.
Naše výsledky ukazují, že kontextové embedinky jsou jazykově neutrálnější a obecně informativnější než zarovnané statické slovní embedinky, které jsou explicitně trénovány na jazykovou neutralitu.
Kontextové embedinky jsou stále standardně pouze mírně jazykově neutrální, nicméně ukazujeme dvě jednoduché metody, jak dosáhnout silnější jazykové neutrality: zaprvé neřízeným vystředěním reprezentace pro jazyky a zadruhé explicitní projekcí na malých paralelních datech.
Kromě toho ukazujeme, jak překonat nejlepší dosažené přesnosti při identifikaci jazyka a zarovnávání slov v paralelních větách.
Představujeme příspěvek do soutěže a kombinace automatického překladu a parafrázování ve výuce jazyků (STAPLE).
Pro překlad jsme použili standardní model Transformer, doplněný kroslinguálním klasifikátorem pro filtrování překladových hypotéz.
Abychom zvýšili rozmanitost výstupů, použili jsme další trénovací data a vyvinuli jsme parafrázovací model založený na architektuře Levenshtein Transformer, který generuje další synonymní překlady.
Výsledky parafrázování byly opět filtrovány kroslinguálním klasifikátorem.
Zatímco použití dalších dat a náš filtr zlepšily výsledky, parafrázování generovalo příliš mnoho neplatných výstupů, aby dále zlepšilo kvalitu výstupů.
Náš model bez parafrázování skončil přibližně uprostřed soutěžního pořadí a přinesl zlepšení o 10-22% vážený F1 bodů oproti základnímu řešení.
Představujeme naše systémy pro WMT20 Very Low Resource MT Task k překladu mezi němčinou a hornolužickou srbštinou.
Pro trénink našich systémů generujeme syntetická data zpětným i dopředným překladem.
Trénvací data navíc obohacujeme o německo-české překlady z češtiny do hornolužické srbštiny pomocí neřízeného statistického MT systému, který obsahuje ortograficky podobné slovní dvojice a transliterace slov mimo slovník.
Náš nejlepší překladový systém mezi němčinou a srbštinou je založen na transferu modelu z česko-německého systému a má o 12 až 13 BLEU vyšší skóre než základní systém vytvořený pouze s využitím dostupných paralelních dat.
Popisujeme naše dva neuronové překladové systémy pro anglicko-český a anglicko-polský překlad, které se zúčastnily soutěže v překladu novinových článků WMT 2020.
První systém překládá každou větu nezázvisle.
Druhý systém je tzv. document-level, tedy překládá více vět naráz a je trénovaný na vícevětných sekvencích dlouhých až 3000 znaků.
Kvalita lidského překladu byla dlouho považována za nedosažitelnou pro počítačové překladové systémy.
V této studii představujeme systém hlubokého učení CUBBITT, který tento názor zpochybňuje.
V zaslepeném lidském hodnocení překladu novinových článků z angličtiny do češtiny CUBBITT výrazně předčil lidský překlad od profesionální agentury v zachování významu textu (adequacy, přesnosti překladu).
Zatímco lidský překlad je stále hodnocen jako plynulejší, ukázalo se, že CUBBITT je podstatně plynulejší než dosavadní překladače.
Většina účastníků překladového Turingova testu navíc nedokázala rozlišit překlady CUBBITT od překladů lidských.
Tato práce se blíží kvalitě lidského překladu a za určitých okolností jej dokonce v přiměřenosti překonává.
To naznačuje, že hluboké učení může mít potenciál nahradit člověka v aplikacích, kde je hlavním cílem zachování významu.
Tento dokument představuje náš pokrok směrem k zavedení univerzální komunikační platformy v úkolu vysoce mnohojazyčného živého projevu překlady pro konference a vzdálené schůzky živé titulkování.
Platforma byla navržena se zaměřením na velmi nízkou latenci a vysoká flexibilita při umožnění snadného propojení výzkumných prototypů nástrojů pro zpracování řeči a textu, bez ohledu na to, kde fyzicky běhat.
Nastíníme naše řešení architektury a také ho krátce porovnáme s platformou ELG.
Technické podrobnosti jsou uvedeny o nejdůležitějších součástech a shrnujeme události zkušebního nasazení, které jsme zatím provedli.
Cílem příspěvku je představit česko-německou slovníkovou databázi obsahující frekventované jazykové výrazy podílející se na strukturaci textu – anaforické diskurzní konektory.
Představujeme aplikace EVALD (Evaluator of Discourse) pro automatické vyhodnocování českých textů.
Podrobně analyzujeme nově získaná jazyková data - texty psané cizími mluvčími dosahující první úrovně osvojování českého jazyka.
Představujeme také nové pravopisné "featury" přidané do systému.
GeCzLex je databáze překladových ekvivalentů českých a německých textových konektorů.
Je založena na značkovaných datech několika elekronických jazykových zdrojů: pro češtinu je jeho základem Pražský diskurzní korpus 2.0 a slovník českých konektorů CzeDLex 0.6, pro němčinu podobný slovník DiMLex, pro oba jazyky pak česko-německá část paralelního korpusu Intercorp 11.
Současné, první vydání je pilotní verzí a zároveň výstupem výzkumného projektu o anaforičnosti českých a německých konektorů.
Databáze tedy nyní obsahuje překladové ekvivalenty pro a) konektory utvořené zpravidla spojením předložky a anaforického prvku (jako např. "darum" v němčině a "proto" v češtině) a b) české konektory, u nichž byla demonstrována schopnost vázat se na nesousední, vzdálené textové segmenty.
Tento článek popisuje podání Idiap pro WAT 2019 pro anglicko-hindský vícemodální překladatelský úkol.
Použili jsme nejmodernější model Transformeru a jako dodatečný zdroj dat jsme použili anglicko-hindský paralelní korpus IITB.
Z různých skladeb multimodálního úkolu jsme se zúčastnili skladby „Text-Only“ pro hodnocení a testovací sady.
Naše podání je mezi konkurenty špičkové jak z hlediska automatického, tak manuálního hodnocení.
Na základě automatických skóre předčí naše pouze textové podání i systémy, které v úkolu „multimodální překlad“ zohledňují vizuální informace.
Visual Genome je dataset spojující strukturované obrazové informace s anglickým jazykem.
Představujeme „Hindi Visual Genome“, multimodální datový soubor skládající se z textu a obrazů vhodný pro anglicko-hindský multimodální strojový překlad a multimodální výzkum.
Vybrali jsme krátké anglické segmenty (popisky) z Visual Genome spolu s přidruženými obrázky a automaticky je přeložili do hindštiny.
Následovala pečlivá ruční kontrola, která vzala v úvahu související obrázky.
Zkoumáme vícehlavou sebepozornost v enkodérech Transformer NMT pro tři zdrojové jazyky a hledáme vzory, které by mohly mít syntaktickou interpretaci.
V mnoha hlavách pozornosti často nalézáme sekvence po sobě jdoucích stavů, které sledují stejnou pozici, které se podobají syntaktickým frázím.
Navrhujeme transparentní deterministickou metodu kvantifikace množství syntaktické informace přítomné v sebepozornosti, založenou na automatickém vytváření a vyhodnocování frázových stromů z frázovitých sekvencí.
Výsledné stromy porovnáváme se stávajícími syntaktickými korpusy, a to jak ručně, tak pomocí výpočtu přesnosti a úplnosti.
Slovní embedinky a hluboké neuronové sítě fungují skvěle.
Nemají žádné explicitní znalosti jazykových abstrakcí.
Jak fungují?
Jaké emergentní abstrakce v nich můžeme pozorovat?
Jak je můžeme interpretovat?
Jsou emergentní struktury a abstrakce podobné klasickým lingvistickým strukturám a abstrakcím?
V této práci provádíme studii soustřeďující se na neuronový překlad (NMT) pro angličtinu-indonéštinu (EN-ID) a indonéštinu-angličtinu (ID-EN).
Zaměřujeme se na doménu mluveného jazyka, jmenovitě na hovorový jazyk.
Budujeme systémy NMT pomocí modelu Transformer pro oba směry překladu a implementujeme adaptaci domény, kde předtrénované systémy NMT trénujeme na datech mluveného jazyka (v doméně).
Dále provádíme hodnocení toho, jak může metoda doménové adaptace v našem systému EN-ID vést k formálnějším výsledkům překladů.
Neuronové systémy generování přirozeného jazyka jsou známy svými patologickými výstupy, tj.
generováním textu, který nesouvisí se specifikovaným vstupem.
V tomto článku ukazujeme vliv sémantického šumu na současné nejlepší neuronové generátory, které implementují různé mechanismy sémantické kontroly.
Zjistili jsme, že vyčištění trénovacích dat může zlepšit sémantickou přesnost až o 97% při zachování plynnosti výstupů.
Dále jsme zjistili, že nejčastějším typem chyby je vynechání informace, ne přidaná halucinovaná informace.
Představujeme systém pro automatický odhad kvality výstupů generování přirozeného jazyka založený na rekurentních neuronových sítích, který se učí zároveň přiřazovat numerická absolutní hodnocení jednotlivým výstupům a dodávat relativní hodnocení pro páry různých výstupů.
Druhá úloha se trénuje pomocí párové hinge chyby nad skóre ze dvou kopií sítě pro absolutní hodnocení.
Pro zlepšení kvality absolutního hodnocení používáme i učení relativního hodnocení a syntetická trénovací data: syntetizujeme trénovací páry zašuměných výstupů generátorů a učíme systém preferovat ten méně zašuměný.
Toto vedlo ke 12% zvýšení korelace s lidským hodnocením proti předchozí nejlepší dosažené hodnotě.
Navíc ukazujeme první výsledky na datové sadě relativních hodnocení z E2E NLG Challenge (Dušek et al., 2019), kde syntetická data přinesla 4% zlepšení přesnosti oproti základnímu modelu.
Prezentujeme první datovou sadu zaměřenou na end-to-end generování jazyka v češtině v doméně restaurací, společně s několika silnými základními modely postavenými na architektuře sequence-to-sequence.
Neanglické generování jazyka je obecně málo probádaný problém a čeština jakožto morfologicky bohatý jazyk představuje ještě těžší úkol: protože v češtině je třeba skloňovat jmenné entity, delexikalizace nebo jednoduché kopírovací mechanismy nefungují samy o sobě a lexikalizace výstupů generátoru je netriviální.
V našich experimentech představujeme dva různé přístupy k tomuto problému: (1) použití jazykového modelu pro výběr správné vyskloňované formy během lexikalizace, (2) dvoufázové generování: náš model sequence-to-sequence vygeneruje prokládanou sekvenci lemmat a morfologických značek, která je posléze zpracována morfologickým generátorem.
Tento dokument představuje výsledky premiérově sdíleného úkolu organizovaného společně s Konferencí o strojovém překladu (WMT) 2019.
Účastníci byli požádáni, aby sestavili systémy strojového překladu pro kterýkoli z 18 jazykových párů, které budou vyhodnoceny na základě testovací sady novinek.
Hlavním metrem pro tento úkol je lidský úsudek o kvalitě překladu.
Úkol byl také otevřen pro další testovací sady, které zkoumají specifické aspekty překladu.
Tento dokument představuje výsledky sdíleného úkolu WMT19 Metrics.
Účastníci byli požádáni, aby pomocí automatických metrik ohodnotili výstupy překladatelských systémů soutěžících v WMT19 News Translation Task.
13 výzkumných skupin předložilo 24 metrik, z nichž 10 jsou „metriky“ bez odkazů a představují podání ke společnému úkolu s WMT19 Quality Estimation Task, „QE as a Metric“.
Navíc jsme vypočítali 11 základních metriky, s 8 běžně používanými výchozími hodnotami (BLEU, SentBLEU, NIST, WER, PER, TER, CDER a chrF) a 3 reimplementy (chrF+, sacreBLEU-BLEU a sacreBLEU-chrF).
Metriky byly hodnoceny na systémové úrovni, jak dobře daná metrika koreluje s oficiálním manuálním řazením WMT19 a na úrovni segmentu, jak dobře metrika koreluje s lidskými úsudky o kvalitě segmentu.
Letos používáme přímé hodnocení (DA) jako jedinou formu manuálního hodnocení.
Reflexiva v češtině plní nerůznější funkce.
V tomto příspěvku jsme se zaměřily na změny ve valenci derivovaných reflexivních sloves.
Soutěžní úkol pro rok 2019 na konferenci Computational Language Learning (CoNLL) byl věnován sémantickému parsingu (Meaning Representation Parsing, MRP) napříč různými přístupy.
Soutěž zahrnuje pět formálně a lingvisticky rozdílných přístupů k reprezentaci významu (DM, PSD, EDS, UCCA a AMR).
Do soutěže se přihlásilo osmnáct týmů, z nichž pět se neúčastnilo oficiálního hodnocení, protože jejich výsledky dorazily až po uzávěrce, nebo tým využil dodatečných trénovacích dat, popřípadě byl jeden ze spoluorganizátorů soutěže mezi zástupci týmu.
Veškeré technické informace týkající se soutěže jsou k dispozici na webových stránkách úkolu: http://mrp.nlpl.eu.
V příspěvku navrhujeme dvě neuronové architektury pro rozpoznávání vnořených pojmenovaných entit, což je úloha, ve které se pojmenované entity mohou překrývat a také být označeny více než jednou značkou.
Vnořené značky zakódováváme pomocí linearizovaného schématu.
V prvním navrženém přístupu jsou vnořené značky modelovány jako multiznačky náležející kartézkému součinu vnořených značek ve standardní LSTM-CRF architektuře.
V druhém navrženém přístupu přistupujeme k úloze rozpoznávání vnořených pojmenovaných entit jako k sequence-to-sequence problému, ve kterém vstupní sekvence sestává z tokenů a výstupní sekvence ze značek, přičemž používáme vynucený mechanismus attention na slově, které právě značkujeme.
Navržené metody překonávají současný stav poznání v úloze rozpoznávání vnořených pojmenovaných entit na čtyřech korpusech: ACE-2004, ACE-2005, GENIA a českém CNEC.
Naše architektury jsme dále obohatili nedávno publikovanými kontextovými embeddingy: ELMo, BERT a Flair, čímž jsme dosáhli dalšího zlepšení na všech čtyřech korpusech.
Navíc publikujeme nejlepší známé výsledky v ropoznávání pojmenovaných entit na korpusech CoNLL-2002 v nizozemštině a španělštině a korpusu CoNLL-2003 v angličtině.
Je známo, že neuronový strojový překlad vyžaduje velké množství paralelních trénovacích vět, které obecně brání tomu, aby vynikal na párech jazyků s nedostatečným množstvím zdrojů.
Tato práe se zabývá využitím translingválního učení na neuronových sítích jako způsobu řešení problému nedostatku zdrojů.
Navrhujeme několik přístupů k transferu znalostí za účelem opětovného využití modelu předtrénovaného na jiné jazykové dvojici s velkým množstvím zdrojů.
Zvláštní pozornost věnujeme jednoduchosti technik.
Studujeme dva scénáře: a) když používáme předtrénovaný model bez jakýchkoli předchozích úprav jeho trénovacího procesu a b) když můžeme předem připravit prvostupňový model pro transfer znalostí pro potřeby dítěte.
Pro první scénář představujeme metodu opětovného využití modelu předtrénovaného jinými výzkumníky.
V druhém případě předkládáme metodu, která dosáhne ještě většího zlepšení.
Kromě navrhovaných technik se zaměřujeme na hloubkovou analýzu technik transferu znalostí a snažíme se vnést trochu světla do pochopení transferového učení.
Ukazujeme, jak naše techniky řeší specifické problémy jazyků s málo daty a že jsou vhodné i pro jazykové páry s velkým množstvím dat.
Potenciální nevýhody a chování hodnotíme studiem transferového učení v různých situacích, například pod uměle poškozeným trénovacím korpusem, nebo se zafixovanými částmi modelu.
V tomto tutoriálu se naučíte používat tensor2tensor a jak aplikovat přenos znalostí na nízko-zdrojové jazykové páry.
Tutorial je vhodný i pro účastníky, kteří nemají zkušenosti s trénováním neuronových MT modelů.
Tento článek popisuje systém CUNI do News WMT 2019 pro jazyky s nedostatečnými zdroji: Gujarati-Angličtina  a Kazakština-Angličtina.
Zúčastnili jsme se na obou jazykových párech v obou směrech překladu.
Náš systém kombinuje přenos znalostí z jiného dvojice jazyků s vysokým množstvím paralelních dat, po kterém následuje trénování na zpětně přeložených jednojazyčných dat.
Díky simultánnímu tréninku v obou směrech můžeme iterovat proces zpětného překladu.
Používáme Transformer model v constrained podmínkách.
V tomto článku poskytujeme přehled zkušeností z první ruky a výhodných bodů pro osvědčené postupy z projektů v sedmi evropských zemích věnovaných výzkumu korpusu studentů (LCR) a vytváření korpusů studentů jazyků.
Korpusy a nástroje zapojené do LCR jsou stále důležitější, stejně jako pečlivá příprava a snadné vyhledávání a opětovné použití korpusů a nástrojů.
Nedostatek společně dohodnutých řešení pro mnoho aspektů LCR, interoperabilita mezi korpusy studentů a výměna dat z různých korpusových projektů studentů však zůstává výzvou.
Ukážeme, jak mohou být koncepty jako metadata, anonymizace, taxonomie chyb a jazykové anotace, jakož i nástroje, řetězce nástrojů a datové formáty individuálně náročné a jak lze výzvy řešit.
Mnohé lingvistické teorie a anotační schémata obsahují hloubkově-syntaktickou a/nebo sémantickou vrstvu.
Ačkoli řada z nich byla aplikována na více než jeden jazyk, žádná se nepřibližuje množství jazyků, které jsou pokryty univerzálními závislostmi (Universal Dependencies, UD).
V tomto článku představujeme prototyp hloubkových univerzálních závislostí (Deep Universal Dependencies): dvourychlostního konceptu, ve kterém určitá minimální hloubková anotace je automaticky odvozena z povrchových stromů UD, zatímco bohatší anotaci je možné přidat ručně u korpusů, kde jsou k dispozici potřebné zdroje.
Data Deep UD zpřístupňujeme v repozitáři Lindat.
Představujeme UDify, vícejazyčný víceúlohový model schopný přesně předpovědět univerzální slovní druhy, morfologické rysy, lemmata a závislostní stromy současně pro všech 124 treebanků Universal Dependencies napříč 75 jazyky.
Využitím vícejazyčného modelu BERT předcvičeného na 104 jazycích jsme zjistili, že jeho dotrénování na všech zřetězených treebancích spolu s jednoduchými softmax klasifikátory pro každý úkol UD ústí v nejlepší známé výsledky pro UPOS, UFeats, lemmatizaci, UAS a LAS metriky, aniž by vyžadovalo jakékoli rekurentní nebo jazykově specifické komponenty.
Hodnocení UDify ukazuje, že vícejazyčné učení nejvíce prospívá jazykům s málo daty.
Vícejazykové trénovaní poskytuje kvalitní předpovědi i pro jazyky, které nebyly zastoupeny v trénovacích datech, naznačují, že i pro ně posky vícejazyčné školen.
Zdrojový kód UDify je dostupný na https://github.com/hyperparticle/udify.
Nedávný vývoj v oblasti strojového překladu experimentuje s myšlenkou, že model může zlepšit kvalitu překladu provedením více úloh, např. překládáním ze zdroje na cíl a také označováním každého zdrojového slova syntaktickými informacemi.
Intuice je taková, že síť by zobecňovala znalosti na více úloh a zlepšila tak výkon překladu, zejména v podmínkách nízkých zdrojů.
Vymysleli jsme experiment, který tuto intuici zpochybňuje.
Podobné experimenty provádíme jak v multidekodérech, tak v prokládacích sestavách, které označují každé cílové slovo buď syntaktickou značkou, nebo úplně náhodnou značkou.
Překvapivě ukazujeme, že model si vede skoro stejně dobře na nekorespondovaných náhodných značkách jako na skutečných syntaktických značkách.
Naznačujeme některá možná vysvětlení tohoto chování.
Hlavním poselstvím našeho článku je, že experimentální výsledky s hlubokými neuronovými sítěmi by měly být vždy doplněny triviálními výchozími hodnotami dokumentujícími, že pozorovaný přírůstek je ne kvůli některým nesouvisejícím vlastnostem systému nebo tréninkovým efektům.
Skutečná důvěra v to, odkud zisky pocházejí, bude pravděpodobně i nadále problematická.
V současné společnosti se otázky sociální spravedlnosti často týkají dokumentárních videoklipů a jejich interpretace.
Pochopení způsobů práce s videem a jeho okolí v každodenním prostředí by mohlo přinést nové pohledy na tradiční témata.
Tato práce vychází z etnometodologické studie videonahrávek kolektivní práce studentů s on-line materiály sestavenými z textů, obrázků a fragmentů orálněhistorických rozhovorů.
Studenti pracovali s jedním počítačovým zařízením a jedním papírovým listem v malých skupinách po dvou nebo třech.
Časová organizace práce v učebně s digitálními ústními dějinami je v tomto uspořádání rozdělena do tří fází: 1) příprava na sledování videoklipu, což vyžaduje vytvoření optimálního uspořádání hmotných artefaktů a tělesné orientace účastníků; 2) sledování videoklipu, během něhož je upřednostňováno nepřerušované sledování od začátku do konce, jakož i omezení hovoru účastníků na "průběžné komentáře"; 3) reflexe videoklipu, během níž se projevuje orientace na formulaci požadované odpovědi a její společné zapsání do papírového listu, včetně případného druhého sledování videoklipu.
Pro efektivní a smysluplné používání audiovizuálních orálněhistorických materiálů (OH) je důležité pochopit, jak lidé chápou smysl takových videozáznamů v sociální interakci.
Vyvstávají tak zásadní otázky týkající se sekundární analýzy a praktického využití archivovaného audiovizuálního materiálu OH, jako například: Jaké jsou rysy OH rozhovoru jako společenského objektu?
Co jej činí smysluplným a interpretovatelným?
Kolik toho potřebujeme vědět o sociálně situovaném charakteru rozhovoru, abychom ho správně pochopili?
Existuje ve vztahu k OH „příliš málo“ nebo „příliš mnoho“ kontextu?
Jaký smysl mají rozhovory na OH ve společenské praxi a jaký je jejich vztah k širším historickým znalostem?
V rámci workshopu uchopíme tyto dalekosáhlé otázky z velice empirického a praktického hlediska.
Oslovujeme akademické pracovníky, kteří se zajímají o mezioborové přístupy a pracují s interview, orální historií a digitalizovanými nebo digitálními kvalitativními daty obecně.
Tato práce popisuje testovací sadu dokumentů z auditorské domény pro strojový překlad a její použití jako jedné ze „testovacích sad“ v WMT19 News Translation Task pro překladatelské směry zahrnující češtinu, angličtinu a němčinu.
Naše hodnocení naznačuje, že současné MT systémy optimalizované pro oblast všeobecného zpravodajství mohou docela dobře fungovat i v konkrétní oblasti auditních zpráv.
Podrobné manuální hodnocení však ukazuje, že hluboká faktická znalost dané oblasti je nezbytná.
Pouhým okem neodborníka se překlady mnoha systémů zdají téměř dokonalé a automatické hodnocení MT s jednou referencí je pro zvážení těchto detailů prakticky zbytečné.
Dále na ukázkovém dokumentu z oblasti smluv ukazujeme, že i ty nejlepší systémy zcela selhávají v zachování sémantiky smlouvy, specificky zachování identit stran.
CzeDLex 0.6 je druhá vývojová verze slovníku českých diskurzních konektorů.
Slovník obsahuje konektory částečně automaticky extrahované z Pražského diskurzního korpusu 2.0 (PDiT 2.0), rozsáhlého korpusu s ručně anotovanými diskurzními vztahy.
Nejfrekventovanější slovníková hesla (pokrývající více než 90% diskurzních vztahů anotovaných v PDiT 2.0) byla ručně zkontrolována, přeložena do angličtiny a doplněna dalšími lingvistickými informacemi.
Tato práce se zabývá opomínejou otázkou valence příslovcí.
Po stručném teoretickém úvodu představíme postup při extrahování seznamu potenciálních valenčních příslovcí ze dvou českých syntakticky značkovaných korpusů, SYN2015 a PDT.
Dále zmíníme metodologické a teoretické problémy spojené s tímto problémem, zejména ty, které se týkají nejasných hranic slovních druhů, a charakterizujeme typy získaných valenčních příslovcí.
Tam, kde je to vhodné, komentujeme lexikografické zpracování valenčních příslovcí a případně navrhujeme jeho úpravu.
DeriNet je rozsáhlý lingvistický zdroj obsahující více než 1 milion českých lexémů spojených téměř 810 tisíci derivačních vztahů.
Jeho předchozí verze, DeriNet 1.7, kromě derivací neobsahovala další anotace – byly v ní uvedeny lemmata a slovnědruhové kategorie každého lexému, a od verze 1.5 binární příznak kompozitnosti.
Tento článek představuje rozšířenou verzi zdroje, nazvanou DeriNet 2.0, která přináší řadu nových anotací: všechny lexémy mají vyznačené základní morfologické kategorie (vid, rod a životnost), 250 tisíc lexémů má identifikované kořenové morfémy, 150 tisíc derivačních vztahů je označeno svou sémantickou kategorií (zdrobňování, přivlastňování, přechylování, opakovanost a změna vidu), některá kompozita jsou v rámci pilotního projektu přiřazena ke svým základovým slovům a přibylo několik tzv. fiktivních lexémů spojujících příbuzné derivační rodiny bez společného předka.
Tyto nové anotace mohly být přidány díky novému souborovému formátu, který je obecný a rozšiřitelný a tedy potenciálně využitelný i v jiných podobných projektech.
Rozvoj a využívání jazykových zdrojů často zahrnuje zpracování osobních údajů.
Obecné nařízení o ochraně osobních údajů (GDPR) stanoví celoevropský rámec pro zpracování osobních údajů pro výzkumné účely a zároveň umožňuje určitou flexibilitu na straně členských států.
Dokument pojednává o právním rámci pro výzkum lan- guage po vstupu GDPR v platnost.
V první části představíme některé základní pojmy ochrany údajů, které jsou důležité pro výzkum jazyků.
Ve druhé části je diskutován obecný rámec zpracování osobních údajů pro výzkumné účely.
V poslední části se zaměříme na modely, které některé členské státy EU používají k regulaci zpracování dat pro výzkumné účely.
ITAT (Informačné Technológie - Aplikácie a Teória) je tradiční česko-slovenská konference sdružující vědce a odborníky pracující v širokém spektru informatiky.
ITAT nabízí nejen možnost výměny nápadů a informací, ale klade také důraz na neformální komunikaci a diskuse mezi účastníky.
Tento článek představuje úvodní výzkum větné reprezentace ve spojitém prostoru.
Získali jsme páry velmi podobných vět, které si liší pouze drobnou změnou (jako změna substantiva, přidání adjektiva) z datasetů na odvozování v přirozeném jazyce pomocí metody jednoduchých vzorců.
Zkoumáme nakolik drobná změna ve větě ovlivní její reprezentaci ve spojitém prostoru a jak jsou tyto změny zobrazeny v některých populárních modelech větných embeddingů.
Zjistili jsme, že některé embeddingy pěkně reflektují malé větné změny.
Představujeme sbírku testů pro získávání informací napříč jazyky v medicínské doméně.
Tato sbírka je postavena na zdrojích používaných laboratoří CLEF pro hodnocení elektronického zdravotnictví v letech 2013–2015 při úkolech vyhledávání informací zaměřených na pacienta a zlepšuje využitelnost a opakovanou použitelnost oficiálních údajů.
Soubor dokumentů je totožný s oficiálním souborem, který byl pro tento úkol použit v roce 2015, a obsahuje asi milion anglických lékařských webových stránek.
Sada dotazů obsahuje 166 položek použitých během tří let jako testovací dotazy, které jsou nyní dostupné v osmi jazycích.
Rozšířená sbírka testů poskytuje další relevantní hodnocení, která téměř zdvojnásobily množství oficiálně posuzovaných párů dotaz-dokument.
Tato práce popisuje obsah rozšířené sbírky, podrobnosti překladu dotazů a posouzení relevance a nejmodernější výsledky získané z této sbírky.
https://lindat.mff.cuni.cz/repository/xmlui/handle/11234/1-2925
Představujeme metodu automatického rozšíření dotazů pro vyhledávání informací mezi jazyky v oblasti medicíny.
Metoda využívá strojový překlad dotazů ze zdrojového jazyka do jazyka dokumentu a lineární regresi k předvídání výkonu vyhledávání pro každý přeložený dotaz, který je rozšířen o kandidátský termín.
Kandidátské termíny (v jazyce dokumentu) pocházejí z více zdrojů: hypotézy pro překlad dotazů získané ze systému strojového překladu, články na Wikipedii a abstrakty PubMed.
Rozšíření dotazu je použito pouze v případě, že model předpovídá skóre pro kandidátní termín přesahující vyladěnou hranici, která umožňuje rozšiřovat dotazy pouze se silně příbuznými termíny.
Naše experimenty jsou prováděny s využitím kolekce testů elektronického zdravotnictví CLEF 2013–2015 a vykazují významná zlepšení jak v mnohojazyčném, tak jednojazyčném nastavení.
V tomto příspěvku porovnáváme strukturu českých slovních embeddingů pro anglicko-český strojový překlad (NMT), word2vec a analýzu sentimentu.
Ukazujeme, že i když je možné úspěšně předvídat část slovních druhů (POS) z embeddingů word2vec a různých překladových modelů, ne všechny prostory embeddingů vykazují stejnou strukturu.
Informace o POS jsou přítomny v embeddingu word2vec, ale vysoký stupeň organizace POS v dekodéru NMT naznačuje, že tyto informace jsou důležitější pro strojový překlad, a proto je model NMT reprezentuje přímějším způsobem.
Naše metoda je založena na korelaci dimenzí PCA s kategorickými lingvistickými údaji.
Také ukazujeme, že další zkoumání histogramů tříd podél dimenzí PCA je důležité pro pochopení struktury znázornění informací v embeddinzích.
Článek popisuje vážený konečný morfologický převodník pro krymskou tatarštinu, který je schopen analyzovat a generovat slova jak v latince, tak v cyrilici.
Tento převodník byl vyvinut týmem, který sestává z člena komunity a jazykového experta, polního lingvisty, který pracuje s krymskotatarskou komunitou, turkologa se zkušeností s počítačovou lingvistikou a zkušeného počítačového lingvisty se zkušenostmi s turkickými jazyky.
Tento dokument slouží jako stručný přehled zvláštního vydání JNLE o znázornění významu věty, který spojuje tradiční symbolické a moderní kontinuální přístupy.
Uvedeme pozoruhodné aspekty významu věty a jejich slučitelnost s oběma proudy výzkumu a poté shrneme podklady vybrané pro tuto zvláštní otázku.
Předkládáme dvě případové studie, které prokazují, že soužití různých (pod)oborů komputační lingvistiky a nauky o přirozeném jazyce může vést k novým zjištěním a pomoci rozvoji oboru (oborů).
Jeden příklad pokrývá studium synonymie vyhledáváním informací v různých lexikálních zdrojích s ohledem na mnohojazyčnost a druhý ukazuje na studium některých jevů týkajících se informační struktury a pořadí slov v angličtině a češtině, jak lze paralelní vícejazyčný a/nebo vícevrstevný korpus, pokud je správně opatřen anotací, použít pro studium některých aspektů hloubkové syntaktické struktury.
Oba případy podporují naše přesvědčení, že tvorba jazykových zdrojů je základním krokem v hlavní úloze počítačové lingvistiky, že dobře definovaná anotace je důležitým krokem vpřed jak k testování původní jazykové teorie, tak k jejímu dalšímu rozvoji.
Vzpomínka na Michaela Alexandra Kirkwooda Hallidaye se zvláštní pozorností věnovanou jeho spojení s pražskými učenci.
Data paralelního anotovaného anglicko–českého korpusu byla použita ke zkoumání variability vzájemné pozice LOC a TWHEN v češtině a angličtině a k analýze vztahu mezi informační strukturou a daným pořadím v těchto dvou jazycích.
Na základě pražské teorie Topic/Focus Articulation a s využitím paralelního anglicko–českého korpusu jsme se zaměřili na dvě otázky: (i) Do jaké míry se shoduje Focus proper v angličtině a v češtině, (ii) pokud se Focus proper liší, platí alespoň, že Focus proper v angličtině je členem (globálního) Focusu v české větě?
Prezentujeme softwarové řešení a zkušenosti s provozem repozitáře pro jazyková data a nástroje pro zpracování přirozených jazyků - LINDAT/CLARIN.
Představíme unikátní podporu licencování s důrazem na Open Access a to, jak podporujeme všechny 4 klíčové principy FAIR.
Ukážeme vytváření záznamů včetně volby licence, jejich schvalování a publikaci editory, i prostředí pro administraci repozitáře včetně definice licencí, jejich podepisování a kontroly přístupu.
Ukážeme také integrace repozitáře s dalšími službami a provozní statistiky.
Overview of recent advances in cross-lingual information retrieval in the patient-centered web search.
Přehledná přednáška na téma vyhledávání informací napříč jazyky.
Tato práce se zaměřuje na sémantické role, důležitou součást studia lexikální sémantiky, neboť jsou zachyceny jako součást dvojjazyčného (česko-anglického) slovníku slovesných synonym (CzEngClass).
Tento slovník navazuje na existující valenční lexikony zahrnuté v rámci anotace různých pražských závislostních korpusů.
Současná analýza sémantických rolí je nastíněna z pohledu FGP a doložena příklady z korpusu, z Pražského česko-anglického závislostního korpusu.
Článek se věnuje popisu nesystémového valenčního chování českých deverbativních substantiv, jak se jeví na základě automatického srovnání valenčních rámců vzájemně propojených substantivních a slovesných lexikálních jednotek ve valenčních slovnících NomVallex a VALLEX.
Nesystémové valenční chování se v NomVallexu nejčastěji projevuje nesystémovými formami aktantů, zatímco změny v počtu a typu aktantů jsou co do počtu případů zanedbatelné.
Nesystémové formy významně přispívají k všeobecnému nárůstu počtu forem ve valenčních rámcích substantiv, ve srovnání s počtem forem ve valečních rámcích jejich základových sloves.
Nesystémové formy jsou častější ve valenčních rámcích neproduktivně tvořených substantiv než ve valenčních rámcích substantiv tvořených produktivně.
Data Pražského česko-anglického závislostního korpusu (Prague Czech-English Dependency Treebank, PCEDT) posloužila jako materiál pro srovnávací studii věnovanou vydělování adverbiálních významů místního určení "v rámci daného místa".
České předložkové skupiny obsahující předložky v, na a u vyjadřující výše uvedené místní určení byly srovnány s jejich anglickými ekvivalenty a byly dále rozděleny do tří sémantických podskupin, konkrétně "uvnitř", "na povrchu" a "v daném místě".
Naše analýza potvrdila, že přestože oba jazyky strukturují realitu jiným způsobem, lze vypozorovat určité tendence ve vztahu forem a jejich funkcí, které vedou k jemnější klasifikaci daných adverbiálních významů.
Jedná se o studii popisující aktuálně probíhající výzkum.
V článku jsou popsány systematické změny, které jsou realizovány v českém morfologickém slovníku v souvislosti s anotací nových dat v Pražských závislostních korpusech.
Přináší řešení několika komplikovaných morfologických jevů, které se objevují v českých textech.
Představeny jsou dva nové slovní druhy: cizí slovo a segment.
Popisují se pravidla pro reprezentaci variantních a homonymních tvarů a slov (lemmat), pravidla pro zachycení zkratek a tzv. agregátů (např. naň).
Změny ve slovníku jsou prováděny za účelem vyšší konzistence mezi daty a slovníkem a  v slovníku samotném.
Příspěvek se zabývá tvořením vidového protějšku u přejatých slovesných neologismů v češtině.
To, zda je vidový protějšek tvořen sufixací či prefixací, závisí - podle mé hypotézy diskutované v příspěvku - na tom, zda je báze neologismu v češtině interpretovaná jako slovesná nebo nominální.
Příspěvek popisuje poloautomatickou proceduru, při níž byly vztahy mezi základovými slovy a jejich deriváty v lexikální síti DeriNet označkovány sémantickými značkami.
V prezentovaném pilotním experimentu, který byl omezen na pět sémantických značek (diminutiva, posesiva, ženské protějšky maskulin, iterativa a vidové významy), byla data značkována metodami strojového učení.
Představujeme návrh projektu pro automatické generování scénářů divadelních her.
Navrhujeme hierarchický postup generování založený na expanzi textu (inverze sumarizace textu), která iterativně rozgenerovává název hry, dokud není vygenerován celý scénář.
Diskutujeme výzvy projektu a navrhujeme pro ně řešení.
Podobně jako v jiných oborech, zpracování přirozeného jazyka prošlo nedávno revolucí zavedením hlubokého učení.
V mé přednášce se zaměřím na dvě specifické vlastnosti přírozeného textu jako vstupu pro systém strojového učení a na současné způsoby, jakými jsou v hlubokých neuronových sítích řešeny: - Reprezentace masivně vícehodnotových diskrétních dat (slov) kontinuálními nízkodimenzionálními vektory (slovní embedinky).
- Zpracování vstupních sekvencí s proměnnou délkou pomocí vztahů na dlouhou vzdálenost mezi elementy (větami) neurálními jednotkami pevné velikosti (mechanismy pozornosti).
CoNLL 2018 Shared Task, tým CUNI-x-ling -- zdrojové kódy pro soutěž ve vícejazyčném syntaktickém parsingu
Zkoumáme, do jaké míry lze flexi automaticky oddělit od derivace, jen na základě slovních forem.
Očekáváme, že při použití vhodné míry vzdálenosti budou páry vyskloňovaných tvarů stejného lemmatu k sobě blíže než páry vyskloňovaných forem dvou různých lemmat (stále odvozených od stejného kořene).
Vzdálenosti slovních tvarů odhadujeme pomocí editační vzdálenosti, která představuje podobnost založenou na znacích, a pomocí podobnosti slovních embedinků, která slouží jako proxy k významové podobnosti.
Konkrétně zkoumáme Levenshteinovu a Jarovu-Winklerovu editační vzdálenost a kosinovou podobnost FastTextových slovních embedinků.
Vyhodnocujeme oddělitelnost flexe a derivace na vzorku z databáze DeriNet, což je databáze slovotvorných vztahů v češtině.
Zkoumáme míry vzdálenosti slov jednak přímo a jednak a jako složku shlukovacího postupu.
Nejlepších výsledků je dosaženo kombinací Jarovy-Winklerovy editační vzdálenosti a kosionové podobnosti slovních embedinků, která překonává míry použité samostatně.
Další analýza ukazuje, že metoda funguje lépe pro některé třídy flexí a derivací než pro jiné, což ukazuje některá omezení metody, ale také podporuje myšlenku nahrazení binární dichotomie flexe-derivace kontinuální škálou.
Zaměřujeme se na úlohu neřízené lemmatizace, tj.
seskupení vyskloňovaných forem jednoho slova pod jeden štítek (lemma) bez použití anotovaných trénovacích dat.
Navrhujeme provádět aglomerativní shlukování slovních forem s novou mírou vzdálenosti.
Naše míra vzdálenosti je založena na pozorování, že flexe jednoho slova mají tendenci být podobné řetězcově i významově.
Proto kombinujeme kosinovou podobnost slovních embedinků, která slouží jako proxy k významové podobnosti, s editační vzdáleností Jaro-Winklera.
Naše experimenty na 23 jazycích ukazují, že náš přístup je slibný a překonal baseline pro 23 z 28 testovacích sad.
Představení výzkumu automatického vyhodnocování koherence v češtině s pomocí naanotovaných velkých dat.
Využíváme velkých neanotovaných dat (n-gramový model, odhady hustoty featur) ke zlepšení kvality automatického hodnocení koherence textů v češtině.
Spolu s novými featurami z různých jazykových rovin přispělo využití neanotovaných dat k signifikantnímu zlepšení výsledků systému.
V tomto článku popisujeme naše systémy předložené v rámci soutěže Building Educational Applications (BEA) 2019 Shared Task (Bryant a kol., 2019).
Zúčastnili jsme se všech tří variant.
Naše modely jsou systémy NMT založené na architektuře Transformer, který vylepšujeme začleněním několika vylepšení: dropout celých zdrojových a cílových slov, vážení cílových podslov, průměrování modelu a použití trénovaného modelu iterativním způsobem.
Systém v Restricted Track je trénován na poskytnutých korpusech s nadměrně zesílenými "čistšími" větami a na testovací sadě dosahuje skóre 59,39 F0,5.
Systém v režimu nízkých zdrojů je trénován z historie revizí Wikipedie a dosahuje skóre 44,13 F0,5.
V neomezeném režimu jsme dotrénováním systému z režimu nízkých zdrojů dosáhli 64.55 F0.5 skóre a obsadili tak třetí místo.
Automatická oprava gramatiky v angličtině je dlouho studovaný problém s mnoha existujícími systémy a datovými zdroji.
Výzkum oprav chyb v jiných jazycích je však pouze omezený.
V této práci představujeme nový dataset AKCES-GEC pro gramatickou korekci chyb pro češtinu.
Dále provádíme experimenty na češtině, němčině a ruštině a ukazujeme, že při využití syntetického paralelního korpusu může model neuronového strojového překladu Transformer dosáhnout na těchto datasetech nejlepších známých výsledků.
AKCES-GEC vychází pod licencí CC BY-NC-SA 4.0 na adrese https://hdl.handle.net/11234/1-3057 a zdrojový kód modelu GEC je k dispozici na adrese https://github.com/ufal/low-resource-gec-wnut2019.
Tento článek představuje výsledky sdílených úkolů z 6. workshopu o asijském překladu (WAT2019), včetně dílčích úkolů Ja↔En, Ja↔Zh pro překlad vědeckých článků, Ja↔En, Ja↔Ko, Ja↔En pro překlad patentů, Hi↔En, My↔En, Km↔En, Ta↔En pro překlad smíšených doménových dílčích úkolů, Ru↔Ja komentář pro překlad zpráv a En pro multimodální překlad.
V rámci programu WAT2019 se sdílených úkolů účastnilo 25 týmů.
Obdrželi jsme také 10 písemných podání k výzkumu, z nichž 71 bylo přijato.
Automatickému hodnotícímu serveru bylo předloženo asi 400 výsledků překladu a vybraná podání byla ručně vyhodnocena.
Využití modelů řízených daty pro sumarizaci textu nebo podobné úlohy se v posledních letech stává velmi běžným.
Zatímco většina studií hlásí pouze základní přesnost, není nic známo o schopnosti zmíněných modelů se zlepšit, jsou-li trénovány na větších datech.
V tomto příspěvku definujeme a navrhujeme tři metriky efektivity dat: efektivita úspěšnosti dat, časové nedostatečnosti dat a celkové účinnosti dat.
Navrhujeme také jednoduché schema využívající těchto metod a využívající je pro ucelenější hodnocení populárních metod sumarizace textů a generování nadpisů.
Pro druhou z úloh zpracováváme a uvol%nujeme rozsáhlou kolekci 35 miliónů párů abstrakt-název vědeckých článků.
Naše výsledky odhalují, že mezi tetovanými metodami je Transformer nejúčinnější pro obě úlohy.
Klíčová slova, která svým vědeckým článkům přiřadili jejich autoři jsou nepostradatelná pro rozpoznání obsahu a témat dané článku.
Většina řízených i neřízených metod generování klíčových slov není schopna přiřazovat termíny, které to dobře vystihují, ale nevyskytují se v textu.
V tomto příspěvku zkoumáme možnost klíčových slov coby shrnutím názvu práce a abstraktu.
Nejdříve sesbíráme, zpracujme a vydáme velkou sadu metadat vědeckých článků čítajících 2,2 milionu záznamů.
Pak vyzkoušíme populární neurální architektury pro sumarizaci textů.
Na rozdíl od pokročilých metod hlubokého učení, velkých objemů dat a mnoha dní výpočtů naše systematické vyhodnocování na čtyřech testovacích sadách dat ukázalo, že zkoumané metody sumarizace textu nemohou vytvořit lepší klíčová slova než jednoduché neřízené či řízené metody.
V oblasti online komunikace, komerce a překladů, se analýza polarity sentimentu textů napsaných v různých přirozených jazycích stává zásadní.
Zatímco pro angličtinu je k dispozici mnoho příspěvků a zdrojů, "menší" jazyky, jako je čeština, se zatím netěší větší pozornosti.
V tomto přehledu zkoumáme efektivitu mnoha algoritmů strojového učení pro analýzu sentimentu příspěvků na českém Facebooku a recenzí různých produktů.
Sepíšeme sady optimálních hodnot parametrů pro každý algoritmus a ohodnocení v obou datasetech.
Nakonec zaznamenáme, že metoda podpůrných vektorů je nejlepším klasifikátorem a snahy dále zlepšit výkon pomocí baggingu, boostingu, či hlasovacích schemat selhaly.
V tomto článku studujeme abstraktiví sumarizaci videí bez doménového omezení.
Na rozdíl od tradiční sumarizace zpravodajských textů není cílem "komprimovat" textové informace, ale spíše poskytnout plynulé textové shrnutí informací, které byly shromážděny z různých zdrojových modalit, v našem případě videozáznamů a audio přepisů (nebo textu).
Ukazujeme, jak vícezdrojový model sekvenčního učení s hierarchickým mechanismem pozorností dokáže integrovat informace z různých modalit do uceleného výstupu, porovnáváme různé modely trénované s různými modalitami a prezentuje pilotní experimenty na How2 korpusu instruktážních videí.
Navrhujeme také novou hodnotící metriku (Conent F1) pro abstraktivní sumarizaci, která měří spíše sémantickou adekvátnost než plynulost, kterou naopak zachcují tradiční metriky jako jako ROUGE a BLEU.
Článek představuje experimentální výzkum srovnávající, jak jsou texty psané nerodilými mluvčími češtiny hodnoceny softwarovou aplikací EVALD a učiteli češtiny jako cizího jazyka.
Představujeme první kompletní hlasový dialogový systém řízený multidimenzionálním statistickým dialogovým manažerem.
Tento framework prokazatelně významně snižuje potřebu dat využitím doménově nezávislých dimenzí, jako jsou společenské konvence nebo zpětná vazba, které (jak ukazujeme) lze přenášet mezi doménami.
V tomto článku provádíme uživatelskou sudii a ukazujeme, že výkon multidimenzionálního systému, který lze adaptovat ze zdrojové domény, je ekvivalentní výkonu jednodimenzionální baseline, kterou je třeba natrénovat od nuly.
Přednáška představuje výsledky anotace implicitních vztahů v češtině na základě korpusu PDiT-EDA 1.0.
Zaměřuje se na distribuci implicitních a explicitních vztahů, jejich sémantiku, přítomnost větné negace a vztah implicitnosti k textovému žánru.
Analyzujeme některé faktory ovlivňující explicitnost/implicitnost diskurzních vztahů, např. žánr textu, sémantický typ diskurzního vztahu a přítomnost negace v diskurzních argumentech.
Předkládáme popis našeho příspěvku do soutěže CoNLL 2019, Cross-Framework Meaning Representation Parsing (MRP 2019).
Navržená architektura je naším prvním pokusem o sémantický parsing v rámci UDPipe 2.0, nástroje pro lemmatizaci, POS tagging a závislostní parsing.
Pro MRP 2019, který zahrnuje pět formálně a lingvisticky rozdílných přístupů k reprezentaci významu (DM, PSD, EDS, UCCA a AMR), navrhujeme uniformní, jazykově a formálně agnostickou architekturu založenou na transformaci grafů pomocí umělých neuronových sítí.
Bez jakékoli znalosti grafové struktury, a specificky bez jakýchkoli lingvisticky nebo formálně motivovaných klasifikačních rysů náš systém implicitně modeluje reprezentaci významu v grafu.
Po opravě člověkem způsobené chyby (použili jsme nesprávnou verzi poskytnutých analýz testovacích dat) se náš příspěvek umístil na třetím místě v soutěžním hodnocení.
Zdrojový ḱód našeho systému je dostupný na adrese https://github.
com/ufal/mrpipe-conll2019.
Nedávno byly navrženy kontextové embeddingy, které vhodně zachycují význam slova v závislosti na kontextu.
V tomto příspěvku vyhodnocujeme dvě metody pro výpočet takových embeddingů, BERT a Flair, na čtyřech úlohách zpracování přirozeného jazyka v češtině: značkování slovních druhů (POS tagging), lemmetizace, závislostní parsing a rozpoznávání pojmenovaných entit.
První tři úlohy jsou vyhodnoceny na dvou korpusech: Pražský závislostní korpus 3.5 a Universal Dependencies 2.3.
Rozpoznávání pojmenovaných entit je vyhodnoceno na Českém korpusu pojmenovaných entit (Czech Named Entity Corpus) 1.1 a 2.0.
Publikujeme state-of-the-art výsledky ve všech výše zmíněných úlohách na všech korpusech.
Představujeme rozsáhlé hodnocení tří nedávno navržených metod pro kontextualizované embeddiny na 89 korpusech v 54 jazycích projektu Universal Dependencies 2.3 ve třech úkolech: POS tagging, lemmatizace a závislostní analýza.
Využitím BERT, Flair a ELMo jako předtrénovaných embeddingů do systému UDPipe 2.0, jednoho z vítězů CoNLL 2018 Shared Task a celkového vítěze EPE 2018, představujeme porovnání těchto tří kontextualizovaných metod, word2vec předtrénovaných embedingů a trénovatelných embedingů založených na znacích slov.
Popsané metody dosahují nejlepších známých výsledků na UD 2.2 v porovnání s výsledky na CoNLL 2018 Shared Task.
Představujeme náš příspěvek k shared tasku SIGMORPHON 2019: Crosslingualita a kontext v morfologii, úkol 2: kontextová morfologická analýza a lemmatizace.
Odevzdali jsme modifikaci UDPipe 2.0, jednoho z výherního systému CoNLL 2018 Shared Task: Multilingual Parsing from Raw Text to Universal Dependencies a celkového vítěze The 2018 Shared Task on Extrinsic Parser Evaluation.
Jako první vylepšení používáme předtrénované kontextualizované embeddingy (BERT) jako další vstupy do sítě, za druhé používáme jednotlivé morfologické vlastnosti jako regularizaci a nakonec slučujeme vybrané korpusy stejného jazyka.
V lemmatizačním úkolu náš systém výrazně převyšuje všechny ostatní systémy s přesností lemmatizace 95,78 (druhý nejlepší byl 95,00, třetí 94,46).
V morfologické analýze se náš systém umístil těsně druhý: přesnost naší morfologické analýzy byla 93,19, vítězný systém měl 93,23.
Universal Derivations (UDer) je sada lexikalních sítí zachycujících slovotvorné, zvl.
derivační vztahy jednotlivých jazyků, tyto sítě byly harmonizovány do jednotného formátu.
Stávající verze UDer v0.5 obsahuje 11 harmonizovaných zdrojů pokrývajících 11 různých jazyků.
Cílem tohoto článku je otevřít diskusi o harmonizaci existujících datových zdrojů zabývajících se derivační morfologií.
Představujeme nově vytvořený soubor jedenácti harmonizovaných zdrojů pojmenovaný „Universal Derivations“ (zjevně inspirovaný úspěchem iniciativy Universal Dependencies mezi syntakticky anotovanými korpusy) a harmonizační proces, kterým jsme tyto zdroje sjednotili do stejného anotačního schématu.
Užitečnost jazykových anotací v překladu do neurálních strojů byla zřejmě prokázána v minulých pracích.
Pokusy se však omezovaly na opakující se sekvenční architektury a relativně malé nastavení dat.
Zaměřujeme se na nejmodernější model Transformeru a používáme srovnatelně větší korporáty.
Konkrétně se snažíme podporovat znalosti syntaxe na zdrojové straně pomocí víceúkolového učení buď pomocí jednoduchých technik manipulace s daty, nebo pomocí speciální modelové komponenty.
Konkrétně jednoho cvičíme Transformer se soustředí na vytvoření stromu závislosti na straně zdroje.
Celkově naše výsledky zpochybňují užitečnost víceúkolových sestav s jazykovými informacemi.
Techniky manipulace s daty, doporučované v předchozích dílech, se v nastavení velkých dat ukazují jako neúčinné.
Zacházení se sebepozorností jako se závislostmi se zdá mnohem slibnější: pomáhá při překladu a odhaluje, že model Transformer dokáže velmi snadno uchopit syntaktickou strukturu.
Důležitým, ale kuriózním výsledkem však je, že identického zisku se dosáhne použitím triviálních ,,lineárních stromů`` namísto skutečných závislostí.
Přínos tedy nemusí vyplývat z přidaných jazykových znalostí, ale z nějakého jednoduššího regularizačního efektu, který jsme navodili u matricí, které se věnují samy sobě.
V článku přestavuje náš přísvek do soutěže v robustním strojovém překaladu na konferenci WMT19.
Náš základní systém je CUNI Transformer systém trénovaný překlad novinových textů pro WMT18.
Kvantitativní výsledky ukazují, že systém CUNI Transformer je již mnohem robustnější základní model založený na LSTM, který poskytli organizátoři soutěže.
Kvalitu překladu našeho modelu jsme dále vylepšili vyladěním na zašuměných datech, která byla poskytnuta k soutěži.
Filtry konvolučních neuronových sítí používaných v počítačovém vidění se často vizualizjí jako malé čtevrcové obrázky, které maximalizují odezvu filtru.
V tomto abstraktu používáme stejný postup při interpretaci váhových matic v jednoduchých architekturách pro úkoly zpracování přirozeného jazyka.
Intepretujeme konvoluční neuronovou síť pro klasifikaci sentimentu jako slovní pravidla.
Pomocí těchto pravidel jsme schopni rokonstruovat fungování původního modelu.
Vícejazyčný BERT (mBERT) poskytuje větné reprezentace pro 104 jazyků, které jsou užitečné pro mnoho vícejazyčných úloh.
Předchozí práce zkoumala mnohojazyčnost mBERTu s využitím nulového transferového učení na morfologických a syntaktických úkolech.
Místo toho se soustředíme na sémantické vlastnosti mBERTu.
Ukazujeme, že reprezentace mBERT mohou být rozděleny na jazykově specifickou složku a jazykově neutrální složku a že jazykově neutrální složka je dostatečně obecná, pokud jde o modelování sémantiky, aby umožnila vysoce přesné zarovnání slov a vyhledávání vět, ale zatím není dostatečně dobrá pro obtížnější úkol odhadu kvality MT.
Naše práce přináší zajímavé výzvy, které musí být vyřešeny, aby bylo možné sestavit lepší jazykově neutrální reprezentace, zejména u úkolů vyžadujících jazykový přenos sémantiky.
Lexikální desambiguace je úlohu, při které má být zvolen ten význam slova, který je v daném kontextu relevantní.
V posledních letech můžeme pozorovat úspěšnou aplikaci vektorových reprezentací slov napříč různými úlohami v oblasti zpracování přirozeného jazyka.
Vzhledem ke schopnosti těchto vektorových reprezentací odrážet distribuční sémantiku byla v nedávné době věnovaná pozornost i možnosti využití pro lexikální desambiguaci.
V tomto článku navrhujeme novou neřízenou metodu pro lexikální desambiguace v jednom jazyce s využitím vektorových reprezentací natrénovaných pro jiný jazyk a překladového slovníku.
V našich experimentech byly pro lexikální desambiguaci perských slov využity vektorové reprezentace anglických překladů slov z blízkého kontextu.
Každý možný překlad polysémního slova je porovnán s vektorovými reprezentacemi okolních slov, z toho je vygenerováno podobnostní skóre, přičemž překladový ekvivalent s nejvyšším skóre reprezentuje zvolený význam.
Tato metoda vyžaduje pouze neznačkovaný korpus a překladový slovník.
Úspěšnost našeho přístupu je ilustrovaná na malém vzorku ručně desambiguovaných dat.
ílem sdíleného úkolu o automatickém rozlišení mezer v ruštině (AGRR2019) v roce 2019 je boj proti netriviálnímu lingvistickému jevu, který se vyskytuje v koordinovaných strukturách, a eliminuje opakovaný predikát, obvykle z druhé věty.
V tomto článku definujeme metriku úkolů a hodnocení, poskytujeme podrobné informace informace o přípravě údajů, schématech anotace a metodice, analyzovat výsledky a popsat různé přístupy účastníka řešení.
Popisujeme naše čtyři systémy neuronového strojového překladu (NMT), které jsme odeslali do shared tasku IWSLT19 pro anglicko-český překlad  TED Talks.
Cílem této studie je porozumět interakcím mezi NMT na úrovni dokumentů a doménovou adaptací.
Všechny naše systémy jsou založeny na modelu Transformer implementovaném ve frameworku Tensor2Tensor.
Dva ze systémů slouží jako baseline a nejsou přizpůsobeny doméně TED Talks: SENTBASE je trénován na jednotlivých větách, DOCBASE na vícevětných (document-level) sekvencích.
Další dva předložené systémy jsou přizpůsobeny doméně TED Talks: SENTFINE je adaptován na jednotlivých větách, DOCFINE na vícevětných sekvencích.
Představujeme jak automatické metrické hodnocení, tak manuální analýzu kvality překladu se zaměřením na rozdíly mezi těmito čtyřmi systémy.
Naším cílem je anotace korpusu CzeSL podle gramatiky jazyka, se kterou pracuje nerodilý mluvčí, a ne podle standartní gramatiky.
Tento přístup přináší několik problémů.
Za prvé nemáme dostatek dat na to, abychom analyzovali gramatiky jednotlivých autorů.
Za druhé v jazyce nerodilých mluvčí je podstatně více složitějších jevů  než v jazyce rodilých mluvčí.
V současných neuronových systémech pro strojový překlad textů přirozeného jazyka (NMT) se morfologicky příbuzná slova zpracovávají jejich rozdělením na podslovní jednotky takovým způsobem, aby se slovník jednotek vešel do limitů daných zvoleným NMT modelem a do paměti grafické karty.
V tomto článku srovnáváme dva nejobvyklejší, nelingvistické, způsoby vytváření podslovních jednotek (BPE a STE, metody implementované v nástroji Tensor2Tensor) se dvěma lingvisticky motivovanými způsoby: Nástrojem Morfessor a námi vyvinutou metodou založenou na derivačních vztazích.
Naše experimenty s překladem z němčiny do češtiny, morfologicky bohatých jazyků, ukazují, že prozatím mají lepší výsledky nelingvistické metody.
K tomu identifikujeme důležitý rozdíl mezi BPE a STE a ukazujeme, že jednoduché předzpracování textu před BPE výrazně zvyšuje kvalitu překladu vyhodnocovanou automatickými metrikami.
Tato práce porovnává kvalitu a rychlost systémů pro neuronový strojový překlad (Tensor2Tensor, Marian, Nematus, Neural Monkey, OpenNMT) na dvou srovnatelných překladových úlohách.
Extrakce syntaktických struktur z self-attentions NMT enkodéru.
Extrakce syntaktických struktur z self-attentions NMT enkodéru.
Extrakce syntaktických struktur z self-attentions enkodéru Transformeru.
Extrakce syntaktických struktur z self-attentions enkodéru Transformeru
Modely strojového učení přinášejí slibné výsledky v mnoha oborech včetně zpracování přirozeného jazyka.
Tyto modely jsou nicméně náchylné k adversálním příkladům.
Jedná se o uměle vytvořené příklady s dvěma důležitými vlastnostmi: podobají se skutečným tréninkovým příkladům, ale matou již natrénovaný model.
Tento článek zkoumá účinek používání adversálních příkladů při tréninku rekurentních neuronových sítí, jejichž vstup je ve formě slovních či znakových embeddingů.
Účinky jsou studovány na kompilaci osmi datasetů.
Na základě experimentů a charakteristik datasetů dospíváme k závěru, že použití adversálních příkladů pro úkoly zpracování přirozeného jazyka, které jsou modelovány pomocí rekurentních neuronových sítí, přináší efekt regularizace a umožňuje trénovat modely s větším počtem parametrů bez overfittingu.
Na závěr popisujeme, které kombinace datasetů a nastavení modelů by mohly mít z adversálního tréninku největší prospěch.
Příspěvěk se zabývá otázkou, jak může syntaktická vlastnost sloves, jako je reciprocita, být promítnuta do slovníka a přispět k dalšímu popisu a klasifikaci sloves.
Popisujeme první volně dostupný závislostní korpus sanskrtu.
Je založen na textech z Paňčatantry, starověké indické sbírky bajek.
Zvolili jsme formalismus Universal Dependencies, který v současnosti představuje faktickou normu mezijazykově srovnatelné morfologické a syntaktické anotace.
V článku probíráme obtíže se segmentací textu na slova, představujeme inventář morfologických kategorií, jakož i některé syntaktické konstrukce, které jsou zajímavé ve světle pravidel Universal Dependencies.
Dále popisujeme experiment s automatickou syntaktickou analýzou (parsingem).
Tento článek popisuje CUNI system na WAT 2018 pro překlad mezi angličtinou a Hindštinou.
Náš systém využívá transfer learningu z anglicko-českého modelu.
Využíváme technologii neuronového transformeru.
Náš systém začíná trénováním na jazykovém páru s mnoho paralelními daty, česko-anglickém, na který naváže jazykový pár s nedostatkem dat.
Náš systém se umístil první podle lidského hodnocení.
Tento článek popisuje dvoustupňovou metodu přepisu historických rukopisů.
V této metodě používá první krok reprezentaci na stránce, což usnadňuje přepis dokumentu po stránce a řádku po řádku, zatímco druhý krok to převádí do textového formátu TEI / XML, aby zajistit, aby byl dokument plně prohledávatelný.
Představujeme uživatelské rozhraní mezi českým valenčním lexikonem, PDT-Vallex [1] a KonText1 - webová aplikace pro dotazování na korpusy dostupné v rámci projektu LINDAT / CLARIN.
KonText umožňuje vyhodnocování jednoduchých a komplexních dotazů, zobrazování výsledků jako shodných linek, výpočet distribuce frekvence, výpočet asociačních opatření pro kolokace a dále práce s jazykovými daty.
Pro každé sloveso ve shodné lince umožňuje naše rozhraní zobrazit informace o jeho valenčním rámci v samostatném okně, pokud existují odpovídající položky PDT-Vallex, stejně jako seznam možných valenčních rámců pro toto konkrétní sloveso.
Informace týkající se slovesného rámu obsahuje lemma slovesa, prvky rámce se sémantickými rolami, slovník slovníku popis a příklady z PDT-Vallex, Praha Dependency Treebank [2] a Praha Česko-anglická závislostní stromová banka [3].
Informace jsou požadovány z REST-API z valenční lexikon PDT-Vallex, který obsahuje přes 11000 valenčních rámců pro více než 7000 sloves která se objevila v pražské Dependency Treebank, Praha Czech-English Dependency Treebank nebo Praha závislost Treebank mluveného češtiny.
Používáme vidlici aplikace KonText (vyvinutá Ústavem českého národního korpusu), který byl dále rozšířen Ústavem formální a aplikované lingvistiky, aby vyhovovaly potřebám projektu LINDAT / CLARIN.
Plugin jsme present poskytuje unikátní řešení pro český jazyk, které integruje valenční informace z Český valenční lexikon s prostředky dotazování na pražskou Závislostní bankou.
Rozbalení pomocí křížových značek je založeno na nahrazení jedné vrstvy anotací za jinou při zpracování dat v jednom jazyce.
Nejčastěji není k dispozici ani rodný značkovač nebo syntaktický analyzátor závislostí používaný v (před) anotaci Gold stromové banky.
Přístup přes křížové štítky umožňuje anotovat nové texty pomocí volně dostupných nástrojů nebo nástrojů optimalizovaných podle potřeb uživatele.
Vyhodnocujeme robustnost analyzování ruské závislostí s použitím různých morfologických a syntaktických tagů ve vstupu a výstupu.
Kvalitativní analýza chyb ukazuje, že křížová substituce tří morfologických značek a dvou syntaktických značek způsobuje pouze mírný pokles výkonu.
Umělé závislostní stromy v anotačním stylu Universal Dependencies v2, zaměřené na druh elipsy zvaný anglicky gapping (v UD odpovídá vztahu 'orphan').
Motivace a popis těchto dat je obsažen v Droganova et al., 2018 (LREC, Miyazaki, Japonsko).
V této práci se zaměřujeme na konkrétní jazykový jev, elipsu, a zkoumáme výstupy současných parserů, abychom zjistili jejich úspěšnost a typické chyby s ohledem na elipsy.
K tomuto účelu jsme sebrali a zpracovali výstupy několika nejlepších parserů, které se zúčastnily společné úlohy CoNLL 2017.
Oficiální vyhodnocovací software jsme rozšířili, aby bylo možné zjistit chyby v analýze elips.
Protože studované struktury jsou poměrně vzácné, a tudíž není k dispozici dostatečné množství dat pro experimenty, popisujeme dále tvorbu nového datového zdroje, polouměle vytvořeného závislostního korpusu elips.
Popisujeme pokusy s několika přístupy k automatickému rozšíření trénovacích dat pro závislostní syntaktické analyzátory s využitím velkých webových korpusů.
Jedna sada metod je obecná, inspiruje se samotrénováním a trojtrénováním a přidává nový algoritmus, který napodobuje strukturální složitost původního treebanku.
Metody ve druhé sadě se více zaměřují na eliptické konstrukce.
Pokusy vyhodnocujeme na 5 jazycích: češtině, angličtině, finštině, ruštině a slovenštině.
Tento příspěvek shrnuje diskusi skupiny aktivních výzkumníků rozpoznávání notopisu (Optical Music Recognition, OMR), která se konala v rámci 12th IAPR International Workshop on Graphics Recognition, a prezentuje její výstupy: OMR by mělo zpřesnit svou terminologickou a taxonomickou základnu, a komunita výzkumníků v oboru by měla intenzivněji spolupracovat jak mezi sebou, tak se zájemci o OMR.
Představujeme LemmaTag, architekturu neuronové sítě, která společně generuje morfologické značky a lemmata pomocí obousměrných rekurentních neuronových sítí pomocí slovních a znakových embeddingů.
Demonstrujeme, že oběma úkolům pomáhá sdílet enkodér, předvídat podtypy značek a používat předpovězené značky na vstup lemmatizátoru.
Vyhodnocujeme náš model na několika jazycích se složitou morfologií, a překonáváme nejlepší známé výsledky jak morfologického značkování tak lemmatizace v češtině, němčině a arabštině.
V tomto příspěvku popisujeme metody a výsledky výzkumu zaměřeného na vícejazyčné korpusové srovnání spojovacího výrazu "and" v angličtině a jeho ekvivalentů v češtině, francouzštině, maďarštině a litevštině u vybraných příspěvků z TED talks.
Analýza funkcí spojovacího výrazu AND a jeho ekvivalentů v angličtině, češtině, litevštině, francouzštině a maďarštině podle doménové klasifikace Crible - Degand (2017).
Mezijazykové srovnání funkcí spojky "a" a možností jejího překladu, založené na paralelních překladech titulků v TED talks.
Výchozí studie o nespecifičnosti významu některých spojek v různých jazycích.
V lingvistice se obvykle slova považují za složená z morfémů, což jsou dále nedělitelné jazykové jednotky nesoucí význam.
Zadáním této práce je nalézt automatickou metodu dělení českých slov na morfémy, které by bylo možné přidat do DeriNetu, sítě derivačních vztahů mezi českými slovy.
Vytvořili jsme dvě různé takové metody.
První nalézá hranice morfémů na základě hledání rozdílů mezi slovem a jeho derivačním předkem, a tranzitivně mezi všemi slovy v derivačním hnízdě.
Tato metoda explicitně modeluje hláskové a morfologické alternace a nalézá nejvhodnější hranice morfémů pomocí metody maximální věrohodnosti.
Ve srovnání s moderním systémem Morfessor FlatCat naše metoda přinejhorším mírně zaostává, ovšem v některých testech naopak dosahuje výsledků výrazně lepších.
Druhou metodou je neuronová síť pro současné předpovídání morfologické segmentace a derivačních předků, trénovaná na datech získaných první metodou a na derivačních vztazích ze sítě DeriNet.
S naší hypotézou, že tento způsob trénování dvou úloh naráz pomůže k dosažení lepších výsledků oproti trénování samotné segmentace, jsou však ve shodě pouze některé provedené pokusy.
Celkově dosahuje neuronová síť horších výsledků než první metoda, pravděpodobně kvůli trénování na datech obsahujících chyby, které se tím přidávají k chybám metody samotné.
Článek analyzuje kompatibilitu stávající kategorizace licencí v CLARINu s paradigmatem Open Science.
V první části se prezentují základní koncepty a teoretický rámec, druhá část řeší kategorizaci licencí v projektu CLARIN do tříd PUB, ACA a RES a možnosti do budoucna tento systém změnit.
Varianty možných změn jsou analyzovány jako podklad k další diskusi o změně přístupu k licencím v CLARINu.
Zkoumáme anotaci zvratných zájmen v korpusech Universal Dependencies (UD) 2.2 (Nivre et al., 2018), přičemž se zaměřujeme zejména na slovanské jazyky.
Snažíme se zjistit, zda jsou současná anotační pravidla dostatečně jasná, aby se jimi anotátoři dokázali řídit.
Ukazujeme celou řadu nesrovnalostí napříč jazyky v současných datech a navrhujeme vylepšení–někdy anotačních pravidel, většinou však přímo anotace dat.
Cílem článku je přispět ke konzistentnější a mezijazykově paralelnější anotaci reflexiv v budoucích vydáních UD.
Tento článek se věnuje přiřazování audia přímo k notopisu reprezentovanému jako obraz, bez jakýchkoliv abstratktních reprezentací.
Navrhujeme metodu, která se naučí společný prostor pro reprezentaci krátkých útržků audia a jejich protějšků v obrázkách not pomocí multimodálních konvolučních neuronových sítí.
Následně ukazujeme, jak s těmito naučenými reprezentacemi (1) identifikovat příslušnou skladbu podle nahrávky, (2) vyhledávat nahrávky pomocí obrázků not.
Všechny vyhledávací modely jsou natrénované na novém velkém multimodálním datasetu audia a notopisu, který je spolu s tímto článkem dán veřejně k dispozici.
Dataset obsahuje 479 detailně anotovaných klavírních skladeb od 53 skladatelů, celkem 1129 stran not a více než 15 hodin k nim zarovnaného audia, které bylo z příslušných not syntetizováno.
Nad modelem natrénovaným těmito syntetickými daty však provádíme pokusy, které vyhledávají v databázi komplexních not (např. téměř celé dílo pro sólový klavír F. Chopina) a komerčních nahrávek špičkových klavíristů.
Naše výsledky naznačují, že navržená metoda spolu s velkým datasetem vede k vyhledávacím modelům, které úspěšně zobecňují ze syntetických trénovacích dat na skutečná data.
Současné modely pro křížové vyhledávání mezi nahrávkami a notovými zápisy přes natrénované multimodální reprezentace používají konvoluční neuronové sítě, jenž očekávají na vstupu pro audio pevně daný časový úsek.
Podle tempa nahrávky však toto okno zachycuje různá množství hudebních událostí (not), zatímco fixně dlouhé okno do not jich zachycuje množství, které na tempu téměř nezávisí.
V této práci se snažíme tento problém obejít pomocí mechanismu měkké pozornosti, která umožňuje modelu zakódovat pouze ty části útržku audia, které jsou nejvíce relevantní pro vybudování efektivního vyhledávacího klíče.
Experimentální výsledky na klasické klavírní hudbě ukazují, že pozornostní mechanismus vyhledávání zlepšuje, a má intuitivně jasné výhody.
Tento příspěvek se zabývá parafrázovatelností českých slovesných víceslovných výrazů (kategoriálních slovesa a idiomů).
V příspěvku je navržena lexikografická reprezentace parafrází a demonstrováno jejich praktické využití ve strojovém překladu.
Stručný úvod k panelu o umělé inteligenci a humanitních oborech představuje možnosti neuronového strojového překladu a hlubokého učení obecně pro lingvistiku.
V prezentaci jsem představil současnou úroveň kvality dosahovanou neuronovým strojovým překladem a podrobně se v diskusi věnoval očekávaným výhodám a rizikům, která do překladatelské profese přináší projekt ELITR.
Užíváme systém EVALD k automatickému ohodnocení výstupů několika systémů strojového překladu; výsledky ukazují, že automatické ohodnocení diskurzu v textech umožňuje rozlišit různé systémy strojového překladu.
Korpusová studie lokální koherence textu založené na anaforických vztazích mezi elementy v tématické (Topic) a rématické (Focus) části věty v různých žánrech textů Pražského závislostního korpusu.
Zkoumáme dvě dichotomie, kterými se zabývá literatura o informační struktuře věty, konkrétně dichotomii topic/focus založenou na vztahu "býti o čem", a dichotomii mezi danou a novou informací.
Zaměřujeme se obzvláště na otázku, zda dichotomie topic/focus může být založena na rozlišení mezi danou a novou informací, či zda vztah "býti o čem" tvoří přesnější obraz situace.
Synonymní slovník CzEngClass je výsledkem projektu zkoumajícího sémantickou „ekvivalenci“ slovesných významů a jejich valenčního chování v paralelních zdrojích česko-anglického jazyka, tj.
vztahujících se k slovním významům s ohledem na kontextuálně založená slovesná synonyma.
Položky lexikonu jsou propojeny s PDT-Vallexem (http://hdl.handle.net/11858/00-097C-0000-0023-4338-F), EngVallexem (http://hdl.handle.net/11858/00-097C-0000-0023-4337-2), CzEngVallexem (http://hdl.handle.html.net/11234/1-1512), FrameNetem (https://framenet.icsi.berkeley.edu/verbverbands/), VerbNetem (http://coloredu.html.html Součástí datového souboru je soubor odrážející volby anotátorů pro přiřazení sloves do tříd.
Synonymní slovník CzEngClass je výsledkem projektu zkoumajícího sémantickou „ekvivalenci“ slovesných významů a jejich valenčního chování v paralelních zdrojích česko-anglického jazyka, tj.
vztahujících se k slovním významům s ohledem na kontextuálně založená slovesná synonyma.
Položky lexikonu jsou propojeny s PDT-Vallexem (http://hdl.handle.net/11858/00-097C-0000-0023-4338-F), EngVallexem (http://hdl.handle.net/11858/00-097C-0000-0023-4337-2), CzEngVallexem (http://hdl.handle.html.net/11234/1-1512), FrameNetem (https://framenet.icsi.berkeley.edu/verbverbands/), VerbNetem (http://coloredu.html.html Součástí datového souboru je soubor odrážející volby anotátorů pro přiřazení sloves do tříd.
V článku se zaměřujeme na valency a synonymii sloves v bilingvním česko-anglickém kontextu.
Náš výzkum sémantické ekvivalence sloves je z pohledu syntaktického (včetně valence) založen na FGP a z pohledu sémantického je inspirován především FrameNetem a VerbNetem.
Jako hlavní zdroj korpusových dokladů používáme Pražský česko-anglický závislostní korpus 2.0.
Postup výzkumu “od spoda nahoru” považujeme za nový a adekvátní přístup pro stadium slovesné synonymie.
Synonymní česká a anglická slovesa jsou uskupeny do mezijazykových synonymních tříd v novém slovníku CzEngClass.
Tento slovník pro každé synonymní sloveso dané třídy obsahuje jak mapování valenčních argumentů na sémantické role, tak propojení s jednotlivými slovesnými významy ve FrameNetu, VerbNetu, ve Vallexech a v anglickém WordNetu, což ze slovníku CzEngClass zároveň vytváří bohatě propojený slovník.
Podíváme se na jeden ze základních kamenů taxonomie vztahů v Universal Dependencies, na tzv. core arguments (základní aktanty) a na způsoby, jak je lze odlišit od tzv. oblique dependents (vedlejší aktanty a volná doplnění).
Představím Universal Dependencies, celosvětový komunitní projekt zacílený na tvorbu mnohojazyčných korpusů anotovaných podle jednotných pravidel na morfologické a syntaktické rovině.
Proberu koncept základních aktantů (core arguments), jednoho z pilířů, na kterých stojí anotační schéma UD.
Ve druhé části přednášky se zaměřím na některé zajímavé problémy spojené s aplikací Universal Dependencies na slovanské jazyky.
Na příkladech z 12 slovanských jazyků, které jsou v současné době reprezentované v UD, ukážu, že na mezijazykové konzistenci je ještě stále co zlepšovat.
Testovací data rozebraná systémy, které se účastnily soutěže v syntaktické analýze Universal Dependencies při konferenci CoNLL 2018.
Konference o počítačovém učení přirozeného jazyka (CoNLL) každoročně zahrnuje tzv. společnou úlohu, tedy soutěž, jejíž účastníci trénují a testují své systémy strojového učení na jednotné sadě dat.
Jedna z úloh roku 2018 byla věnována učení závislostních syntaktických analyzátorů (parserů) pro velké množství jazyků, v reálné situaci bez jakýchkoli ručních anotací na vstupu.
Představujeme databázi forem a funkcí vybudovanou na podkladě ručně anotovaných víceúrovňových korpusů češtiny zvaných Pražské závislostní korpusy.
Pražská databáze forem a funkcí (ForFun) byla vytvořena, aby usnadnila lingvistické badání o vztahu funkce a formy, což je jeden z hlavních úkolů, jak v teoretické lingvistice, tak v oblasti počítačového zpracování jazyka.
V článku jsou představeny možnosti, jakým způsobem lze v databázi vztah funkce a formy zkoumat.
Článek je z větší části založen na již dříve prezentovaném příspěvku na 16th International Workshop on Treebanks and Linguistic Theories in Prague (Bejček et al., 2017).
Příspěvek se zaměřil na polyfunkčnost reflexiv v češtině, vymezení jejich hlavní funckí, které v jazyce plní a důsledky pro jejich popis ve slovníku.
Ačkoli treebanky anotované podle pravidel univerzálních závislostí (UD) dnes existují pro mnoho jazyků, cíl anotace stejných jevů křížově jazykově konzistentním způsobem není vždy splněn.
V této studii zkoumáme jeden jev, u něhož se domníváme, že takový soulad chybí, a to expletiva.
Takové prvky zaujímají pozici, která je strukturálně spojena s hlavním argumentem (nebo někdy s volnou závislostí), a přesto jsou nesouvisející a sémanticky prázdné.
Mnoho UD stromů označuje alespoň některé prvky za expletiva, ale škála jevů se liší mezi stromy, a to i u úzce příbuzných jazyků, a někdy dokonce u různých stromů pro stejný jazyk.
V tomto článku uvádíme kritéria pro určení výrazů, které jsou použitelná napříč jazyky a kompatibilní s cíli UD, poskytujeme přehled výrazů, které se nacházejí v současných UD stromech, a předkládáme doporučení pro anotaci expletiv, aby bylo možné v budoucích vydáních dosáhnout konzistentnější anotace.
Článek představuje analýzu českých slovesných předpon, což je první krok projektu, který má konečný cíl automatickou morfematickou analýzu češtiny.
Studovali jsme předpony, které se mohou vyskytnout v českých slovesech, zejména jejich možné a nemožné kombinace.
Popisujeme postup rozpoznávání předpon a odvozujeme obecná pravidla pro výběr správného výsledku.
Analýza "dvojitých" prefixů umožňuje vyvodit závěry o univerzálnosti první předpony.
Připojili jsme také lingvistické komentáře k několika typům předpon.
Článek seznamuje s výsledky automatické analýzy pořádku slov ve 23 závislostních korpusech projektu HamleDT.
Analýza se zaměřuje na základní vlasnosti pořádku slov, pořadí tří hlavních konstituentů - predikátu, subjektu a objektu.
Kvantitativní analýza je provedena zvlášť pro hlavní a vedlejší věty.
Příspěvek se zabývá změnami v kategorii slovesného vidu, k nimž dochází během odvozování sloves od sloves v češtině.
Po stručném shrnutí základních bodů aspektologických diskuzí nad videm českého slovesa je tvoření vidových protějšků prezentováno jako integrální součást derivace českých sloves.
Ve shodě s tímto pohledem je kategorie vidu využita jako důležitý rys při modelování slovesné derivace v databázi zachycující derivační morfologii češtiny.
V příspěvku představujeme sadu kritérií, na jejichž základě byla slovesa v databázi organizována.
Představujeme naši stále probíhající práci na mezijazyčném přenosu syntaktických parserů.
Prezentuji, co jsem se dozvěděl o PhD studiu na University of Genova, a navrhuji několik změn pro PhD studium na ÚFALu.
V této dizertaci se zaměřujeme na problém automatického syntaktického rozboru jazyků, pro něž nejsou k dispozici žádná syntakticky anotovaná trénovací data.
Zkoumáme několik metod mezijazyčného přenosu syntaktické i morfologické anotace, a nakonec docházíme k metodám založeným na využití dvojjazyčných či vícejazyčných korpů zarovnaných na úrovni vět, a strojového překladu.
Zvláštní pozornost věnujeme automatickému odhadování vhodnosti zdrojového jazyka pro analýzu daného cílového jazyka, a navrhujeme novou míru založenou na podobnostech častých sledů slovních druhů.
Účinnost představených postupů byla ověřena jak v našich pokusech, tak nezávisle v pracech uznávaných světových vědců.
Data v podobě prostého textu získaná z dumpů Wikipedie v únoru 2018.
Tento článek popisuje systém CUNI x-ling zaslaný do soutěže CoNLL 2018 UD Shared Task.
Zaměřili jsme se na syntaktickou analýzu jazyků s nedostatkem zdrojů, které mají k dipozici malá nebo žádná trénovací data.
Použili jsme široké spektrum přístupů, včetně jednoduchého překladu závislostních korpusů slovo po slově, kombinace delexikalizovaných parserů, a využití dostupných tvaroslovných slovníků.
Náš příspěvek byl v oficiálním vyhodnocení označen za jasného vítěze v kategorii analýzy jazyků s nedostatkem zdrojů.
Tématem této knihy je studium vlastností koreference s použitím mezijazykových přístupů.
Navrhujeme dvě mezijazykové metody: rozpoznávání koreference s informací z druhého jazyka a projekci koreference.
Výsledky našich experimentů s těmito metodami na česko-anglických datech naznačují, že s ohledem na koreferenci přináší angličtina více informací do češtiny než naopak.
Tématem této práce je studium vlastností koreference s použitím mezijazykových přístupů.
Motivací práce je výzkum lingvistické typologie založené na koreferenci.
Další motivací je prozkoumání, jestli rozdíly ve způsobech, jak jazyky vyjadřují koreferenci, mohou být využity k natrénování lepších modelů pro rozpoznávání koreference.
Navrhujeme dvě mezijazykové metody: rozpoznávání koreference s informací z druhého jazyka a projekci koreference.
Výsledky našich experimentů s těmito metodami na česko-anglických datech naznačují, že s ohledem na koreferenci přináší angličtina více informací do češtiny než naopak.
Rozpoznávání koreference s informací z druhého jazyka navíc dokázalo při aplikaci na paralelních datech překonat na obou jazycích výsledky jednojazykového systému na rozpoznávání.
Při experimentech používáme jednojazykový rozpoznávač koreference a vylepšenou metodu na zarovnání koreferenčních výrazů, které jsme rovněž navrhli v rámci této práce.
Představujeme systém pro automatické hodnocení textové koherence v českých esejích psaných nerodilými mluvčími.
Systém EVALD pracuje s množinou rysů z oblasti pravopisu, slovní zásoby, morfologie, syntaxe, diskurzních vzahů a koreference.
Nově nyní přidáváme rysy z oblasti informační struktury věty (aktuálního členění větného).
Evaluace rozpoznávání notopisu (Optical Music Recognition, OMR) je dlouholetým trnem v patě oboru.
Tento krátký position paper se pokouší vyjasnit, co přesně jsou překážky ve vyhodnocování OMR: detailnější pohled ukazuje, že hlavním problémem je nalézt způsob, jak vypočítat editační vzdálenost mezi prakticky použitelnými reprezentacemi notopisu.
Odhadovat tyto "ceny úprav" pro aplikaci OMR pro přímočarou digitalizaci not je obtížné, tvrdím však, že problémy s modelováním dalších faktorů ovlivňující náročnost lidského post-editování výstupu OMR je možné separovat od vyhodnocování sytémů OMR během jejich vývoje, pokud se použije intrinsní evaluace místo evaluace motivované aplikací, a načrtávám způsob, jak takovou evaluaci udělat.
Rozpoznávání notopisu (optical music recognition, OMR) slibuje, že díky němu půjde prohledávat hudební "full-text" v rozsáhlých notových archivech.
Otevřel by se tak nový způsob přístupu k obrovskému množství hudby, která byla napsána, avšak ne nahrána.
OMR však toto už slibuje dlouho a povětšinou bezvýsledně: jeho výsledky nejsou dostatečně dobré, především pro hudební rukopisy či pro nedokonalé scany.
V poslední době se však OMR zlepšilo, především díky pokrokům ve strojovém učení.
V tomto příspěvku vezmeme OMR systém založený na tradičním několikakrokovém postupu a druhý systém založený na učení end-to-end, a ilustrujeme jejich možnosti v jednoduchých, prototypických vyhledávacích aplikacích.
Na příkladu také ukazujeme, jak použití OMR může výrazně snížit náklady na studie kvantitativní muzikologie.
Dohromady tyto výsledky interpretujeme tak, že v určitých úlohách již lze současné technologie OMR nasadit jako obecný nástroj pro obohacování digitálních knihoven.
Detekce notačních symbolů je nejpalčivější otevřený podproblém v rozpoznávání notopisu (Optical Music Recognition, OMR).
Ukazujeme, že architektura U-Net pro sémantickou segmentaci spolu s triviálním detektorem představuje silnou baseline, a navrhujeme několik triků, které výsledky ještě zlepšují: trénování proti konvexním obalům notačních objektů, a vícekanálové výstupy které umožňují sdílet parametry sítě pro několik sémanticky příbuzných tříd objektů.
Oba triky přináší výrazné zlepšení v detekci klíčů, což má zásadní následky pro výsledky OMR.
Následně začleníme U-Nety do kompletního rozpoznávacího systému: přidáme model doplňující vztahy mezi rozpoznanými symboly, a dosáhneme tak výsledného f-score 0.81 pro extrakci výšek zapsaných tónů.
Nad takto automaticky extrahovanými tóny provedeme pokusy pro vyhledávání rukopisných kopií stejné hudby, které přináší první empirické indikace, že využívání mocných modelů hlubokého učení pro OMR skutečně dle očekávání přibližuje full-textové vyhledávání ve velkých sbírkách hudebních rukopisů na dosah.
Článek prezentuje aplikaci pro laické, netrénované uživatele, která slouži pro generování kvalitních zarovnaných fonetických přepisů mluveného slova.
Aplikace se již několik let používá a přepsalo se jí přes 600 tisíc slovních forem napříč dvěma verzemi webového rozhraní.
Představujeme opatření pro kompenzaci nedostatku odborného tréninku.
Článek prezentuje webovou aplikaci nové generace, která umožňuje uživatelům přispívat opravami automaticky získaného přepisu dlouhých záznamů mluveného slova.
Popisujeme rozdíly od podobných případů, porovnáváme svoje řešení s ostatními a pozastavujeme se nad vývojem oproti nyní 6 let staré aplikaci, z níž vycházíme, ve světle učiněného pokroku, získaného poučení a v prohlížeči nově dostupných technologií.
Představujeme pilotní verzi CzeDLexu, slovníku českých diskurzních konektorů.
Ve své aktuální verzi CzeDLex obsahuje 205 lemmat konektorů, získaných z anotací Pražského diskurzního korpusu 2.0 (PDiT).
19 lemmat bylo plně ručně zpracováno, což zahrnuje více než dvě třetiny všech diskurzních vztahů anotovaných v PDiT.
UDPipe je trénovatelný nástroj, který provádí segmentaci vět, tokenizaci, morfologické značkování, lemmatizaci a syntaktickou analýzu.
Představujeme prototyp UDPipe 2.0 a jeho vyhodnocení v Soutěži CoNLL 2018 UD: Multilingual Parsing from Raw Text to Universal Dependencies, která využívá tři míry pro hodnocení.
Z 26 účastníků obsadil prototyp první místo dle míry MLAS, třetí dle míry LAS a třetí dle míry BLEX.
V extrinsic hodnocení EPE 2018 se systém umístil na prvním místě v celkovém hodnocení.
Prototyp je založen na neuronovou síťi s jediným společným modelem pro současné morfologické značkování, lemmatizaci a syntaktickou analýzu a je trénován pouze pomocí trénovacích dat CoNLL-U a předtrénovaných slovních embeddingů, na rozdíl od obou systémů, které překonaly tento prototyp v LAS a BLEX mírách.
Open-source zdrojový kód prototypu je k dispozici na adrese http://github.com/CoNLL-UD-2018/UDPipe-Future.
Po soutěží CoNLL 2018 jsme mírně vylepšili modelovou architekturu, což vedlo k lepšímu výkonu jak v intrinsic hodnocení (odpovídající prvnímu, druhému a druhému místu dle metrik MLAS, LAS a BLEX), tak i v extrinsic hodnocení.
Vylepšené modely budou brzy k dispozici v UDPipe na adrese http://ufal.mff.cuni.cz/udpipe.
Shrnutí dokumentu je dobře studovaným NLP úkolem.
Se vznikem modelů umělé neuronové sítě se zvyšuje souhrnná výkonnost, stejně jako požadavky na výcvikové údaje.
Pro Čechy je však k dispozici pouze několik datových souborů, z nichž žádný není zvlášť velký.
Kromě toho bylo shrnutí vyhodnoceno převážně na angličtině, přičemž běžně používaná metrika ROUGE je specifická pro angličtinu.
V tomto příspěvku se snažíme řešit obě otázky.
Představujeme SumeCzech, český datový soubor pro sumarizaci zpráv.
Obsahuje více než milion dokumentů, z nichž každá obsahuje nadpis, několik věty dlouhý abstrakt a úplný text.
Sadu dat lze stáhnout pomocí dodaných skriptů, které jsou k dispozici na adrese http://hdl.handle.net/11234/1-2615.
Vyhodnocujeme několik souhrnných základních dat na množině dat, včetně silného abstrakčního přístupu založeného na architektuře neuronových sítí Transformeru.
Hodnocení se provádí jazykově-agnostickou variantou ROUGE.
Zpráva se zaměřuje na existující morfologické zdroje obsahující derivační slovotvorné vztahy.
Pro každý zdroj je ve zprávě popsána jeho historie, licence, formát, struktura dat a některé základní statistiky pro porovnání zdrojů.
Zpráva představuje první krok v přezkoumání a harmonizaci těchto zdrojů podobným způsobem, jako tomu bylo již učiněno se zdroji syntaktických stromů.
Představujeme morfologický analyzátor shipiba-koniba, domorodého jazyka z oblasti peruánské Amazonie.
Díky robustnosti konečněstavových systémů můžeme vytvořit model komplexní morfosyntaxe tohoto jazyka.
Vyhodnocení na textových korpusech ukazuje slibné pokrytí gramatických jevů, omezením je pouze zatím malý slovník.
Nástroj je volně k dispozici pro kohokoliv, čímž chceme podpořit další výzkum peruánských domorodých jazyků.
Tento nástroj je prvním morfologickým analyzátorem jazyka šipibo-konibo.
Je to
Paralelní dvojjazyčné korpusy v souladu s větou jsou hlavním a někdy jediným požadovaným zdrojem pro výuku systémů pro překlad statistických a neurálních strojů (SMT, NMT).
Navrhujeme koncovou hlubokou neuronovou architekturu pro jazykové nezávislé zarovnání vět.
Kromě zarovnání typu "one-to-one" může náš zarovnávač také provádět cross-a many-to-many alignment.
Předkládáme také případovou studii, která ukazuje, jak může výrazná jazyková analýza výrazně zlepšit výkon čisté neuronové sítě.
V souboru Europarl korpus (Koehn, 2005) a anglicko-perského korpusu (Pilevar et al., 2011) jsme použili tři páry jazyků pro vytvoření souhrnu dat.
Pomocí této datové sady jsme testovali náš systém jednotlivě a v systému SMT.
V obou nastaveních jsme dosáhli výrazně lepších výsledků ve srovnání s výchozími zdroji open source.
Wikipedia poskytuje neocenitelný zdroj paralelních vícejazyčných dat, které jsou ve vysoké poptávce pro různé druhy jazykových šetření, včetně teoretických i praktických studií.
Zavedeme vede nový end-to-end neuronový model pro rozsáhlé paralelní sběr dat z Wikipedie.
Náš model je nezávislý na jazyku, robustní a vysoce škálovatelný.
Používáme náš systém pro shromažďování, francouzsko-anglické a perzština-anglické věty.
Hodnocení člověka na konci ukazují silný výkon tohoto modelu při shromažďování vysoce kvalitních paralelních dat.
My navrhnout také statistický rámec, který rozšiřuje výsledky našeho lidského hodnocení na jiné jazykové páry.
Náš model také získal nejmodernější výsledek německo-anglické datové sady ze společného úkolu BUCC 2017 na paralelní extrakci vět z srovnatelných korpusů.
V tomto příspěvku navrhujeme nový jazykově založený přístup k odpovědi na otázky non-factoid otevřené domény z nestrukturovaných dat.
Nejprve vypracujeme architekturu pro textové kódování, na jejímž základě zavedeme hluboký neuronový model.
Tato architektura využívá mechanismus dvoustranné pozornosti, který pomáhá modelu soustředit se na otázku a větu odpovědi současně na extrakci frázové odpovědi.
Za druhé, do modelu předáváme výstup analyzátoru volebních obvodů a integrujeme do sítě síť jazykových složek, abychom se mohli soustředit na kusy odpovědi spíše než na jeho jednotlivé slova pro vytvoření přírodnějšího výstupu.
Díky optimalizaci této architektury se nám podařilo získat výsledky z hlediska výkonnosti, které jsou téměř shodné s lidskými parametry, a konkurenceschopné na nejmodernějších systémech datových souborů SQuAD a MS-MARCO.
Přednáška přináší přehled vývoje slovníků textově-spojovacích prostředků napříč jazyky, od prvních z 90. let až po ty nejnovější, včetně projektu CzeDLex, slovníku českých textových konektorů.
Neural Monkey je open-source toolkit pro sequence-to-sequence učení.
Článek je zaměřen na prezentaci současného stavu toolkitu cílovým skupinám, mezi které patří studenti a výzkumníci, ať už aktivní v komunitě hlubokého učení či nováčci.
Pro každou skupinu popisujeme nejvíce relevantní vlastnosti toolkitu spolu s jednoduchým schématem konfigurace, metodami analýzy modelů, které podporují užitečnou intuici, nebo modulární design umožňující snadné prototypování.
Shrnujeme relevantní příspěvky vědecké komunity, které vznikly s využitím tohoto toolkitu a rozebíráme charakteristiky našeho toolkitu s ohledem na ostatní existující systémy.
Článek uzavírá nástin budoucího vývoje toolkitu.
Toto je česká verze datasetu Multi30k, který se používá při soutěžích v Multimodálním strojovém překladu.
Dataset je založený ja datové sadě Flickr30k, která obsahuje přes 30 tisíc fotografií opatřených anglickými popisky.
Pro soutěž na WMT16 a WMT17 byly tyto věty přeloženy do Němčiny a Francozštiny.
Pro soutež v roce 2018 jsme obahatili tento dataset také o překlady do českého jazyka.
V článku představuje příspěvek do soutěže v multimodálním strjovém překladu na WMT18.
V našem systému požíváme self-attentive neuronové sítě místo rekurentních.
Evaluujeme dvě metody, jak lze zahrnout vizuální rysy do modelu: v prvním používáme vizuální informaci jako další vstup do dekodéruů v druhé metodě trénujeme enkodér tak, aby predikoval vizuální reprezentaci.
Pro náš příspěvek jsem vytěžili dodatečná data.
Obě navrhované metody přináší výrazné zlepšení oproti obdobným modelům využívajícím neuronové sítě.
V této práci se zaměřujeme na tři různé úlohy NLP: popis obrázků, strojový překlad, a rozbor sentimentu.
Reimplementujeme úspěšné postupy jiných autorů a přizpůsobujeme je českému jazyku.
Nabízíme end-to-end architektury, které dosahují nejlepších či téměř nejlepších výsledků známých pro tyto úlohy, přičemž všechny jsou implementovány ve stejném nástroji pro sekvenční učení.
Natrénované modely jsou k dispozici jak ke stažení, tak v podobě online dema.
Autoregresivní dekódování je jedinou součástí převádějících sekvence na sekvence, která bráňí masivní paralelizaci při inferenci.
Neautoregresivní modely umožňují dekodéru generovat všechny výstupní symboly nezávisle a tedy paralelně.
V článku představujeme novou neautoregresivní architekturu založenou na konekcionistické temporální klasifikaci (CTC).
Na rozdíl od jiných neautoregresivních metod, které je nutné trénovat v několika krocích, představovaný systém se trénuje monoliticky.
Experimentuje se strojovým překladem mezi angličinou a rumunštionou a angličtinou němčinou na standardních testovacích datech z WMT.
Naše modely dosahují výrazného zrychlení oproti autoregresivním modelům, přičemž kvalita překladu je srovnatelná s jinými neautoregresivními modely.
Při sekvenčním učením s více zrdoje informace, může být mechanismus pozornosti (attention) modelován různými způsoby.
Toto téma bylo důkladně studováno na rekurentních neurnovoých sítích.
V tomto článku se zabýváme tímto problém v architektuře Transormer.
Navrhujeme čtyři různé strategie kombinace vstupů: sériové, paralelní, ploché a hierarchické.
Navrhované metody vyhodnocujeme na úloze multimodálního překladu a překladu z více zdrojových jazyků současně.
Z  výsledků experimentů vyplývá, že modely jsou schopny využívat více zdrojů a fungovat lépe než modely s pouze jedním zdrojem informace.
Popisujeme náš neuronový překladač zaslaný do soutěže v překladu zpráv WMT2018.
Náš systém je založen na modelu Transformer (Vaswani et al., 2017).
Používáme vylepšenou techniku zpětného překladu, kdy opakujeme proces překládání jednojazyčných dat jedním směrem a trénujeme model pro opačný směr pomocí syntetických paralelních dat.
Aplikujeme jednoduché, ale účinné filtrování syntetických dat.
Na vstupní věty aplikujeme rozpoznávač koreference za účelem doplnění vypuštěných osobních zájmen.
Na přeložený výstup aplikujeme dvě jednoduché substituce.
Náš systém je výrazně (p < 0,05) lepší než všechny ostatní anglicko-české a česko-anglické systémy ve WMT2018.
V článku prezentujeme sadu vylepšení taggeru pro automatickou detekci slovesných víceslovných výrazů, MUMULS.
Náš tagger se zúčastnil PARSEME shared tasku a jako jediný byl založen na neuronových sítích.
Ukazujeme, že embeddingy slov na základě jejich znaků vedou k zlepšením, především díky redukci množství out-of-vocabulary slov.
Dále nahrazením softmaxové vrstvy v dekodéru klasifikátorem založeným na conditional random fields dosahujeme dalšího zlepšení.
Na závěr porovnáváme různé druhy reprezentací příznaků zohledňující okolní kontext slova za pomocí různých architektur enkodérů.
Experimenty s češtinou ukazují, že kombinace embeddingů založených na konvoluci jednotlivých znaků, self-attentive architektura enkodéru a conditional random filed klasifikátor dosahují nejlepších empirických výsledků.
Cílem příspěvku je výzkum provázanosti textové koreference a aktuálního členění větného a jejich podíl na koherenci textu.
V příspěvku představujeme dvě softwarové aplikace na automatické hodnocení koherence textu v češtině s názvem EVALD – Evaluátor diskurzu.
První aplikace "EVALD 1.0" hodnotí texty psané rodilými mluvčími češtiny (hodnotící škálou užívanou v českých školách: 1–5).
Druhá aplikace "EVALD 1.0 pro cizince" hodnotí texty nerodilých mluvčích češtiny (na škále A1–C2 podle "Společného evropského referenčního rámce").
Obě aplikace jsou dostupné online na https://lindat.mff.cuni.cz/services/evald-foreign/.
Tento balíček obsahuje datové sady pro vývoj a testování modelů strojového překladu pro krátké vyhledávací dotazy v oblasti medicíny, a to pro čestinu, angličtinu, francouzštinu, němčinu, španělštinu, maďarštinu, polištinu a švédštinu.
Dotazy obsažené v datech pochází jak od zdravotnických profesionálů, tak od laické veřejnosti.
Tento příspěvek shrnuje poznatky zjištěné při vytváření lexikografického modelu pro popis komplexních predikátů s kategoriálním slovesem v češtině.
Prozkoumali jsme vliv řazení vět pro online trénování neuronových sítí pro počítačová překlad.
Práce má dvě části: řazení stejných příkladů v rámci minibatche a postupné zvyšování složitosti trénovacích dat (tzv. Curriculum learning).
Výsledkem práce je, že homogenita minibatchí nemá na trénování velký vliv zato curriculum lepších větších výsledků.
V prednáške popisujem základy dolovania informácií z textu.
Najprv sa zameriavam na rôzne aplikácie dolovania informácií.
Následne popíšem základné a najčastejšie používané metódy dolovania informácií z textu.
Nakoniec použijeme niekoľko online nástrojov na spracovanie textu a vytvoríme reprezentáciu textu pomocou word cloudu.
Článok uvádza prehľad rozličných metód pre spracovanie obrazových dát a porovnáva efektívnosť ich využitia v úlohe vyhľadávania hyperlinkov v archíve videí.
Vizuálna informácia, ktorá sa získa pomocou metód Feature Signatures, SIMILE deskriptorov a konvolučných neurónových sietí sa využíva pri výpočte podobnosti snímkov vo videu a umožňuje tak vyhľadávanie podobných tvárí, objektov a pozadia.
Vizuálne deskriptory sa tiež používajú pri rozpoznávaní objektov v snímkoch a tento a textový popis je možné ďalej kombinovať s textovým vyhľadávaním na základe automatických prepisov a titulkov.
Prezentované experimenty boli robené vrámci benchmarkov MediaEval a TRECVid.
Cílem příspěvku je podat přehled anotace elipsy v korpusech Universal Dependencies (UD) 2.0.
Z dlouhodobého hlediska je znalost typů a četností eliptických konstrukcí užitečná pro experimenty se syntaktickou analýzou zaměřené na elipsu; to byla také naše původní motivace.
Nicméně se ukazuje, že současný stav anotace ještě zdaleka není dokonalý, a tudíž hlavním výstupem naší studie je přehled a popis anotačních chyb či nekonzistencí; doufáme, že tím přispějeme ke zlepšení budoucích verzí korpusů UD.
Zabýváme se využitím velkého korpusu (Pražského diskurzního korpusu 2.0) s ručně anotovanými diskurzními vztahy pro vytvoření slovníku českých diskurzních konektorů (CzeDLex).
Popisujeme teoretické aspekty projektu a technické řešení založené na Prague Markup Language, které umožňuje efektivní začlenění slovníku do rodiny pražských korpusů.
Článek popisuje dvě studie zaměřené na softwarové nástroje vyvinuté pro derivační sítě jako např. DeriNet; jde o nástroje určené pro vyhledávání a vizualizaci derivačních stromů.
Článek popisuje postup transformace latinského závislostního treebanku do dotazovatelné podoby, aby mohl být prohlížen online pomocí dotazovacího nástroje nad závislostními stromy.
Nejdříve jsou představeny anotační vrstvy, poté architektura dotazovacího nástroje a nakonec postup konverze do relační databáze.
Srovnavame koreferencni vyrazy v paralelnich textech.
Jde nam o vedlejsi vety vs.
neosobni klauzy, korelativni vyrazy a pro-drop kvality v cestine, polstine, rustine a anglictine.
Detekce jednotlivých symbolů na stránce hudební notace je jedním ze zbývajících nevyřešených podproblémů rozpoznávání not.
Navrhujeme použít plně konvoluční segmentační neuronovou síť, která produkuje vysoce kvalitní pravděpodobnostní masky přes pixely.
Pokusy na detekci notových hlaviček nad těmito maskami dosahují f-score 0.98 i při použití pouze elementárních detektorů.
V této práci prezentujeme nový, volně dostupný slovník parafrází českých komplexních predikátů s lehkými slovesy ParaDi.
Kandidáti na jednoslovné predikativní parafráze byli vybráni automaticky z velkých jednojazyčných dat pomocí word2vecu.
Dále byli manuálně ověřeni.
V experimentu s vylepšováním kvality strojového překladu ukazujeme jednu z mnoha praktických aplikací ParaDi.
Zpráva o účasti týmu Univerzity Karlovy v soutěži vyhledávání zdravotních informací CLEF eHealth Evaluation Lab 2017.
Příspěvek na interním workshopu DGT "Smart Select" o nástrojích pro neuronový strojový překlad i o potížích při trénování modelů.
Příspěvek představil některé aspekty překotného vývoje na poli neuronového strojového překladu a naznačil, jak v prudce se měnícím prostředí udržet stabilní směr výzkumu.
Příspěvek popisující neuronový přístup ke strojovému překladu obecně a první experimenty s neuronovým překladem pro IBM.
Shrnutí stavu vývoje neuronových překladačů na UK MFF v rámci projektu QT21.
Tento článek popisuje neuronové systémy a systémy založené na frázovém překladu, kterými UK přispělo do anglicko-českého News Translation Task v WMT17.
Experimentujeme se syntetickými daty pro trénování a zkoušíme několik technik na kombinaci systémů, jak neuronových, tak frázových.
Náš hlavní příspěvek CU-CHIMERA využívá frázových překlad s využitím neuronových a hluboce-syntaktických navrhovaných překladů
Článek shrnuje výsledky soutěžních úloh konference WMT17: tři překladové úlohy (novinové texty, biomedicínské texty a multimodální překlad), dvě úlohy v automatickém hodnocení (metriky a odhad kvality MT), automatickou korekturu, úlohu v trénování neuronových MT systémů a učení metodou jednorukého bandity.
Tento článek představuje výsledky úlohy WMT17 pro trénink neuronového strojového překladu.
Cílem této úlohy je prozkoumat metody výcviku předem zvolené neuronové architektury, zaměřené především na nejlepší kvalitu překladu a jako sekundární cíl kratší čas trénování.
Účastníci měli k dispozici kompletní systém pro neuronový strojový překlad, výchozí parametry trénování a konfiguraci sítě.
Překlad byl proveden v anglicko-českém směru a úkol byl rozdělen na dvě podskupiny s různými konfiguracemi - jedna byla upravena tak, aby se vešla na 4GB a druhá na 8GB GPU kartu.
Obdrželi jsme 3 řešení pro variantu 4 GB a 1 řešení pro variantu 8 GB; také jsme poskytli výsledky nášeho běh pro každou velikost jako baseline.
Přeložili jsme zkušební sadu netrénovanými modely a výsledky vyhodnotili pomocí několika automatických metrik.
Uvádíme také výsledky lidského hodnocení předložených systémů.
Příspěvek přestavil aktuální stav vývoje a experimentů s neuronovými překladači na UK MFF v rámci projektu QT21.
UFAL Medical Corpus je sbírka paralelních korpusů, které byly shromážděny pro účely EU projektů KConnect, Khresmoi a HimL s cílem dosáhnout spolehlivějšího strojového překladu medicínských textů.
MorphInd je robustní morfologický nástroj, který dané povrchové slovní formě přiřazuje její morfologickou značku a příslušné lemma, a umožňuje tak další automatické zpracování.
Pro dva valenční slovníky slovanckých jazyků, PDT-Vallex pro češtinu a Walenty pro polštinu článek porovnává jejich frazeologickou část.
Oba slovníky jsou založené na korpusu, i když se liší jak způsob propojení, tak technické řešení, ovšem oba jsou dostupné elektronicky ve standardnim formátu.
V článku se porovnávají frazeologická hesla, jejich formální popis a možnosti a omezení.
V závěru se doporučují rozšíření těchto komponent pro obecnější pokrytí i pro další jazyky.
Analýza aktuálního členění věty z hlediska její sémantické relevance a důležitosti pro strojový překlad.
Soubor vybraných statí rozdělený do pěti oddílů, a to 1.
Valence, 2.
Aktuální členění, negace a presupozice, 3.
Zachycení AČV v anotovaném  počítačovém korpusu češtiny, 4.
Struktura a analýza diskurzu, 5.
Rozbor některých zaharničních přístupů k uvedeným otázkám
Souhrn argumentů pro studium a odpovídající anotaci korpusu z hlediska hloubkové syntaktické struktury založené na závislostní gramatice
Kritický rozbor studií J.-M.Zemba o sémantice záporu a o informační struktuře věty z pohledu pražské školy.
Prezentace cílů, průběhu a výsledků projektu KConnect na Dnech H2020 na UK.
Úspěchy v oblasti medicínského strojového překladu v projektu KConnect
Shrnujeme zapojení našeho týmu CEMI do soutěže s úlohou rozpoznávání rodného jazyka autora, tzv. NLI Shared Task~2017, pro kterou byla k dispozici textová a mluvená data.
Představujeme výsledky, kterých jsme dosáhli použitím tří různých architektur, kde každá z nich kombinuje modely natrénované nad různými příznaky.
Jak jsme očekávali, lepších výsledků dosáhly systémy, které kombinují textové a mluvené příznaky.
Dokonce bylo dosaženo dramatického zlepšení.
Naš nejlepší systém je založen na feed-forward neural networks, jejichž výstupy skryté vrstvy jsou kombinovány pomocí softmax.
Dosáhli jsme úspěšnosti 0.9257 macro-averaged F1 na evaluační testovací sadě a náš tým spolu s dalšími třemi obsadil první místo v hlavní soutěži.
Na příkladu nově vznikajícího slovníku českých diskurzních konektorů CzeDLex představujeme obecné a efektivní technické řešení tvorby takového slovníku, založené na datovém a aplikačním balíku Prague Markup Language a na extrakci základního hrubého obsahu slovníku z velkého anotovaného korpusu.
CzeDLex je nový elektronický slovník českých diskurzních konektorů.
Jeho formát a struktura jsou založeny na studiu obdobných existujících zdrojů a upraveny podle české syntaktické tradice a specifik pražského přístupu k anotaci diskurzních vztahů v textu.
Nejprve uvádíme slovník do kontextu podobných zdrojů a probíráme teoretické otázky vytváření slovníku.
Poté představujeme technické řešení založené na Prague Markup Language.
Následně popisujeme proces získání dat pro slovník z velkého korpusu s ručně anotovanými diskurzními vztahy.
Zkoumáme, jakými strategiemi jsou označeny základní aktanty (core arguments) v indoevropských jazycích s pádovou morfologií.
Koncept základních aktantů je v Universal Dependencies stěžejní, někdy je však obtížné ho namapovat na terminologie tradičně používané v jednotlivých jazycích.
Přezkoumáváme metodologii popsanou Andrewsem (2007) a přidáváme stručné definice některých základních pojmů.
Statistiky z 26 treebanků UD ukazují, že ne všichni poskytovatelé dat definují hranici mezi základními (core) a nepřímými (oblique) argumenty stejně.
Proto navrhujeme úpravu a upřesnění anotačních pravidel, které zlepší konzistenci napříč treebanky na jedné straně a bude více slučitelné s tradiční gramatikou na straně druhé.
Shrnu soutěž v parsingu, kterou jsme organizovali toto jaro.
11 let po první soutěžní úloze CoNLL v závislostním parsingu byla ta současná jednou z největších soutěží v historii CoNLL, a to jak co do velikosti a rozmanitosti testovacích dat (81 treebanků, 49 jazyků), tak co do počtu účastníků (přes 50 týmů, 32 odevzdaných systémů).
Soutěž se vyznačovala několika novinkami: kompletní analýza od prostého textu až po závislostní stromy, jazyky s nedostatkem dat a předem neznámé jazyky, jednotné anotační schéma pro všechny jazyky, evaluace naslepo na vzdáleném serveru.
Výsledky představují kvalitativně novou úroveň stavu poznání pro automatickou závislostní analýzu většiny jazyků včetně češtiny.
Shrnu soutěž v parsingu, kterou jsme organizovali toto jaro.
11 let po první soutěžní úloze CoNLL v závislostním parsingu byla ta současná jednou z největších soutěží v historii CoNLL, a to jak co do velikosti a rozmanitosti testovacích dat (81 treebanků, 49 jazyků), tak co do počtu účastníků (přes 50 týmů, 32 odevzdaných systémů).
Soutěž se vyznačovala několika novinkami: kompletní analýza od prostého textu až po závislostní stromy, jazyky s nedostatkem dat a předem neznámé jazyky, jednotné anotační schéma pro všechny jazyky, evaluace naslepo na vzdáleném serveru.
Výsledky představují kvalitativně novou úroveň stavu poznání pro automatickou závislostní analýzu většiny jazyků včetně češtiny.
Popisujeme převod syntakticky anotované části Slovenského národního korpusu do anotačního schématu známého jako Universal Dependencies.
Zatím byla převedena pouze malá část dat, nicméně jde o první slovenský treebank, který je volně přístupný pro výzkumné účely.
Uvádíme řadu výzkumných projektů, ve kterých už tato data byla využita, včetně prvních výsledků automatické syntaktické analýzy (parsingu).
Popisujeme rodinu formátů korpusových formátů zvanou CoNLL, se zvláštním zřetelem na jejího nejnovějšího člena, formát CoNLL-U.
Představujeme Universal Dependencies (UD), komunitní projekt zaměřený na mezijazykově použitelné anotační schéma pro morfologii a syntaxi přirozených jazyků.
Klíčovou myšlenkou UD je, že podobné gramatické konstrukce mají být analyzovány a anotovány podobně; strukturní reprezentace paralelních vět ve dvou jazycích mají být maximálně paralelní.
Komunita UD je velmi rozmanitá, stejně jako předpokládané možnosti využití, které se UD snaží podporovat: modely pro počítačové zpracování přirozeného jazyka (zvláště morfologické značkování a syntaktická analýza); jazykovědné bádání a dotazy na korpus; studie z jazykové typologie.
Kromě návrhu anotačních pravidel se projekt UD zabývá také sběrem samotných korpusů, jejich převodem do jednotné anotace a jejich zpřístupněním pro výzkum.
Vzhledem k tomu, že UD je omezeno dostupností dat, má pochopitelně výrazně větší zastoupení velkých eurasijských jazyků bohatých na digitální zdroje; nicméně, přibývají i vzorky z menšinových jazyků a několika klasických jazyků.
První část přednášky představí obecné principy UD.
Ve druhé části se podíváme zblízka na treebanky klasických jazyků a probereme obtíže s harmonizací tradiční terminologie ze synchronního i diachronního hlediska.
Předvedeme také nástroje, které lze využít k databázovým dotazům nad korpusy.
Tento balíček obsahuje výstupy 33 automatických syntaktických analyzátorů, které se účastnily společné úlohy (shared task) ve vícejazyčném parsingu z prostého textu do Universal Dependencies, v rámci konference CoNLL 2017.
Konference o počítačovém učení přirozeného jazyka (CoNLL) zahrnuje soutěž (společnou úlohu, shared task), ve které účastníci trénují a testují své učící systémy na stejných sadách dat.
V roce 2017 byla jedna ze dvou soutěží věnována učení závislostních parserů (syntaktických analyzátorů) pro velké množství jazyků, v realistických podmínkách bez jakékoli ruční anotace na vstupu.
Všechny testovací sady byly anotovány podle jednotného schématu zvaného Universal Dependencies.
V tomto článku definujeme úlohu a vyhodnocovací metodiku, popisujeme přípravu dat, shrnujeme a rozebíráme hlavní výsledky a podáváme stručný přehled jednotlivých přístupů v účastnických systémech.
Přednáška se zaměřila na vybrané vlastnosti českých příklonek: především na omezení na jejich umístění ve větě a haplologii reflexivních příklonek.
Prezentujeme pilotní studii věnovanou automatické syntaktické analýze žakovského korpusu CzeSL.
Provedli jsme experimenty, které naznačily, že základní větné členy subjekt, predikát, objekt, mohou být určeny pomocí parseru natrénovaného na textech od rodilých mluvčích.
ForFun je nástroj pro rozmanitý lingvistický výzkum, zejména v oblasti syntaxe pro popis syntaktických funkcí a jejich formálních realizací v českcýh větách.
ForFun je založen na datech Pražských závislostních korpusů (PDTs), uspořádává jejich morfologickou a syntaktickou anotaci do nové databáze, ve které je možné rychle a snadno prohledávat autentické příklady užité v PDTs pro jednotlivé funkce (66 položek) a  též opačně lze zkoumat funkce vyjádřené zvolenou formou (téměř 1500 položek).
V mnoha jazycích lze některé slova psát více způsoby.
Říkáme jim varianty.
Hodnoty všech jejich morfologických kategorií jsou totožné, což vede k identické morfologické značce.
Spolu s totožným lematem máme dva nebo více slovních tvarů se stejným morfologickým popisem.
Tato nejednoznačnost může působit problémy v různých aplikacích automatického zpracování jazyka.
Existují dva typy variant - ty, které ovlivňují celé paradigma (globální varianty), a ty, které mají vliv pouze na slovní tvary používající některé kombinace morfologických hodnot (inflexní varianty).
V příspěvku navrhujeme prostředky, jak označit všechny slovní tvary, včetně jejich variant, jednoznačně.
Tento požadavek nazýváme "Zlaté pravidlo morfologie".
Práce se zabývá především češtinou, ale hlavní myšlenky lze uplatnit i v jiných jazycích.
Zkoumáme lidské úsudky o tom, jak dobře popisují jednotlivé vzory užívání (usage patterns) 29 cílových sloves z modelového slovníku anglických sloves jejich náhodné KWIC.
Zaměřujeme se na případy, kdy je pro daný KWIC hodnoceno více než jeden model a snažme se odhadnout vliv účastníků události (argumenty), které jsou denotativně podobné ve dvou vzorcích, s ohledem na všechny kombinace párů v daném lemmatu.
Tento efekt porovnáváme s účinkem několika kontextových rysů KWIC, účinkem spárovaných implicit PDEV, které se navzájem implikují, a účinkem příslušnosti k danému lemu.
Ukazujeme, že lemmatický efekt je stále silnější než jakákoli vlastnost, která prochází napříč lemma, kterou jsme zatím prozkoumali, takže každé sloveso se zdá být malým vesmírem samo o sobě.
Velmi rychla implementace banky filtru pro rozdeleni vstupniho komplexniho signalu do N frekvencne ekvidistantnich kanalu.
Příspěvek představuje databázi lingvistických forem a funkcí postavenou nad Pražským závislostním korpusem.
Účelem databáze ForFun je usnadnit lingivstům studium vztahu formy a funkce.
Ukážeme možnosti využití databáze.
V příspěvku se zabýváme hranicí mezi přejímáním slov a slovotvorbou (zvláště derivací) na příkladu substantiv s příponou -ismus a -ita.
Z hlediska české slovní zásoby jsou zkoumány formální (flektivní i derivační) vlastnosti a význam těchto slov.
Příspěvek se věnuje paradigmatu českého slovesa z hlediska flektivní a derivační morfologie, poukazuje na vzájemnou propojenost obou oblastí.
Kategorie vidu je popisována jako flektivní kategorie slovesa, která je formálně vyjadřována derivačními prostředky.
Příspěvek představuje poloautomatickou proceduru, jejímž cílem bylo v derivační databázi DeriNet identifikovat vidové dvojice sloves lišící se příponami.
Na základě dat z valenčního slovníku Vallex jsme sestavili seznam párů sufixů, kterými se vidové protějšky liší, a tento seznam využili k vyhledání dalších dvojic v rozsáhlých datech sítě DeriNet.
Nalezené dvojice byly potvrzeny ruční anotací.
Snadný způsob prohlížení souborů ve formátu CoNLL a CoNLLU ve vašem terminálu.
Rychlý a textový.
V několika rozměrech rozebíráme chyby v kroslingválním přenosu taggeru a parseru z angličtiny do 32 jazyků.
Identifikujeme a vysvětlujeme silné a slabé stránky a nepravidelnosti a navrhujeme možná řešení.
Natrénované modely pro UDPipe, použité k vytvoření našeho příspěvku zaslaného na sdílenou úlohu VarDial 2017 (https://bitbucket.org/hy-crossNLP/vardial2017) a popsaných v článku stejných autorů s názvem Slavic Forest, Norwegian Wood.
Nástroje a skripty užité k vytvoření modelů mezijazyčných parserů, zaslaných na sdílenou úlohu VarDial 2017 (https://bitbucket.org/hy-crossNLP/vardial2017) a popsaných v článku stejných autorů s názvem Slavic Forest, Norwegian Wood.
Představení Treex CR - systému na rozpoznávání koreference pro angličtinu a češtinu.
Článek popisuje systém pro rozpoznávání koreference  v němčině a ruštině, trénovaný výlučně na koreferenčních vztazích projektovaných skrz paralelní korpus.
Rozpoznávač operuje na tektogramatické vrstvě a používá vícero specializovných modelů.
Měřeno metrikou CoNLL systém dosahuje 32 bodů pro Ruštinu a 22 bodov pro němčinu.
Analýza výsledků ukazuje, že rozpoznávač pro ruštinu je schopen při projekci z angličtiny dosáhnout 66% kvality dosažené na angličtině.
Systém byl poslán na CORBON 2017 Shared task.
Automatická segmentace, tokenizace a morfologická a syntaktická anotace textů ve 45 jazycích, vygenerovaná pomocí UDPipe (http://ufal.mff.cuni.cz/udpipe), spolu se 100rozměrnými slovními embeddingy vypočítanými nad textem převedeným na malá písmena nástrojem word2vec (https://code.google.com/archive/p/word2vec/).
Strojový překlad do tvaroslovně bohatých jazyků představuje složitý problém.
Prestože pokrytí na úrovni lemmat může být dostatečné, řada jejich tvaroslovných variant se z trénovacích dat nedá získat.
Představujeme statistický překladový systém, který tyto tvaroslovné varinaty dokáže generovat.
Na rozdíl od dřívějších prací nerozdělujeme modelování tvarosloví a lexikální volbu na dva navazující kroky.
Náš postup je integrován přímo v dekódování a využívá informace z konextu jak na zdrojové, tak na cílové straně.
Bylo prokázáno, že zvyšující se hloubka modelu zlepšuje kvalitu neuronového strojového překladu.
Přes mnoho návrhů různých variant arhitektur pro zvýšení hloubky modelu doposud nebyla provedena žádná důkladná srovnávací studie.
V této práci popisujeme a vyhodnocujeme několik stávajících přístupů k zavedení hloubky v neuronovém strojovém překladu.
Navíc prozkoumáváme nové varianty architektur včetně hlubokých přechodových RNN a měníme, jak je hlubokém dekodéru použit mechanismus pozornosti ("attention").
Představujeme novou architekturu "BiDeep" RNN, která kombinuje hluboké přechodové RNN a skládané RNN.
Hodnocení provádíme na anglicko-německém datovém souboru WMT pro překlady novinových článků s využitím stroje s jednou GPU pro trénování i inferenci.
Zjistili jsme, že několik našich navrhovaných architektur zlepšuje stávající přístupy z hlediska rychlosti a kvality překladu.
Nejlepších výsledků jsme získali s BiDeep RNN kombinované hloubky 8, získáním průměrného zlepšení 1,5 BLEU nad silnou baseline.
Náš kód je pro snadný přístup zveřejněn.
Většina hudebních skladeb, které byly kdy vytvořeny, dnes existuje pouze v psané podobě, většinou v rámci archivů; konkrétně v ČR je více než 10 000 takových rukopisů.
Pro zachování a šíření této části kulturního dědictví je vhodné jej digitalizovat, a další výhody přináší digitalizace hudebního obsahu těchto dokumentů.
Ruční přepisování not v editorech jako Sibelius či MuseScore je však v tomto rozsahu příliš pomalé.
Rozpoznávání notopisu (Optical Music Recognition, OMR), ekvivalent OCR pro hudební notaci, může být klíčovým nástrojem pro zpřístupnění obsahu hudebních archivů - pro široký muzikologický výzkum, pro lepší správu (např. detekce opisů), a pro zkrácení cesty, kterou skladby musí ujít od archiválie k živému provedení.
Představujeme MUSCIMarker, open-source nástroj pro vývoj systémů rozpoznávání notopisu (Optical Music Recognition, OMR).
Nástroj je postavený okolo reprezentace notopisu jakožto grafu, definovaného v datasetu MUSCIMA++.
Nástroj je transparentní a interaktivní, umožňuje uživateli vizualizovat, ověřit a upravovat výsledky jednotlivých kroků OMR.
Navíc je díky čistě Pythonové implementaci přenosný mezi operačními systémy, a umožňuje pracovat offline.
Dokládáme hodnotu MUSCIMarkeru skrze prototyp systému na plnohodnotné rozpoznávání notopisu, od předzpracování obrazu po přehrání výstupu a export do formátu MIDI.
Publikum prezentace bude mít příležitost MUSCIMarker i rozpoznávací prototyp vyzkoušet.
Notové hlavičky představují rozhraní mezi zápisem hudby a hudbou samotnou.
Každá hraná nota je kódována pomocí notové hlavičky, a detekovat hlavičky je tím pádem pro rozpoznávání not nevyhnutelné.
V tištěné notaci jsou hlavičky jasně rozlišitelné, avšak různorodost rukopisů činí jejich identifikaci obtížnější.
Představujeme jednoduchý detektor notových hlaviček používající konvoluční neuronové sítě pro klasifikaci pixelů a regresi na ohraničení, který dosahuje na detekci f-score 0.97 nad datasetem MUSCIMA++, nepotřebuje odstraňování osnov, a lze jej použít na různorodé rukopisné styly a úrovně složitosti zapsané hudby.
V tomto článku popisujeme vylepšení úlohy pro řízení robota neomezeným přirozeným jazykem.
MorphoRuEval-2017 je hodnotící kampaň určená k povzbuzení rozvoje technologií automatického morfologického zpracování pro ruštinu, a to jak pro normativní texty (novinky, beletrie, fakta), tak pro méně formální povahu (blogy a další sociální média).
Tento článek porovnává metody, které účastníci použili při řešení úlohy morfologické analýzy.
Rovněž se zabývá problémem sjednocení různých stávajících výcvikových sbírek ruského jazyka.
Co dál je možné dělat s handlem, kromě "základního" oddělení id od lokace.
Metadata handlu.
Handle a content negotiation.
Template handle.
Historie vzniku, vývoj a úvod do používání repozitáře clarin-dspace.
V příspěvku představujeme projekt anotace evaluativního významu v Pražském závislostním korpusu 2.0.
Projekt navazuje na sérii anotací malých korpusů prostého textu.
V projektu byla použita automatická identifikace potenciálně evaluativních uzlů prostřednictvím českého slovníku hodnotících výrazů Czech SubLex 1.0.
V rámci anotačních prací byly odhaleny výhody i nevýhody zvoleného anotačního schématu.
Popisujeme proces vzniku NUDAR, arabského treebanku ve stylu Universal Dependencies.
Představujeme převod z Penn Arabic Treebanku do syntaktické reprezentace Universal Dependencies přes mezilehlou závislostní reprezentaci.
Probíráme obtíže, se kterými je převod závislostních stromů spojen, řešení, která jsme použili, a hodnocení námi převedených dat.
Dále představujeme prvotní výsledky parsingu na NUDARu.
Příspěvek se zabývá vedlejšími jazykovými signály, které mohou vyjadřovat sémantiku implicitních vztahů.
K nim patří např. hodnotící výrazy ve fokusu, za nimiž následuje obvykle argument s významem explikace či specifikace.
Kapitola se zaměřuje na popis a delimitaci diskurzních konektorů, tj.
výrazů přispívajících ke kohereci textu a pomáhajících čtenáři lépe porozumět sémantickým vztahům v textu.
V příspěvku je představen etymologický původ diskurzních konektorů z hlediska současné lingvistiky.
Cílem je podat definici diskurzních konektorů s ohledem na jejich historický vývoj, díky němuž můžeme lépe nahlížet na  diskurzní vztahy v současném jazyce.
V kapitole analyzujeme etymologický původ a vývoj deseti nejfrekventovanějších konektorů v češtině, angličtině a němčině (mezijazykový pohled může napomoci také přesnějšímu překladu konektorů) a poukazujeme na fakt, že tyto konektory prošly ve všech sledovaných jazycích velmi podobným vývojem, než se ustálily v roli současných diskurzních konektorů.
Domníváme se proto, že způsob vzniku diskurzních konektorů může být jazykovou univerzálií.
V závěru kapitoly ukazujeme, jak naše zjištění mohou pomoci při anotacích diskurzu ve velkých korpusech.
Představujeme novou verzi UDPipe 1.0, což je trénovatelný nástroj provádějící větnou segmentaci, tokenizaci, morfologické značkování, lemmatizaci a syntaktickou analýzu.
Poskytujeme modely pro všech 50 jazyků UD 2.0, a navíc lze jednoduše UDPipe natrénovat pomocí vlastních dat v CoNLL-U formátu.
Pro potřeby CoNLL 2017 Shared Task: Multilingual Parsing from Raw Text to Universal Dependencies, upravená verze UDPipe 1.1 byla použita jako základový systém a umístila se na 13. místě z 33 účastníků.
Nejnovější verze UDPipe 1.2, která se také účastnila, dosáhla na 8. místo, přičemž potřebuje jen malý čas na běh a středné velké modely.
Nástroj je k dispozici pod open-source licencí MPL a poskytuje rozhraní pro C++, Python (pomocí ufal.udpipe balíčku PyPI), Perl (pomocí UFAL::UDPipe balíčku CPAN), Javu a C#.
Představujeme náš příspěvek do First Shared Task on Extrinsic Parser Evaluation (EPE 2017).
Náš systém, UDPipe, je trénovatelný nástroj provádějící tokenizaci, morfologickou analýzu, morfologické značkování, lemmatizaci a syntaktickou analýzu.
Je nezávislý na jazyku a k dispozici jsou modely pro všech 50 jazyků UD 2.0.
Použitím relativně omezeného množství trénovacích dat (200 tisíc tokenů z anglického korpusu UD) a bez nastavení specifického pro angličtinu získal systém celkové hodnocení 56.05 a umístil se mezi soutěžícími systémy jako 7.
Popis architektury projektu clarin-dspace a dodrziavanie standardov a doporuceni RDA-DFT/FAIR/OAIS.
Navrhujeme propuštěnou hlubokou neuronovou síť (CDNN) hluboký neuronový model pro výběr věty odpovědi v kontextu systémů QA (Question Answering).
Pro vytvoření nejlepších předpovědí kombinuje CDNN neurální uvažování s určitým symbolickým omezením.
Integruje techniku přizpůsobení vzoru do vektoru vět učení se.
Při výcviku za použití dostatečných vzorků převyšuje CDNN ostatní nejlepší modely pro výběr vět.
Ukazujeme, jak se využívají další zdroje Školení může zvýšit výkon CDNN.
V dobře studovaném datovém souboru pro výběr věty odpovědi náš model výrazně zlepšuje nejmodernější technologii.
V tomto krátkém časopise oznamujeme postupnou práci na hybridním hlubokém nervovém systému, který odpovídá na faktoidní a nepravotní otázky otevřené oblasti.
Tento systém doplňuje znalostní graf založený na zodpovězení dotazu s vyhledávacími technikami pro volné texty, které řeší problematiku sparsity ve znalostních grafech.
Ospravedlňujeme účinnost navrhovaného systému na základě výsledků pilotního experimentu.
Rovněž popisujeme nastavení probíhajícího projektu v kontextu tohoto systému.
Uvádíme zprávu o pokročilejších úkolech při sestavování datových sad otázka odpovědět Quora.
Datová sada Quora se skládá z otázek, které jsou položeny na stránkách Quora answering site.
Je to jediná datová sada, která poskytuje odpovědi současně na úrovni vět a slov.
Otázky v datové sadě jsou navíc autentické, což je mnohem realističtější pro systémy odpovědí na otázky.
Testujeme výkonnost nejmodernějšího záznamníku otázek na datové množině a porovnáváme ji s lidskou výkonností, abychom vytvořili horní hranici datové sady.
Prezentace nabízí přehled a srovnání současných elektronických lexikonů textových konektorů v různých jazycích se zvláštním zřetelem na nový lexikon českých konektorů - CzeDLex.
Neuronový strojový překlad (NMT) se stal v posledních letech široce využívaným přístupem ke strojovému překladu.
V našem tutoriálu začneme úvodem do základů metod hloubkového učení používaných v NMT jako jsou rekurentní neuronové sítě a jejich pokročilé varianty (GRU nebo LSTM sítě) nebo algoritmy pro jejich optimalizaci.
Představujeme modely specifické pro NMT, jako je mechanizmus pozornosti, a popisujeme metody použité pro dekódování cílových vět, včetně ensemblování modelů a paprskového prohledávání.
Projdeme nedávné pokroky v této oblasti a budeme diskutovat o jejich dopadu na nejmodernější metody používané na letošní soutěži WMT (http://www.statmt.org/wmt17/).
V tomto článku popisujeme naše příspěvky do multimodální překladové úlohy na WMT17.
Pro úlohu 1 (multimodální překlad) byl nejlepším systémem čistě textový neuronový překlad titulku zdrojového obrázku do cílového jazyka.
Hlavním rysem našeho systému je využití dalších dat získaných výběrem podobných vět z paralelních korpusů a syntézou dat zpětným překladem.
Pro úlohu 2 (vícejazyčné generování popisu obrázků) náš nejlepší systém generuje anglický popis obrázku, který je poté přeložen podle nejlepšího systému používaného v úloze č. 1.
Také předkládáme negativní výsledky, které jsou založeny na myšlenkách, o kterých se domníváme, že mají potenciál překlad zlepšit, ale v našem konkrétním uspořádání   neprokázaly býti prospěšnými.
Účel tohoto labu je seznámit uživatele s toolkitem Neural Monkey, využívaným pro experimenty se sekvenčním učením.
Attention modely ve vícezdrojovém neuronovém  sekvenčním učení zůstávají poměrně neprobádanou oblastí, a to navzdory jeho užitečnosti v úkolech, které které využívají více zdrojových jazyků či modalit.
Navrhujeme dvě nové strategie jak kombinovat výstupy attentiion modelu z různých vstupů, plochou a hierarchickou.
Navrhované metody porovnáváme se stávajícími a výsledky vyhodnocujeme na datech pro multimodální překlad a automatické post-editování překladu z WMT16.
Navrhované metody dosažení konkurenceschopných výsledků na obou úlohách.
Článek popisuje jeden z možných způsobů, jak zobrazit a prohledávat data s anotací víceslovných jednotek.
Využíváme mnohojazyčný korpus PARSEME s anotací verbálních víceslovných jednotek v 18 jazycích.
Anotované jednotky zahrnují různé typy, jako např. idiomy, konstrukce s lehkými slovesy, inherentně reflexivní slovesa nebo konstrukce se slovesem a částicí.
Korpus byl dosud využíván zejména pro trénování prediktivních modelů, ale nikoli k lingvistickému výzkumu per se.
Článek nabízí způsob, jak data zpřístupnit lingvistům skrze jednoduché vyhledávací prostředí a jazyk Corpus Query Language (CQL) známy například z často užívané platformy NoSke.
I přes omezené možnosti k zachycení komplexních jevů jakými jsou nespojité, koordinované nebo vnořené víceslovné predikáty, CQL může postačovat k základním vyhledávkám víceslovných jednotek pro korpusově založený výzkum.
Tento článek popisuje systém MUMULS, který se účastnil 2017 Shared Task on Automatic Identification of Verbal Multiword expressions (VMWEs).
Systém MUMULS byl implementován přístupem učení s učitelem pomocí rekurentních neuronových sítí v open-source knihovně TensorFlow.
Model byl trénován na poskytnutých datech s VMWEs a také na morfologických a syntaktických anotacích.
MUMULS provádí identifikaci VMWEs v patnácti jazycích, byl to jeden z mála systémů který dokázal kategorizovat VMWEs ve skoro všech jazycích.
Tento článek představuje novou úlohu na využití dat od uživatelů dialogových systémů v konverzacích člověk-stroj.
Tato úloha se zaměřuje na sběr denotací extrahováním z přirozených vět získaných v průběhu dialogu.
Motivace spočívá v potřebě velkého monžství trénovacích dat pro vývoj Q&A dialogových systémů, přičemž získání těchto dat je obvykle těžké a nákladné.
Získávání denotací při interakcích s uživateli například umožňuje online vylepšování komponent pro porozumění přirozenému jazyku a zjednodušit sběr trénovacích dat.
Tento článek také prezentuje výsledky evaluace několika přístupů k extrakci denotací zahrnující modely založené na neuronových sítích s attention architekturou.
Tento článek představuje hybridní dialog state tracker, rozšířený o trénovatelnou jednotku zpracování přirozeného jazyka (SLU).
Naše architektura je inspirována belief trackery založenými na neuronových sítích.
Tento přístup navíc rozšiřujeme o derivovatelná prvidla, která umožní end-to-end trénink.
Tato pravidla umožní našemu trackeru lépe generalizovat v porovnání s trackery založenými pouze na strojovém učení.
Pro evaluaci používáme Dialog State Tracking Challenge (DSTC) 2 - populární dataset využívaný pro srovnání výkonnosti belief trackerů.
Podle informací, které máme, náš tracker dosahuje state-of-the-art výsledků ve třech ze čtyř kategorií datasetu DSTC2.
Udapi je open-source framework poskytující APO pro zpracovávání dat z projektu Universal Dependencies.
Implementace Udapi je dostupné pro programovací jazyky: Python, Perl a Java.
Udapi je vhodné jak pro plnohodnotné aplikace, tak pro rychlé vyváření prototypů: vizualizace stromů, konverze formátu, dotazování, editace, transformace, testy validity, závislostní parsing, vyhodnocování, atd.
V návaznosti na loňský systém pro automatickou post-editaci strojového překladu Karlovy Univerzity se soustředíme na využití potenciálu sequence-to-sequence neuronových modelů pro danou úlohu.
V článku nejprve porovnáváme několik architektur typu enkodér-dekodér na modelech menšího měřítka a představujeme systém, který byl vybrán na základě těchto předběžných výsledků a odeslán na WMT 2017 Automatic Post-Editing shared task.
V článku také ukazujeme jak jednoduchá inkluze umělých dat dokáže vylepšit úspěšnost modelu na základě automatických evaluačních metrik.
V závěru uvádíme několik příkladů výstupů vygenerových našim post-editačním systémem.
V článku jsou představeny možnosti automatické evaluace povrchové koherence (koheze) textů psaných nerodilými mluvčími češtiny během certifikovaných zkoušek.
Na základě korpusové analýzy jsou vyhledávány a popisovány relevantní rozlišovací rysy (týkající se povrchové koherence textu) pro automatickou detekci úrovní textů nerodilých mluvčích A1–C1 (úrovně jsou ustanoveny Společným evropským referenčním rámcem pro jazyky).
Úrovně A1–C1 byly hodnoceny nejprve lidmi (anotátory) – poté byly dělány strojové experimenty s cílem přiblížit se lidskému hodnocení automaticky, a to sledováním vybraných textových rysů, např. frekvence a různorodosti diskurzních konektorů nebo hustoty diskurzních vztahů v daném textu ap.
V článku jsou představeny experimenty sledující vždy různé textové rysy při použití dvou algoritmů strojového učení.
Úspěšnost automatického měření povrchové koherence (koheze) textu podle Společného evropského referenčního rámce pro jazyky je 73,2 % pro rozpoznávání úrovní A1–C1 a 74,9 % pro rozpoznávání úrovní A2–B2.
Značkování slovními druhy (POS tagging) se v počítačovém zpracování přirozeného jazyka někdy považuje za téměř vyřešený problém.
Standardní řízené přístupy často dosahují úspěšnosti přes 95 %, pokud je k dispozici dostatek ručně anotovaných trénovacích dat (typicky několik set tisíc tokenů nebo více).
My si nicméně myslíme, že je stále užitečné studovat polořízené a neřízené přístupy.
Tento článek popisuje systém hybridního strojového překladu (MT), který byl vytvořen pro překlad z angličtiny do němčiny v oblasti technické dokumentace.
Systém je založen na třech různých systémech MT (frázový, pravidlový a neuronový), které jsou spojeny výběrovým mechanismem, který používá hluboké jazykové rysy v procesu strojového učení.
Součástí je také podrobná manuální analýza chyb, kterou jsme provedli pomocí specializované "zkušební sady", která obsahuje vybrané příklady relevantních jevů.
Zatímco automatické výsledky ukazují obrovské rozdíly mezi systémy, celkový průměrný počet chyb, které (ne) dělají, je pro všechny systémy velmi podobný.
Podrobné rozdělení chyb však ukazuje, že systémy se chovají velmi odlišně, pokud jde o různé jevy.
Recognizing textual entailment is typically considered as a binary decision task – whether a text T entails a hypothesis H. Thus, in case of a negative answer, it is not possible to express that H is almost entailed by T. Partial textual entailment provides one possible approach to this issue.
This paper presents an attempt to use word2vec model for recognizing partial (faceted) textual entailment.
The proposed approach does not rely on language dependent NLP tools and other linguistic resources, therefore it can be easily implemented in different language environments where word2vec models are available.
Současná počítačová lingvistika zažívá masový zájem o postojovou analýzu jakožto nástroj zjišťování veřejného mínění.
Je ale možné rozlišit dobro a zlo pomocí statistických metod?
Jak zacházet s ironií, idiomy či vulgarismy?
Jsou emoce jazykově nezávislé?
V příspěvku zodpovím tyto otázky a popíšu současné přístupy k postojové analýze.
Česko-anglické ruční zarovnání slov.
Česko-anglické ruční zarovnání slov.
V tomto článku budeme porovnávat delexicalized přenos a minimálně pod dohledem rozebrat techniky na 32 různých jazyků od Universal závislostí korpusu sbírky.
Minimální dohled při přidávání pouštět univerzální gramatická pravidla pro POS tagy.
Pravidla jsou začleněny do nekontrolované závislost parseru ve formách externích dřívějších pravděpodobnostech.
Také jsme experimentovat s učit se toto pravděpodobností z jiných stromových korpusů.
Průměrná připevnění skóre našeho parseru je o něco nižší než v delexicalized přenosu analyzátor, nicméně, to funguje lépe pro jazyky z méně zdroji jazykových rodin (non-Indo-Evropan), a proto je vhodný pro ty, pro které stromových korpusů často neexistují.
V tomto příspěvku představujeme náš nový experimentální systém sloučení závislost reprezentace dvou rovnoběžných vět do jednoho strom závislostí.
Všechny vnitřní uzly v závislosti stromu představují zdroj-cílové páry slovy, další slova jsou ve formě koncové uzly.
Používáme Univerzální Závislosti anotace styl, ve kterém funkční slova, jejichž použití se často liší mezi jazyky, jsou zaznamenány jako listy.
Paralelní korpus je analyzován v minimálně dohlíží způsobem.
Nezarovnaný slova jsou zde automaticky tlačil na povrch listů.
Představujeme jednoduchý systém překladu vyškoleného na takových sloučených stromech a vyhodnocovat jej WMT 2016 anglicko-to-český a česko-to-anglický překlad úloh.
I přesto, že model je doposud velmi jednoduché a byl používán žádný jazykový model a model word-li řazení varianta Český k angličtině dosáhl podobného Bleu skóre jako další zavedeného systému stromu bázi.
V posledních 12 letech došlo k velkým pokroku v oblasti bez dozoru závislostní parsování.
Různé přístupy však někdy liší v motivaci a ve vymezení problému.
Některé z nich umožňují využití zdrojů, které jsou zakázány jinými, neboť se s nimi zachází jako druh dohledu.
Cílem tohoto příspěvku je definovat všechny varianty bez dozoru závislost rozebrat problém a ukázat jejich motivace, pokrok, a nejlepší výsledky.
Také jsme diskutovali o užitečnosti látky jako součásti bez dozoru analýze obecně, a to jak pro formální lingvistiky a pro aplikace.
Představujeme nedokončené zaměřená na těžbu překladové páry zdrojové a cílové závislost treelets které mají být použity v systému strojového překládání závislostí na bázi.
Představíme nový voze metodu pro paralelní segmentaci stromu na základě vzorků Gibbs.
S použitím dat z české, anglické paralelním korpusu, ukážeme, že postup konverguje ke slovníku, který obsahuje poměrně velké treelets; V některých případech se zdá, že segmentace mít zajímavé lingvistické výklady.
Představujeme novou datovou sadu pro generování jazyka v hlasových dialogových systémech, která spolu s každou odpovědí systému k vygenerování (pár zdrojová sémantická reprezentace – cílová věta v přirozeném jazyce) uvádí i předcházející kontext (uživatelský dotaz).
Očekáváme, že tento kontext dovolí generátorům jazyka adaptovat se na způsob vyjadřování uživatele a tím docílit přirozenějších a potenciálně úspěšnějších odpovědí.
Datová sada byla vytvořena za pomoci crowdsourcingu v několika fázích, aby bylo možno získat přirozené uživatelské dotazy a odpovídající přirozené, relevantní a kontextově zapojené odpovědi systému.
Datová sada je dostupná online pod otevřenou licencí Creative Commons 4.0 BY-SA.
Představujeme nový generátor přirozeného jazyka pro hlasové dialogové systémy, který je schopný přizpůsobit se způsobu, jakým mluví uživatel, a poskytovat odpovědi přiměřené kontextu dialogu.
Generátor je založen na neuronových sítích a přístupu sequence-to-sequence.
Je plně trénovatelný z dat, která spolu s trénovacími výstupy generátoru obsahují také předchozí kontext.
Ukazujeme, že kontextový generátor přináší signifikantní zlepšení oproti základnímu generátoru, a to jak z pohledu automatických metrik, tak v preferenčním testu lidského hodnocení.
Diateze představují vztahy mezi různými povrchověsyntaktickými strukturami sloves.
Jsou podmíněny změnou morfologické charakteristiky slovesného rodu a jsou spojeny se změnami v povrchověsyntaktickém vyjádření valenčních doplnění sloves.
V příspěvku jsme se zaměřili na specifické změny, kterým podléhají valenční doplnění českých funkčních sloves.
Příspěvek se zabývá distribucí Konatele v konstrukcích komplexních predikátů s kategoriálními slovesy.
V příspěvku navrhujeme lexikografickou reprezentaci komplexivních predikátů v češtině.
Zvláštní oddíl je věnován výběru kolokací funkčních sloves a predikativních jmen a anotaci jejich syntaktické struktury.
V tomto článku se zaměřujeme na české složené predikáty, které jsou tvořené lehkým slovesem a predikativním jménem vyjádřeným jako přímý objekt.
Ačkoli čeština -- jakožto inflekční jazyk -- poskytuje výbornou příležitost pro studium distribuce valenčních doplnění složených predikátů, tato distribuce dosud nebyla poplsána.
Na základě manuální analýzy bohatě anotovaných dat PDT formulujeme poučky řídicí tuto distribuci.
V automatickém experimentu tyto poučky ověřujeme na korektních syntaktických strukturách PDT a PCEDT s velmi uspokojivými výsledky: distribuce 97% valenčních doplnění se řídí navrženými poučkami.
Tyto výsledky dokládají, že vytváření povrchové struktury složených predikátů je pravidelný proces.
Zvýšený zájem o ‚porozumění‘ přirozeným jazykům způsobil, že do centra pozornosti současného výzkumu se dostávají různé postupy, často popisované jako ‚sémantická analýza‘.
Předkládáme systém pro rozpoznávání pojmenovaných entit, který je jazykově nezávislý a nepotřebuje klasifikační rysy pro strojové učení.
Systém využívá současných výsledků v oblasti umělých neuronových sítí, jako jsou parametric rectified linear units (PReLU), embeddingy slov a embeddingy charakterů ve slovech založené na gated linear units (GRU).
Systém nepotřebuje vyhledávání vhodné sady klasifikačních rysů (feature engineering) a pouze s využitích povrchových forem, lemmat a slovních druhů na vstupu dosahuje vynikajících výsledků v rozpoznávání pojmenovaných entit v češtině a překonává stávající výsledky dříve publikovaných prací, které využívají ručně vytvořené klasifikační rysy založené na ortografické podobnosti slov.
Navíc tato síť podává robustní výkon i v případě, kdy jsou na vstupu pouze povrchové formy.
Síť dovede využít navíc i kombinaci ručně vytvořených klasifikačních rysů a v tom případě překonává stávající výsledky s markantním rozdílem.
Článok popisuje systém SHAMUS určený na jednoduché vyhľadávanie a navigáciu v multimediálnych archívoch.
Systém pozostáva z troch komponentov.
Search poskytuje textové vyhľadávanie v mutlimediálnej kolekcii, Anchoring automaticky detekuje najvýznamnejšie segmenty videa a sémanticky súvisiace segmenty sú vyhľadané v komponente Hyperlinking.
V článku popisujeme jednotlivé komponenty systému, ako aj online demo rozhranie, ktoré pracuje s kolekciou videí z konferencie TED.
Článek popisuje práci na strojovém překladu provedenou v rámci projektu KConnect, financovaném v rámci programu H2020 a zaměřeném na vývoj a komercializaci cloudových služeb pro vícejazyčnou sémantickou anotaci, sémantické vyhledávání a strojový překlad elektronických zdravotních záznamů a medicínských publikací.
Nejprve prezentujeme hlavní cíl a úlohu strojového překladu v projektu, následně stručně popisujeme hlavní metody a komponenty vyvinuté v rámci projektu, mj. získání dat, metody doménové adaptace, nasazení MT jako cloudové webové služby a nástroj pro trénování překladových systémů, který umožňuje snadnou adaptaci překladové služby na nové jazyky.
The aim of our talk is to present results of quantitative analysis of dependency characteristics of particular analytical functions.
For each word in a syntactically annotated corpus (Bejček et al. 2013), a dependency frame is derived first.
The dependency frame consists of all analytical functions assigned to its directly dependent words.
Cílem je podat snadno použitelné webové aplikace speciálně vyvinuté pro anotaci ruských textů s morfologickou a syntaktickou informaci.
Tato zpráva představuje ruský korpus anotovaný podle standardu Universal Dependencies a popisuje postup, kterým byl existující ruský závislostní korpus SynTagRus transformován do stylu UD.
Článek zkoumá podobnost aplikace atributových gramatik ve dvou zdánlivě odlišných vědeckých oblastech, jmenovitě ve formálním popisu pracovních postupů a v kontrole syntaktické správnosti přirozených jazyků.
Jsou použity existující modely a formalismy a hledá se společný jmenovatel, který by umožnil využít zkušenosti nabyté v obou oblastech.
Zároveň také ukazuje nutnost mírné adaptace formalismu pro kontrolu gramatiky pro jazyky s vysokým stupněm volnosti slovosledu, která by mohla vést k vytvoření nástroje použitelného pro kontrolu pracovních postupů.
ConFarm je webová služba, věnovaná extrakci povrchových reprezentaci slovesnych a jmennych tvaru ze závislostních anotovaných korpusů ruských textů.
V současné době je  k dispozici extrakce konstrukci s konkrétním lemmatem z korpusu SynTagRus a ruského národního korpusu.
Nas systém poskytuje flexibilní rozhraní, které umožňuje uživatelům vyladit výstup.
Extrahované konstrukce jsou seskupeny podle jejich obsahu, aby byla možna kompaktní reprezentace, a skupiny jsou zobrazeny ve formě grafu.
ConFarm se liší od podobných existujících nástrojů pro rustinu v tom, že nabízí kompletní konstrukce, v protikladu k samostatni extrakci zavislostnich clenu nebo práci s slovních spojení, a umožňuje uživatelům objevit nečekané konstrukce, na rozdíl od vyhledavani příkladu podle formy zadane uživatelem.
Tato práce se zabývá otázkou budování svobodného NLP potrubí pro zpracování ruské texty z prostého textu na morfologicky a syntakticky anotovaný struktury ve formátu CONLL.
Potrubí je napsán v python3.
Segmentace je zajišťována vlastní modul.
Mystem s četnými postprocesních oprav se používá pro lemmatizace a morfologie značkování.
A konečně, syntaktická anotace se získá MaltParser využitím naší vlastní model vyškolený na SynTagRus, který byl převeden do formátu CONLL pro tento účel, s jeho morfologické tagset převádí do Mystem / ruského národního korpusu tagset
Příspěvek se zabývá klasifikací českých sloves s genitivním doplněním z hlediska tvoření pasivní a deagentní diateze.
Slovesa jsou klasifikována na ta, která se chovají podobně jako slovesa s akuzativním doplněním,, slovesa, u nichž je genitivní vazba v příznakových členech diateze zachována, a slovesa, jejichž genitivní doplnění může být v diatezi vyjádřeno nominativem i genitivem.
Shrnutí čeho jsme dosáhli v rozborech, anotacích a analýze češtiny (PDT) a němčiny v rámci korpusu GECCo.
Tento článek se zabývá modely pro sledování stavu dialogu pomocí rekurentních neuronových sítí (RNN).
Představujeme pokusy na datové sadě, DSTC2.
Na jedné straně, RNN modely dosahují vynikajících výsledků.
Na druhou stranu většina state-of-the-art modelů jsou "turn-based" a vyžadují specifické předzpracování (např pro data z DSTC2) k dosažení vynikajících výsledků.
Představili jsme dvě architektury, které mohou být použity v inkrementálních nastavení a nevyžadují téměř žádnou předzpracování.
V članku porovnáváme jejich výkonnost na referenčních hodnotách pro DSTC2 a diskutujeme jejich vlastnosti.
S pouze triviální předzpracováním se výkon našich modelů blíží k výsledkům state-of-the-art.
Tento článek prezentuje novou datovou sadu pro výcvik end-to-end úkol orientovaně konverzační agentů.
Obsahuje rozhovory mezi operátorem - odborníkem na danou doménu, a klientem, který hledá informace o úloze.
Spolu s konverzační přepisy zaznamenáme databázová volání prováděné operátorem, které zachycují význam dotazu uživatele.
Očekáváme, že se snadno získatelné databázová volání nám umožní trénovat end-to-end dialog agenty se s výrazně méně tréninkových dat.
Datová sada je sbírána pomocí crowdsourcing a rozhovory pokrývají dobře známé restaurace doménu.
Kvalita dat je vynucováno vzájemné kontroly mezi přispěvateli.
Datový soubor je k dispozici ke stažení pod licencí Creative Commons 4.0 BY-SA licencí.
Navrhujeme dva příspěvky k diskriminativnímu výběru pravidel v hierarchickém strojovém překladu.
Ověřujeme předchozí přístupy na dvou úlohách francouzsko-anglického překladu na doménách s omezenými zdroji a ukazujeme, že nedokážou zlepšit překladovou kvalitu.
Navrhujeme model pro výběr pravidel, který je (i) globální a využívá bohatou sadu rysů a (ii) je trénován s využitím všech dostupných negativních příkladů.
Náš globální model přináší významné zlepšení až 1 bod BLEU oproti předchozím modelům pro výběr pravidel.
Příspěvek shrnul deset let konání soutěže v automatickém hodnocení kvality překladu: představil úspěšné minulé metriky, současné experimenty a poukázal na potřebné další směry vývoje.
Pro dva valenční slovníky slovanckých jazyků, PDT-Vallex pro češtinu a Walenty pro polštinu článek porovnává jejich frazeologickou část.
Oba slovníky jsou založené na korpusu, i když se liší jak způsob propojení, tak technické řešení, ovšem oba jsou dostupné elektronicky ve standardnim formátu.
V článku se porovnávají frazeologická hesla, jejich formální popis a možnosti a omezení.
V závěru se doporučují rozšíření těchto komponent pro obecnější pokrytí i pro další jazyky.
V článku jsou analyzovány výhrady vůči dichotomii arguemtu (valenčního členu) a volného doplnění, které jsou předloženy ve stati A. Przepiórkovského ve stejné publikaci.
Obhajují se kritéria opakovatelnosti, specifičnosti a podmínky užití dialogového testu.
V přednášce se budeme zabývat stromovými strukturami, které jsou využívány v počítačovém zpracování přirozeného jazyka.
Vedle diskurzních vztahů vyjádřených primárně tzv. diskurzními konektory (nebo jsou případně dány implicitně) je třeba při analýze diskurzu brát v úvahu též další vztahy.
To se týká především aktuálního členění větného a vztahů koreference.
Všechny tři tyto aspekty jsou začleněny do anotačního scénáře Pražského závislostního korpusu.
Článek představuje nový dvojjazyčný česko-anglický valenční slovník nazvaný CzEng-Vallex.
Elektronická podoba slovníku je  umístěna v repozitáři Centra jazykové výzkumné infrastruktury LINDAT/CLARIN v XML formátu a je zde k dispozici také v prohledávatelné podobě.
Slovník je propojen s českým valenčním slovníkem PDT-Vallex, s anglickýmm valenčním slovníkem EngVallex a rovněž je propojen s příklady z PCEDT korpusu (PCEDT 2.0).
CzEngVallex  obsahuje 20835 propojených párů valenčních rámců (slovesných významů) překladových ekvivalentů a obsahuje i propojení jejich argumentů.
Představujeme návrh nového slovníku českých diskurzních konektorů.
Formát dat i anotační schéma vycházejí z podobných existujících elektronických zdrojů; zabýváme se důvody pro volbu struktury dat a pro výběr vlasností jednotlivých záznamů ve slovníku.
Pozornost věnujeme obzvláště konzistentnímu zachycení primárních i sekundárních konektorů.
Samotná data pocházejí z Pražského závislostního korpusu, rozsáhlého korpusu s manuálně anotovanými diskurzními vztahy.
PML-Tree Query je mocný a uživatelsky přítulný vyhledávací nástroj pro vyhledávání v bohatě lingvisticky anotovaných datech.
Článek ukazuje, jak může být PML-TQ využito k vyhledávání diskurzních vztahů Penn Discourse Treebanku 2.0 namapovaných na syntaktické stromy Penn Treebanku.
Universal Dependencies (UD) je projekt, který hledá morfologické a syntaktické anotační schéma aplikovatelné na mnoho jazyků, a vydává data anotovaná podle tohoto schématu.
Stručně motivujeme a uvedeme tento projekt, jeho historii a principy, na kterých stojí.
Poté popíšeme návrh nové (druhé) verze anotačních pravidel UD.
Nakonec, pokud zbude čas, popíšeme několik zajímavých problémů, které se týkají aplikace UD na slovanské jazyky.
Tento článek je pokusem navrhnout aplikaci podmnožiny standardu Universal Dependencies (UD) na skupinu slovanských jazyků.
Dotyčnou podmnožinou jsou morfosyntaktické rysy jednotlivých slovesných tvarů.
Systematicky dokumentujeme kategorie, které lze pozorovat u slovanských sloves, a přinášíme množství příkladů z 10 jazyků.
Ukazujeme, že terminologie známá z literatury se často liší, i když podstata zkoumaných jevů je stejná.
Náš cíl je praktický.
Rozhodně nemáme v úmyslu přehodnocovat výsledky mnohaletého bádání slovanské srovnávací jazykovědy.
Spíše chceme zasadit vlastnosti slovanských sloves do kontextu UD a navrhnout jednotný (všeslovanský) způsob, jak mají být prostředky UD aplikovány na tyto jazyky.
Věříme, že náš návrh je kompromisem, který bude přijatelný pro korpusové lingvisty pracující se všemi slovanskými jazyky.
Pro morfologické značkování a syntaktickou analýzu neznámých jazyků byla navržena řada metod.
My zkoumáme delexikalizovaný parsing, navržený Zemanem a Resnikem (2008), a delexikalizované značkování, navržené Yu et al. (2016).
V obou případech předkládáme podrobné vyhodnocení na datech z Universal Dependencies (Nivre et al., 2016), de-facto standardu pro vícejazyčné morfosyntaktické zpracování (předchozí práce pracovaly s jinými daty).
Naše výsledky potvrzují, že každá z uvedených delexikalizovaných metod samostatně má určitý omezený potenciál v případech, kdy není k dispozici žádná ruční anotace cílového jazyka.
Nicméně, pokud obě metody zkombinujeme, jejich chyby se vzájemně zmnožují nad přijatelnou mez.
Ukazujeme, že i sebemenší střípek expertní anotace cílového jazyka může významně zvýšit úspěšnost a měl by být použit, jestliže ho lze získat.
Příspěvek představil rodinu elektronických valenčních slovníků, které jsou rozvíjeny v Ústavu formální a aplikované lingvistiky, VALLEX, PDT-Vallex, EngVallex a CzEngVallex, jejichž teoretické zázemí tvoří funkční generativní popis.
Na příkladu českého morfologického slovníku MorfFlex CZ upozorňujeme na problém homonymie a polysémie.
V morfologickém slovníku není nutné rozlišovat význam slov, pokud takové rozlišení nemá důsledky ve slovotvorbě nebo v syntaxi.
Příspěvek navrhuje několik důležitých pravidel a principů pro dosažení konzistence.
Poster představuje přehled výsledků automatické analýzy slovosledu ve 23 treebancích.
Tyto treebanky byly vytvořeny v rámci projektu HamleDT, jehož cílem je poskytnout univerzální anotaci závislostních korpusů.
Představení mých projektů týkajících se víceslovných výrazů na PARSEME Training school v La Rochelle.
Analyzujeme vnitřní strukturu komplexních adresních datových údajů v textu, kategorizujeme je, anotujeme a vyhodnocujeme výsledky.
Ukážeme, že slovesné víceslovné výrazy (VV) specifikované v Shared Tasku PARSEME jsou anotovány v PDT a jednotlivé kategorie VV je možné z něj extrahovat a v Shared Tasku použít.
Příspěvek prezentuje dva problémy, při jejichž řešení bylo využíváno vztahů mezi derivačními a flektivními paradigmaty.
Za prvé, tyto vztahy byly využity při identifikaci nových vztahů mezi odvozenými slovy a slovy základovými, a to především v případech, kdy během odovzení dochází k hláskové alternaci.
Za druhé, flektivní rysy je možné využívat rovněž jako důležitou vstupní informaci při poloautomatickém značkování významových vztahů mezi deriváty a slovy základovými.
Tento článek představuje zdroje dosud vytvořené v projektu Universal Dependencies (UD), který se snaží vypořádat s chybějící závislostní reprezentací pro zpracování přirozených jazyků aplikovatelnou na více jazyků.
Toto je dokument-alignovaný paralelní korpus anglických a českých abstraktů vědeckých článků, které publikovali autoři z Institutu formální a aplikované lingvistiky Univerzity Karlovy v Praze, jak byly reportovány v systému institutu Biblio.
Autoři každé publikace jsou povinni poskytnout jak originální abstrakt v češtině nebo angličtině, tak jeho překlad do angličtiny  respektive češtiny.
Žádné filterování nebylo provedeno, kromě odstranění záznamů, kterým chybí český nebo anglický abstrakt a nahrazení nových řádků a tabulátorů mezerami.
Představujeme naši práci v oblasti částečně řízené syntaktické analýzy vět přirozeného jazyka, se zaměřením na mezijazyčný přenos delexikalizovaných závislostních parserů s více zdroji.
Představujeme KLcpos3, empirickou míru podobnosti jazyků, navrženou a vyladěnou pro vážení zdrojových parserů při přenosu delexicalizovaných parserů s více zdroji.
Nakonec představíme novou metodu kombinace zdrojů, založenou na interpolaci natrénovaných modelů parserů.
Popisuje náš příspěvek do úlohy překladu v doméně IT na WMT16.
Provádíme doménovou adaptaci již natrénovaných překladových systémů pomocí slovníkových dat bez dalšího trénování.
Náš postup aplikujeme na dva konceptuálně odlišné překladače, vyvíjené v rámci projektu QTLeap -- TectoMT a Moses -- a na jejich kombinaci -- Chiméru.
Všechny naše metody zlepšují ve všech experimentech kvalitu překladu.
Základní varianta naší metody je navíc použitelná na libovolný překladový systém, včetně takového, který je pro uživatele černou skříňkou.
Moses je dobře známý reprezentant rodiny frázových systémů statistického strojového překladu, který je známý tím, že je extrémně chudý na explicitní lingvistické znalosti, a operuje na plochých reprezentacích jazyka, složených jen z tokenů a frází.
Na druhé straně, Treex NLP toolkit, který je vysoce lingvisticky motivovaný, operuje na několika vrstvách reprezentace jazyka, bohatých na lingvistické anotace.
Jeho hlavní aplikace je TectoMT, hybridní systém strojového překladu s hloubkovým transfrem syntaxe.
Nabízíme přehled velkého počtu systémů strojového překladu, sestavených v minulých letech, které různými způsoby kombinují Mosese a Treex/TectoMT.
Článek popisuje pokus o automatizaci všech procesů vytváření dat u systému strojového překladu založeného na pravidlovém přístupu s mělkým transferem.
Uváděné metody byly vyzkoušeny na čtyřech plně funkčních překladových systémech pokrývajících tyto jazykové páry: slovinštinu do srbštiny, češtiny, angličtiny a estonštiny.
Aplikovatelnost použitých metod byla testována rozsáhlou řadou evalučních testů.
Medical and healthcare study programmes are quite complicated in terms of branched structure and heterogeneous content.
In logical sequence a lot of requirements and demands placed on students appear there.
This paper focuses on an innovative way how to discover and understand complex curricula using modern information and communication technologies.
We introduce an algorithm for curriculum metadata automatic processing - automatic keyword extraction based on unsupervised approaches, and we demonstrate a real application during a process of innovation and optimization of medical education.
The outputs of our pilot analysis represent systematic description of medical curriculum by three different approaches (centrality measures) used for relevant keywords extraction.
Further evaluation by senior curriculum designers and guarantors is required to obtain an objective benchmark.
nástroj, který pomůže uživateli vybrat vhodnou veřejnou licenci jeo jeho data nebo software
PDiT 2.0 je novou verzí Pražského diskurzního korpusu.
Přináší komplexní anotaci diskurzních jevů, obohacenou o anotaci sekundárních konektorů.
Popisujeme experimenty s použitím rozlišení významu slov (WSD) ve strojovém překladu.
Zaměřujeme se na WSD u sloves a používáme dva různé přístupy -- slovesné vzorce založené na metodě corpus pattern analysis a významy sloves z valenčního slovníku.
Vyhodnocujeme několik způsobů, jak použít významy sloves jako dodatečný faktor ve strojovém překladači Moses.
Výsledky ukazují statisticky signifikantní zlepšení kvality překladu z pohledu metriky BLEU pro přístup s valenčním slovníkem, ale v ruční evaluaci vycházejí obě metody WSD jako přínos.
Tento představuje nástroj MT-ComparEval pro kvalitativní vyhodnocení strojového překladu.
MT-ComparEval je opensourcový nástroj, který byl navržen tak, aby pomáhal vývojářům strojových překladačů díky grafickému rozhraní, které umožňuje porovnávat a vyhodnocovat různé překladače či experimenty a nastavení.
Tento článek reaguje na potřebu podpory strojového překladu pomocí vývojových cyklů s integrovanými evaluačními metodami.
Naším cílem je zhodnotit, porovnat a vylepšit různé varianty strojových překladačů.
Článek pojednává o nových nástrojích a praktikách, které podporují informovaný přístup k vývoji strojových překladačů.
Článek popisuje náš systém pro aspektovou analýzu postojů (ABSA).
Účastníme se podúkolu 1 (ABSA na úrovni vět), v jeho rámci se pak zaměřujeme na detekci kategorií aspektů.
Trénujeme binární klasifikátory pro každou kategorii.
Letošní rozšíření o další jazyky motivuje jazykově nezávislé přístupy.
Navrhujeme využít neuronové sítě, které by měly automaticky detekovat v datech jazykové konstrukce, a tak omezit nutnost využívat jazykově závislé nástroje a ruční návrh rysů.
Diskriminativní překladové modely, které využívají zdrojový kontext, zlepšují kvalitu statistického strojového překladu.
V tomto článku navrhujeme nové rozšíření, které navíc využívá i informace z cílového kontextu.
Ukazujeme, že i takový model lze efektivně integrovat přímo do procesu dekódování.
Náš přístup lze uplatnit i na velká trénovací data a jeho využití konzistentně zlepšuje kvalitu překladu u čtyř jazykových párů.
Analyzujeme také zvlášť přínos zdrojového a cílového kontextu a ukazujeme, že toto rozšíření lépe zachycuje morfologickou shodu.
Model je volně dostupný v rámci softwaru Moses.
Již v minulosti se ukázalo, že parafrázování referenčních překladů zlepšuje korelaci s lidským hodnocením při automatickém vyhodnocování strojového překladu.
V této práci představujeme novou sadu dat k vyhodnocování anglicko-českého překladu založenou na automatických parafrázích.
Tuto sadu porovnáváme s existující sadou ručně tvořených parafrází a zjišťujeme, že i automatické parafráze mohou hodnocení překladu zlepšit.
Navrhujeme a vyhodnocujeme také několik kritérií pro výběr vhodných referenčních překladů z větší sady.
Tento článek popisuje společnou praci UK a LMU nad anglické-českého a anglický-rumunského systémy frázových překladu pro WMT16.
V porovnání s minulými pokusy, jsme přísně omezili trénovací daty na constrained, aby bylo možné spolehlivé porovnat naší systémy s jiné výzkumné systémy.
My jsme zkoušeli využiti několika dalších modelů v naších systémech, včetně diskriminačního modelu frázových překladu.
UDPipe je trénovatelný nástroj pro tokenizaci, tagging, lemmatizaci a závislostní parsing CoNLL-U souborů.
UDPipe je jazykově nezávislý a pro natrénování jazykového modelu stačí označkovaná data v CoNLL-U formátu.
Předtrénované jazykové modely jsou k dispozici pro téměř všechny UD korpusy.
UDPipe je k dispozici jako spustitelný soubor, jako knihovna pro C++, Python, Perl, Java, C#, a také jako webová služba.
UDPipe je svobodný software licencovaný pod Mozilla Public License 2.0 a jazykové modely jsou k dispozici pro nekomerční použití pod licencí CC BY-NC-SA, nicméně původní data použitá k vytvoření modelů mohou v některých případech ukládat další licenční omezení.
Představujeme naše softwarové nástroje pro NLP: UDPipe, open-source nástroj pro zpracování CoNLL-U souborů, který provádí tokenizaci, morfologickou analýzu, určování slovních druhů a závislostní parsing pro 32 jazyků; a NameTag, rozpoznávač pojmenovaých entit pro češtinu a angličtinu.
Oba nástroje dosahují vynikajících výsledků, jsou dostupné s předtrénovanými modely a mají minimální nároky na čas a paměť počítače.
UDPipe a NameTag lze také trénovat s použitím vlastních dat.
Oba nástroje jsou open-source a jsou dostupné v licenci Mozilla Public License 2.0 (software) a CC BY-NC-SA (data).
Program, C++ knihovna s vazbami na Python, Perl, Java a C# a také online web service a demo jsou dostupné na odkazech http://ufal.mff.cuni.cz/udpipe a http://ufal.mff.cuni.cz/nametag.
Jedním z cílů infrastruktury LINDAT/CLARIN je poskytovat technické prostředky pro sdílení nástrojů a dat pro výzkumné účely a v souladu s technickými požadavky CLARIN ERIC.
Proto byl vybudován a je rozvíjen tento silně adaptovaný repozitářový systém založený na platformě DSpace.
CLARIN SPF není jediná inter-federace, ale je první, která se systematicky zabývá problémy, které působí neuvolnění povinných atributů poskytovateli identit.
Například, jsou-li data zveřejněná pod restriktivní licencí, musí být uživatel jednoznačně identifikovatelný v průběhu času.
Pokud poskytovatel identity nezpřístupní potřebnou informaci, služba nemůže uživateli dovolit, aby data získal.
Představujeme vysoce škálovatelný přístup k otevřenému question answeringu, který nezávisí na datasetu mapujícím z logické formy na povrchovou, ani na jakýchkoliv lingvistických nástrojích pro analýzu jako např. POS tagger nebo rozpoznavání pojmenovaných entit.
Popisovaný přístup je definován v rámci frameworku Constrained Conditional Models, který umožnuje škálovat znalostní grafy bez jakéhokoliv omezení velikosti.
Ve standardním benchmarku jsme dosáhli výsledky srovnatelné se state-of-the-art v otevřeném question answeringu.
Představujeme vysoce škálovatelný přístup k otevřenému question answeringu, který nezávisí na datasetu mapujícím z logické formy na povrchovou, ani na jakýchkoliv lingvistických nástrojích pro analýzu, jako např. POS tagger nebo rozpoznavání pojmenovaných entit.
Popisovaný přístup je definován v rámci frameworku Constrained Conditional Models, který umožnuje škálovat znalostní grafy bez omezení velikosti.
Ve standardním benchmarku jsme dosáhli 4% zlepšení výsledků oproti state-of-the-art v otevřeném question answeringu.
Příspěvek popisuje náš systém UFAL_MULTIVEC v soutěži WMT16 Quality Estimation.
Systém odhaduje kvalitu strojového překladu z angličtiny do němčiny.
Náš přínos spočívá v rozšíření zavedené metody o dvojjazyčné vektorové reprezentace slov a o slovní zarovnání.
Prezentace software, který pomáhá autorovi vybrat pro jeho dílo nejvhodnější (nejsvobodnější) veřejnou licenci.
V tomto článku se zabýváme získáváním textových informací z fotografií.
Dosud se v této oblasti pracovalo pouze s rozpoznáváním izolovaných slov a krátká slova se pro zjednodušení vynechávala.
Tento přístup není vhodný pro další lingvistické zpracování rozpoznaného textu.
Proto se pokoušíme a lepší definice úlohy, která zahrnuje i souvislost rozpoznaného textu.
Rozšířili jsme anotaci stávajících datastetů a vyvinuli evaluační metriku, které bude sloužit k hodnocení rozpoznávání souvislého textu.
Neuronové sekvenční modely jsou velmi slibným novým paradigmatem ve strojovém překladu, které dosahuje srovnatelných výsledků s frázovým strojovým překladem.
Tento článek popisuje systém, se kterým se Univerzita Karlova účastnila soutěže při WMT16 v úkolech automatické post-editace strojového překladu a multimodálního strojového překladu.
V posteru jsem popsala jak víceslovné výrazy se dají reprezentovat a vyhledávít v systému KonText.
Vztah mwe se v současném vydání Universal Dependencies nepoužívá konzistentně.
To může být zčásti způsobeno rozdíly mezi jazyky, nicméně v našem příspěvku ukazujeme na blízce příbuzných jazycích, že tomu tak není vždy; i doslovně ekvivalentní výrazy jsou v některých případech anotovány rozdílně.
Článek se soustřeďuje na včlenění valenčního slovníku do systému TectoMT pro jazykový pár čeština-ruština.
Ukazuje na chyby ve valenci na výstupu ze systému a popisuje, jak začlenění slovníku ovlivnilo výsledky.
Ačkoli podle BLEU skóre nebylo zaznamenáno zlepšení, ruční inspekce prokázala zlepšení v některých konkrétních případech.
Tento článek popisuje paralelní korpusy s automatickou anotací pomocí několika nástrojů pro zpracování přirozeného jazyka, včetně lemmatizace, taggingu, rozpoznání a klasifikace pojmenovaných entit a jejich disambiguace, word-sense disambiguation  a koreference.
Tento článek představuje datovou sadu vytvořenou z přirozených dialogů, která umožňuje testovat schopnost dialogových systémů učit se nová fakta od uživatelů v průběhu dialogu.
Toto interaktivní učení pomůže s jedním z nejpodstatnějších problémů dialogových systémů v otevřených doménách, kterým  je omezenost dat, se kterými je dialogový systém schopen pracovat.
Představovaná datová sada, skládající se z 1900 dialogů, umožňuje simulaci interaktivního získávání rad od uživatelů v podobě odpovědí a podrobných vysvětlení otázek, které mohou být použity pro interaktivní učení.
Dataset sesbíraný z přirozených dialogů umožňující testovat schopnost dialogových systémů učit se nová fakta z uživatelských výpovědí v průběhu dialogu.
Dataset, skládající se z 1900 dialogů umožňuje simulovat interaktivní získávání denotací a vysvětlení k otázkám od uživatelů ve formě, která je vhodná pro interaktivní učení.
Chimera systém strojovéo překladu, který kombinuje hluboce lingvistické jádro TectoMT s frázovým strojovým překladačem Moses.
Pro anglicko-český překlad také používá post-editovací systém Depfix.
Všechny komponenty běží na platformě Unix/Linux a jsou open-source (dostupné z Perlového repozitáře CPAN a repozitáře LINDAT/CLARIN).
Hlavní webová stránka je https://ufal.mff.cuni.cz/tectomt.
Vývoj je momentálně podporován projektem QTLeap ze 7th FP (http://qtleap.eu).
Představujeme MLFix, systém pro automatickou statistickou post-editaci, který je duchovním následníkem pravidlového systému, Depfixu.
Cílem této práce bylo prozkoumat možné postupy automatické identifikace nejčastějších morfologických chyb tvořených současnými systémy pro strojový překlad a natrénovat vhodné statistické modely, které by byly postaveny na získaných znalostech.
Provedli jsme automatickou i ruční evaluaci našeho systému a výsledky porovnali s Depfixem.
Systém byl vyvíjen především na výstupech anglicko-českého strojového překladu, cílem ale bylo zobecnit post-editační proces tak, aby byl aplikovatelný na další jazykové páry.
Upravili jsme původní pipeline, aby post-editovala výstupy anglicko-německého strojového překladu, a provedli dodatečnou evaluaci této modifikace.
Cílem této práce je ukázat na datech Pražského závislostního korpusu, že domnělý volný slovosled v češtině ve skutečnosti volný není, a že je řízen jistými pravidly, odlišnými od pravidel gramatiky, které určují slovosled v jiných evropských jazycích, jako např. v angličtině, němčině nebo francouzštině.
Na nově anotovaných datech je rovněž testována implementace algoritmu pro rozdělení věty na základ a ohnisko na základě kontextové zapojenosti uzlů na tektogramatické rovině.
Výzkum korpusových dat se zabývá interakcí vztahů asociativní anafory a aktuálního členění větného.
Ve zprávě přestavujeme koncept aktuálního členění větného na základě funkčního generativního popisu.
V první části zprávy prezentujeme základní pojmy spojené s aktuálním členěním větným – zejména kontextovou zapojenost a výpovědní dynamičnost a popisujeme operativní kritéria na rozlišení základu a ohniska: tzv. otázkový test a test s negací.
V další části představujeme principy pro anotaci aktuálního členění větného v Pražském česko-anglickém závislostním korpusu.
Výroba a evaluace subjectivity lexikonu pro indonéštinu.
Výsledný slovník byl pořízen za využití automatického strojového překladu a jeho spolehlivost byla ověřena v rámci trénování pravděpodobnostního klasifikátoru na ručně označkovaných datech.
Představujeme nový systém pro generování přirozeného jazyka založený na sytaxi, který je možné trénovat z nezarovnaných párů vstupních reprezentací významu a výstupních vět.
Dělí se na větný plánovač, který inkrementálně staví hloubkově syntaktické závislostní stromy, a povrchový realizátor.
Větný plánovač je založen na A* vyhledávání s perceptronovým rankerem, který používá nové updaty na základě odlišných podstromů a jednoduchý odhad budoucího potenciálu stromů; povrchová realizace je zajištěna pravidlovým systémem z prostředí Treex.
První výsledky ukazují, že trénování z nezarovnaných dat je možné, výstupy našeho generátoru jsou většinou plynulé a relevantní.
Komplexní predikáty s funkčními slovesy představují z hlediska syntaktického popisu problematický jev.
Příspevěk se zabývá především distribucí valenčních doplnění funkčního slovesa a predikativního jména v syntaktické struktuře věty.
Na základě syntaktické analýzy pak navrhuje teoreticky adekvátní a přitom ekonomické zachycení komplexních predikátů.
Úloha 18 na SemEval 2015 definuje sémantickou závislostní analýzu (SDP) se širokým pokrytím jako problém nalezení vztahů mezi predikátem a jeho argumenty ve větě pro všechna plnovýznamová slova, tj.
sémantické struktury, která představuje relační jádro významu věty.
V tomto článku, který úlohu 18 představuje, zasazujeme tento problém do rámce dalších podúloh analýzy jazyka, představujeme a srovnáváme použité cílové reprezentace sémantických závislostí a shrnujeme zadání úlohy, informace o zúčastněných systémech, jakož i hlavní výsledky.
Zpráva popisuje poslední přírůstek v Archivu vizuální historie USC Shoah Foundation, kolekci rozhovorů se svědky a přeživšími genocidy Arménů, která je dostupná od dubna 2015 i v CVH Malach.
Pojednáno je o charakteristikách kolekce i o jejích specificích v rámci celého Archivu USC SF.
Představujeme metologii a výsledky průzkumu anotace víceslovných výrazů v treebancích.
Průzkum probíhal pomocí webu na principu wiki, kam přispívali lidé obeznámení s treebanky.
Výsledky průzkumu jsme studovali zejména z hlediska porovnání přístupů k předložkovým víceslovným výrazům, slovesným konstrukcím s předložkou a víceslovným pojmenovaným entitám.
V této prezentaci jsme představili první výsledky srovnání dvou anotačních schémat, PDiT a GECCo v oblasti zpracování diskurzních konektorů.
Tato zpráva popisuje účast týmu Univerzity Karlovy v Praze na CLEF eHealth 2015 Task 2.
Článek představuje výsledky společných úloh WMT15 -- překladu novinových textů, odhadu kvality překladu a automatické posteditace.
Do standardní překladové úlohy v 10 překladových směrech se letos zapojilo 68 systémů strojového překladu z 24 institucí.
Zároveň bylo vyhodnoceno 7 anonymizovaných systémů.
Úloha odhadu kvality překladu měla 3 podúlohy, kterých se zúčastnilo 10 týmů a celkem 34 systémů.
Pilotní úloha automatické posteditace měla 4 týmy, které odeslaly 7 systémů
Příspěvek představil problematiku strojového překladu při přenosu technologie z výzkumné sféry do rutinního komerčního využití a způsob hodnocení takového překladu v kontextu lokalizace dokumentace v oblasti ifnormačních technologií.
Shrnutí aktivit v oblasti strojového překladu v EU  včetně příspěvků několika projektů v této oblasti podporovaných Evropskou komisí, a směřování této oblasti směrem k jednotnému digitálnímu trhu v EU.
Byly prezentovány základy strojového překladu s použitím hloubkové jazykové analýzy podle tradičního systému "Vauquois trojúhelník", s využitím moderních statistických metod a metod strojového učení.
Rovněž byly ukázány poslední výsledky, kdy hybridní systém Chiméra vytvořený na ÚFAL MFF UK v rámci různých projektů zvítězil v soutěži en-cs překladačá na WMT 2015 Shared Task.
Technologická agentura České republiky již šest let poskytuje podporu v oblasti aplikovaného výzkumu.
Je odpovědná za tvorbu programů v oblasti aplikovaného výzkumu.
V prezentaci je představeno hodnocení programu Center kompetence TAČR, která byla hodnocena v polovině jejich existence.
V příspěvku byly prezentovány zušenosti Ústavu formáln a aplikované lingvistiky MFF UK s projekty v rámcových programech EU a zejména v programu Horizon 2020.
Přednáška představila projekty a další aktivity v oblasti jazykových technologií a speciálně strojového překladu pro tématickou oblast medicíny a lékařství.
V přednášce byl prezentován LINDAT/CLARIN jako uzel mezinárodní infrastrukturní sítě Clarin ERIC.
Zejména byl prezentován repozitář LINDAT/CLARIN a jeho možnosti ukládání a archivace jazykových a jiných dat, a s ním spojené služby.
V přednášce byly prezentovány známé a používané korpusy se zachycenou syntaktickou analýzou (Penn Treebank, Pražské závislostní korpusy) a jejich vztah k analýze váceslovných výrazů.
Cílem tohoto příspěvku je podrobně prozkoumat, jak se v syntakticky anotovaných korpusech zachází s prvky věty, které jsou na povrchu vypuštěné, a pokusit se o kategorizaci výpustek v rámci víceúrovňového anotačního schématu.
V příspěvku se prezentuje způsob zachycení vybraných typů elips v češtině v rámci FGP.
Jde zejména o vypouštění zájmenného subjektu v 1. a 2. osobě, o nepřítomnost subjektu v kontrolovaných infinitivních konstrukcích,o konstrukce uvozené "kromě" a "místo" a o srovnávací konstrukce.
Webová služba pro podporu indexování naskenovaných obsahů knih.
Pro Národní technickou knihovnu.
Technická zprava shrnuje pravidla pro tvorbu valenčního slovníku (CzEngVallexu) českých a anglických sloves,  budovaného na základě paralelního závislostního korpusu (PCEDT) a dvou existujících valenčních slovníků: PDT-Vallexu a EngVallexu.
Zabýváme se aplikací UD na slovanské jazyky.
Nejvíce prostoru věnujeme zájmenům, determinátorům, číslovkám a kvantifikátorům.
Kromě toho diskutujeme i další jazykové jevy jako způsobová slovesa, elipsu, jmenné přísudky a zvratná zájmena.
Většina našich příkladů pochází z češtiny, ale jazykové jevy, které na příkladech ukazujeme, jsou obvykle přenositelné na další slovanské jazyky.
Tam, kde je to vhodné, uvádíme příklady i z jiných jazyků.
HamleDT (HArmonized Multi-LanguagE Dependency Treebank) je sbírka existujících závislostních korpusů (nebo do závislostí převedených jiných syntaktických korpusů), transformovaných do jednotného anotačního stylu.
Tato verze používá Universal Dependencies jako svůj ústřední anotační styl.
Sestavili jsme slovník víceslovných entit BBN a následně jsme jej využili ke kontrolám anotací (anotace WSJ, BBN, PCEDT).
Depfix -- open-souce systém pro automatickou post-editaci výstupů frázového strojového překladu.
Depfix zapojuje řadu nástrojů pro automatické zpracování přirozeného jazyka, pomocí nichž získává rozbor vstupních vět, a používá sadu pravidel pro opravu závažných chyb či chyb obvyklých ve výstupech strojových překladačů.
Toto je sada konfiguračních souborů parseru MSTperl a skriptů pro přenos delexikalizovaného parseru.
Byly použity v práci popsané v článku arXiv:1506.04897 (http://arxiv.org/abs/1506.04897) a v několika souvisejících článcích.
Parser MSTperl je dostupný na adrese http://hdl.handle.net/11234/1-1480
MSTperl je Perlovou reimplementací MST parseru  Ryana McDonalda, s několika pokročilými funkcemi navíc, jako je podpora pro paralelní rysy.
Porovnáváme dva anotační styly, Pražské závislosti a univerzální     Stanfordské závislosti, ve smyslu jejich vhodnosti pro parsing.
Konkrétně se zaměřujeme na porovnání stylu zavěšení adpozic, použivaného v těchto dvou     formalismech, na úloze vícezdrojového mezijazyčného přenosu delexikalizovaného parseru,     používajíce MSTParser.
Zjišťujeme, že v našem scénáři se stává zřetelnou výhoda Stanfordského stylu,     neboť převod anotace adpozic v treebancích anotovaných v Pražském stylu do Stanfordského stylu vede k mírně lepšímu výsledku (+0.2%     UAS).
Dále ukazujeme, že nejlepších výsledků lze dosáhnout pomocí natrénování parserů     na treebancích využívajících oba styly anotace adpozic, analýzy cílového     treebanku pomocí všech těchto parserů a kombinace všech získaných stromů,     po jejich převodu do stejného anotačního stylu (dalších +0.18% UAS).
Rozdíly ve skóre jsou ještě vyšší, když se použije menší sada různorodých zdrojových     treebanků (až 2.24% UAS oproti základní verzi).
Představujeme naši práci v oblasti částečně řízené syntaktické analýzy vět přirozeného jazyka, se zaměřením na mezijazyčný přenos delexicalizovaných závislostních parserů s více zdroji.
Nejprve vyhodnocujeme vliv anotačního stylu treebanku na úspěšnost parsingu, se zaměřením na styl zavěšení adpozic.
Poté představujeme KLcpos3, empirickou míru podobnosti jazyků, navrženou a vyladěnou pro vážení zdrojových parserů  při přenosu delexicalizovaných parserů s více zdroji.
Nakonec představíme novou metodu kombinace zdrojů, založenou na interpolaci natrénovaných modelů parserů.
Představujeme implementaci doménové adaptace pomocí  interpolace překladových modelů v TectoMT, překladovém systému s hloubkovým transferem.
Vyhodnotili jsme tuto metodu na šesti jazykových párech s doménovým paralelním korpusem o 1000 větách, a získali jsme zlepšení až o 3 body BLEU.
Váhy pro interpolaci jsou nastaveny uniformně, bez zapojení jakéhokoliv ladění.
Představujeme KLcpos3, míru podobnosti jazyků založenou na Kullbackově-Leiblerově divergenci rozložení trigramů hrubých značek slovních druhů v otagovaných korpusech.
Tato míra byla navržena pro vícejazyčný delexicalizovaný parsing, a to jak pro výběr zdrojového treebanku při přenosu parseru s jedním zdrojem, tak pro vážení zdrojových treebanků při přenosu parseru s více zdroji.
V úloze výběru zdroje rozpozná KLcpos3 nejlepší zdrojový treebank v 8 z 18 případů.
V úloze vážení zdroje přínáší zvýšení UAS o +4.5 procentního bodu oproti nevážené kombinaci stromů.
Představujeme interpolaci natrénovaných modelů MSTParseru jako metodu kombinace zdrojů pro vícezdrojový delexikalizovaný přenos parseru.
Představujeme jak neváženou metodu, tak variantu ve které je každý zdrojový model vážen podobností zdrojového a cílového jazyka.
Vyhodnocení na sbírce treebanků HamleDT ukazuje, že vážená interpolace modelů má podobnou úspěšnost jako vážená kombinace stromů, přičemž je mnohem méně komputačně náročná.
CloudASR je cloudová platforma pro automatické rozpoznávání řeči, která umožňuje dávkové i online zpracování nahrávek.
Její hlavní přednosti jsou škálovatelnost, přizpůsobitelnost a snadný proces nasazaní.
CloudASR je softwarová platforma a veřejná služba pro rozpoznávání řeči.
Její tři silné stránky jsou: kvalita rozpoznávání na úrovni stavu poznání, jednoduché nasazení, a škálovatelnost.
Dále, obsahuje anotační rozhraní pro přidávání transkripcí.
API platformy podporuje jak dávkovou tak online rozpoznávání.
Dávková verze je kompatibilní s Google Speech API.
Platforma umožňuje přidání nových rozpoznávačů, které potom můžou fungovat paralelně vedle sebe.
MT-ComparEval je nástroj, který umožňuje vývojářům strojového překladu porovnávat a vyhodnocovat různé MT systémy a jejich verze.
MT-ComparEval obsahuje několik metrik pro vyhodnocení strojového překladu.
Představujeme aktuální vývoj korektor, je statistický systém kontroly pravopisu.
Kromě lexikonu, Korektor používá jazyk modely najít chyby real-slovo, detekovatelná pouze v kontextu.
Modely a chyba probanického, vyvozené z chyb korpusů, jsou také používány pro navrhovaly GEST nejpravděpodobnější opravy.
Korektor byl původně vyškolení na malé chyby korpusu a použité jazykové modely extrahuje z in-house corpus WebColl.
Ukážeme dvě nedávná zlepšení: • Postavili jsme nové jazykové modely z volne dostupný schopné (šoural) verze České národní korespondence hnis a ukazují, že tyto provádět trvale lepší na texty vyráběných jak rodilými mluvčími a non-nativní studenti češtiny.
• Trénovali jsme nové modely chyb na ručně s poznámkami žák korpus a ukázat, že lepší výkon než Standardní model chyba (detekce chyb) nejenom pro texty studenty ", ale také pro naše standardní hodšpatne rozpoznaných zpráv data rodilého Čecha.
Pro korekci chyb se standardní model chyba překonaly non-nativní modulárně els ve 2 ze 3 testovaných datových sad.
Diskutujeme důvody pro tento ne zcela intuitivní zlepprostředí.
Na základě těchto poznatků a na základě analýzy chyb základě v obou domorodec a češtině frekventantů, navrhujeme směry pro další zlepšení korektor.
Cílem práce je (i) srovnat přístupy k analýze a anotaci textových jevů v PDiT a GECCo a (ii) určit společné a rozdílné rysy mezi odpovídajícími vědeckymi paradigmaty.
Sledování dialogového stavu je důležitá komponenta moderních dialogových systémů.
Ukazujeme inkrementální sledovač dialogového stavu založený na LSTM sítích.
Ke sledování používá přímo výsledky rozpoznávání řeči.
Ukazujeme klíčová nestandardní aspekty modelu, které pomáhají dostat úspěšnost sledovače k systémům v současném stavu poznání: zahrnutí skóre rozpoznávače, abstrakce málo viděných hodnot, použití transkripce pro trénování a průměrování modelu.
Sledování dialogového stavu je důležitou součástí moderních řečových dialogových systémů.
Navrhujeme první inkrementální trénovatelný sledovač dialogového stavu, který používá přímo výstup z rozpoznávače řeči ke sledování stavu.
Je založen na sítích s dlouhou krátkodobou pamětí a je plně trénovatelný z anotovaných dat.
Dosahujeme slibných výsledků na sledování pod-úkolů Method a Requested v DSTC2.
Nekrolog obsahující zhodnocení vědeckého přínosu jedné ze zakladatelek počítačové lingvistiky, americké badatelky prof. J. J. Robinson.
Představujeme CLARIN Concept Registry, nový registr sémantických konceptů, který je dostupný on-line a jeho smyslem je sloužit jako definice konceptů, na které se odkazují projekty CLARIN.
Tento nový registr nahrazuje (pro účely CLARINu) ISOcat.
Probíráme různé problémy, které komplikovaly používání ISOcatu, a navrhujeme řešení těchto problémů v CCR.
V monografii je představen výzkum vztahů působících společně ve výstavbě textu (syntaktická výstavba, aktuální členění, sémantické diskurzní vztahy v užším smyslu, koreference a asociativní anafora).
Cílem posteru je přispět do diskuze o diskurzních konektorech, zejména o jejich definici a o kritériích, podle kterých je možné vymezit jejich hranice.
V článku překládáme pilotní studii zaměřenou na anotaci významu slov získaných z několika informačních zdrojů.
Studie je prvním krokem z zamýšlené anotací "ukotvení".
Představujeme pilotní experimenty s anotací významů slov ve webovém anotačním prostředí.
Významy přitom pocházejí z několika různých zdrojů.
Experimenty jsou prvním krokem v plánované větší anotaci a měly by nám pomoci s výběrem podmnožiny studovaných zdrojů tak, aby pokrývaly veškerý text v co největším rozsahu a současně vykazovaly přijatelnou úroveň shody mezi anotátory.
Představujeme podrobnou analýzu kombinace systému založeného na transferu TectoMT se statistickým systémem Moses pro překlad mezi angličtinou a češtinou.
Popisujeme možnosti zkoumání této kombinace systémů jak pomocí ruční, tak i automatické evaluace.
Přesto, že výstupy TectoMT často obsahují chyby, Moses dokáže z jeho výstupů vybrat vhodné části.
V mnoha případech pak TectoMT poskytne nové, užitečné překladové varianty, které jsou pro statistickou komponentu jinak nedosažitelné, navzdory velikosti trénovacích dat.
Naše analýzy potvrzují, že TectoMT napomáhá dodržení gramatické shody a požadavků valence, ale zároveň zlepšuje překlad rozmanité škály jazykových jevů.
Zahrnutí výstupů systému založeného na transferu do frázového překladu má také zřejmě pozitivní vliv na prohledávaný prostor hypotéz.
Zjišťujeme, že jednotlivé komponenty této kombinace jsou komplementární a výsledný systém překládá signifikantně lépe než kterákoliv jednotlivá komponenta.
Představujeme diskriminativní model s bohatou sadou rysů pro strojový překlad, který využívá abstraktní sémantickou reprezentaci na zdrojové straně.
Náš model využíváme jako nový rys ve frázovém překladači a dosahujeme mírných zlepšení BLEU skóre v experimentu n-best reranking.
V této práci se zaměřujeme na postojovou analýzu aspektů, což je relativně nová úloha z oblasti počítačového zpracování přirozených jazyků (NLP).
Představujeme novou datovou sadu v češtině, která sestává z uživatelských hodnocení produktů z oblasti IT.
Zároveň popisujeme průběh naší práce na automatické extrakci aspektů.
Věříme, že tato oblast může účastníky workshopu zaujmout a že tento příspěvek podnítí diskuzi na toto téma s výzkumníky z příbuzných oborů.
Parsito je rychlý závislostní parser napsaný v C++ vydaný jako open-source.
Parsito je založené na transition-based parsingu, má vysokou úspěšnost a dosahuje rychlosti 30 tisíc slov za sekundu.
Parsito lze natrénovat na libovolných vstupních datech, bez nutnosti navrhovat jazykově závislé rysy, protože používá klasifikátor založený na neuronových sítích.
K dispozici jsou natrénované modely pro všechny treebanky z projektu Universal Dependencies (37 treebanků k prosinci 2015).
MorphoDiTa (morfologický slovník a tagger) je open-source nástroj pro morfologickou analýzu textů v přirozených jazycích.
Provádí morfologickou analýzu, morfologické generování, tagování a tokenizaci a je distribuován jako samostatný nástroj nebo jako knihovna spolu s natrénovanými lingvistickými modely.
V českém jazyce dosahuje MorphoDiTa state-of-the-art výsledků s rychlostí 10-200 tisíc slov za sekundu.
MorphoDiTa je svobodný software pod LGPL licencí a jazykové modely jsou zdarma pro nekomerční použití a jsou distribuovány pod CC BY-NC-SA licencí, i když u některých modelů mohou původní data použitá k vytvoření modelu implikovat další licenční podmínky.
V článku popisujeme přechodový neprojektivní závislostní parser používající klasifikátor založený na neuronových sítích, který nevyžaduje tvorbu rysů.
Dále představujeme nové přechodové orákulum, které zvyšuje úspěšnost parseru porovnatelně s dynamickým orákulem, ale je použitelné pro každý přechodový systém, jako například neprojektivní systém s operací swap.
Parser je velmi rychlý, jeho modely kompaktní, přičemž dosahuje vysoké úspěšnosti bez potřeby dalších zdrojů jako například korpusů s čistým textem.
Parser jsme otestovali na všech 19 korpusech z projektu Universal Dependencies.
Implementaci parseru v jazyce C++ uvolňujeme jako open-source.
S přibývajícím množstvím dat a služeb dostupných v infrastruktuře LINDAT/CLARIN roste potřeba správně citovat, sdílet, odkazovat a získávat statistiky využití.
Představení frameworku, který zajišťuje jednotný vzhled a zmíněnou funkcionalitu.
Poruzumění mluvené řeči (Spoken language understanding, SLU) a konkrétněji sémantický parsing je zásadní komponentou každé řečové aplikace.
Tento článek podává přehled současného výzkumu v oblasti SLU s důrazem na metody strojového učení používané k tomuto účelu.
Sledujeme aktuální trendy v sémantickém parsingu a diskusi uzavíráme výhledem na nejslibnější směry výzkumu do budoucna.
Doktorská práce se zabývá lingvistickou analýzou diskurzních vztahů jakožto jednoho z aspektů textové koherence.
Diskurzními vztahy rozumíme významové vztahy mezi jednotlivými propozicemi v textu, tzv. diskurzními argumenty.
Cílem práce je ucelený popis diskurzních vztahů v češtině a jeho vtělení do anotačního schématu Pražského závislostního korpusu.
Práce je rozdělena do tří částí: První z nich je zaměřena na teoretický popis diskurzních vztahů a rozbor vhodnosti různých metodologických postupů při korpusovém zpracování.
Druhá část podrobně popisuje navržené schéma pro anotaci diskurzních vztahů a proces vzniku takto značeného korpusu včetně evaluace konzistence značených dat.
V poslední části práce se pak věnujeme některým problematickým okruhům při užití navrženého schématu a jejich řešení.
Cílem Rozpoznávání textu z fotografií (STR) je právně lokalizovat a přespat text zachycený na fotografii z reálného prostředí.
Rostoucí úspěšnost rozpoznávání zároveň dělá z těchto textů zajímavý zdroj dat pro zpracování přirozeného jazyka a zároveň přináší nové problémy, které jsou specifické právě pro texty, které se na fotografiích vyskytují.
V tomto článku představujeme učení dekódování textových řetězců v systému STR pomocí metod strukturní predikce, které se využívají při dekódování v rozpoznávání řeči a strojovém překladu.
Model při učení využívá jazykové a typografické rysy.
Navržená metoda je evaluována  na standardní datové sadě a zvyšuje úspěšnost rozpoznávání znaků i rozpoznávání celých slov.
V této disertační práci zkoumáme strojový překlad mezi češtinou a ruštinou z hlediska lingvisty.
Hlavním cílem práce je lingvistický rozbor chyb ve výstupu čtyř systémů strojového překladu, dvou experimentálních - TectoMT, Moses - a dvou komerčních - PC Translator a Google Translate.
Analyzujeme každý typ chyb a řešíme, zda daná chyba souvisí s rozdílem mezi češtinou a ruštinou nebo zda je zapříčiněná architecturou jednotlivých systémů.
Ve zvláštní kapitole se zaměřujeme na chyby v povrchové valenci sloves.
Představujeme nový dialogový systém učící se z interakce s uživateli.
Systém žádá uživatele o radu u neznámých otázek a zobecňuje je v souladu se svou znalostní bází.
Dialogový systém je vyhodnocen prostředníctvím platformy CrowdFlower.
Cílem naší práce je prozkoumat možnost využití školních rozborů jako trénovací data pro automatickou syntaktickou analýzu.
Implementujeme editor pro procvičování tvaroslovných a větných rozborů.
Následně tyto rozbory shromažďujeme a transformujeme do tvaru potřebného pro trénování vybraného parseru.
Pilotním jazykem je čeština a cílovým formátem jsou anotace ve stylu Pražského závislostního korpusu.
Nyní se zaměřujeme na vyhodnocení větných rozborů a jejich kombinaci s cílem získat kvalitnější rozbory.
Práce se zabývá slovosledem aktantů (aktoru a patientu) v ohniskové části českých vět.
Slovosledná analýza výskytů aktoru a patientu přináší popis faktorů, které mohou ovlivnit uspořádání větných participantů ve slovosledu jako takových.
Poster představil tabulku kontextové zapojenosti závislých vět v češtině a popisuje důvody, proč bývají některé typy závislých vět českými pisateli častěji prezentovány jako čtenáři známé.
Tento výzkum rozvíjí myšlenku ekvikomplexity typologicky odlišných jazyků za pomocí konstrukční analýzy struktur obsahujících  adkolokační verbální idiomy.
Příspěvek popisuje možnosti vylepšení automatické detekce hodnocených entit v rámci postojové analýzy za využití metod kvantitativní lingvistiky, přesněji tematické koncentrace textu.
Přestože je postojová analýza široce zkoumaným odvětvím, většina výzkumu probíhá na prostém textu.
Tento poster ukazuje využití závislostních dat z PDT pro nejrůznější úlohy v rámci opinion miningu.
Při nasazování dialogového systému pro novou doménu je nutné se vypořádat s nedostatkem trénovacích dat pro doménově specifické statistické modely.
V tomto článku popisujeme své zkušenosti s vytvářením dialogového systému pro informace o veřejné dopravě a počasí přímo za provozu s uživateli z řad veřejnosti.
Postupovali jsme inkrementálně od minimálního systému, který byl nasazen na bezplatné telefonní číslo ke sběru řečových dat.
Na získaných datech jsme byli schopni natrénovat statistické modely – doménové jazykové modely pro rozpoznávání řeči a model pro porozumění jazyku, který používá automaticky generovanou sémantickou anotaci.
Náš postup ukazuje, že úspěšný systém lze postavit i s minimálním úsilím a bez předem dostupných trénovacích dat pro danou doménu.
Tento balíček obsahuje sady paralelních vět pro vývoj a testování strojového překladu souhrnů vědeckých článků z oboru medicíny mezi češtinou, angličtinou, francouzštinou a němčinou.
Lékařská překladová úloha na WMT 2014 představuje zajímavou výzvu pro strojový překlad (machine translation, MT).
Ve standardní překladové úloze je koncovou aplikací překlad sám o sobě.
Naproti tomu v této úloze je systém strojového překladu součástí většího systému pro mezijazykové vyhledávání informací (information retrieval, IR).
Vystadial 2013 ASR trénovací skripty obsahují skripty pro HTK a KALDI vyvinuté pro trénování akustických modelů pro automatické rozpoznávání řeči v dialogových systémech.
Vystadial 2013 je databáze telefonních hovorů v anglickém jazyce, vyvinuté pro trénování akustických modelů pro automatické rozpoznávání řeči v dialogových systémech.
Data obsahují více než 41 hodin v anglickém jazyce.
Roland Wagner v článku zaměřeném na česká reflexivní slovesa publikovaném v PBML prezentuje kritické výhrady k Funkčnímu generativnímu popisu (FGP).
Pro autory FGP představuje jeho článek výzvu k doplnění mezer v analýze daného jevu v rámci FGP a k vyjasnění některých teoretických předpokladů týkajících se valence sloves a jejich reflexivních protějšků.
Závislostní sémantickou analýzu se širokým pokrytím definujeme jako úlohu nalézt skladební dvojice mezi všemi autosémantickými slovy ve větě, tj.
strukturu sémantických závislostí, která reprezentuje jádro významu věty.
V této práci představujeme dva nedávno vydané open-source nástroje: NameTag je volně šiřitelný software pro rozpoznávání pojmenovaných entit, který dosahuje nejlepších známých výsledků na češtině; MorphoDiTa provádí morfologickou analýzu (s lematizací), morfologické generování, značkování a tokenizaci s nejlepšími známými výsledky pro češtinu a rychlostí zpracování kolem 10-200 tisíc slov za sekundu.
Nástroje mohou být natrénovány pro libovolný jazyk, pro který jsou k dispozici anotovaná data, jsou však zvlášť navrženy tak, aby byly efektivní pro flexivní jazyky.
Oba nástroje jsou volně šiřitelné pod licencí LGPL a jsou distribuovány spolu z předtrénovanými lingvistickými modely, které jsou zdarma pro nekomerční využití podle licence CC BY-NC-SA.
Vydání zahrnují samostatné nástroje, knihovny v C++ s vazbami pro Javu, Python a Perl, a konečně webové služby.
V článku popisujeme našu účasť v úlohe Search v  Search and Hyperlinking Task vrácmi Benchmarku MediaEval 2014.
Na základe našich experimentov porovnávame dva typy segmentácie: segmentácia na úseky rovnakej dĺžky a segmentácia, ktorá  využíva rozhodovacie stromy.
Taktiež ukážeme užitočnosť využitia metadát a preskúmame odstraňovanie prekrývajucich sa relevantných segmentov.
Podmnožina organizátorů Úlohy 8 na SemEvalu 2014 se pokusila použít k řešení úlohy parsery, které byly již dříve vyvinuty pro jednotlivé datové formáty využité v této úloze.
Kombinace výstupů těchto parserů byla zařazena jako samostatné řešení otevřené části úlohy (open track).
Použité systémy byly typicky vyvíjeny souběžně s anotací dat, konkrétně (a) pro formát DM jde o parser nad ručně sestavenou English Resource Grammar; (b) pro formát PAS jde o systém Enju s pravděpodobnostní HPSG, získanou lingvistickou projekcí PTB; a (c) pro formát PCEDT jde o scénář anglické tektogramatické analýzy v prostředí Treex, zahrnující statistický závislostní analyzátor a řadu cílených zpracovacích bloků, které převádějí stromy z analytické na tektogramatickou rovinu.
V článku popisujeme vydání rozsáhlého jednojazyčného korpusu urdštiny s automatickým značkováním slovních druhů.
Navazujeme na práci Jawaid a Bojar (2012), kde byly pro značkování použity tři taggery a finální výsledek určilo jejich hlasování.
Používáme stejnou komplexní sestavu na velký jednojazyčný korpus a výsledek zpřístupňujeme veřejnosti.
Kromě toho na tomto velkém korpusu trénujeme jeden samostatný tagger, což, doufáme, podstatě zjednoduší zpracování urdštiny.
Tento samostatný tagger na nezávislých testovacích datech dosahuje přenosti 88,74 %.
Poster představující souhrnné informace o Centru vizuální historie Malach, jeho aktivitách a dostupných archivních zdrojích.
Různé pokusy o konceptualizaci často vágně užívaného pojmu kolektivní paměť dospívají k závěru, že kolektivní paměť je hluboce provázaná s jazykovými a narativními fenomény.
V tomto příspěvku je mým cílem předložit přehled a diskusi souvislosti mezi jazykem a kolektivní pamětí v kontextu sociální teorie.
V díle zakládajících teoretických postav M. Halbwachse a J. Assmanna je význam jazyka ve vztahu k otázkám kolektivní paměti chápán jako ústřední.
Stejně tak v posledních dvou dekádách se ze specifické role narativu a konverzace stává významný předmět teoretického výzkumu kolektivní paměti.
Na druhou stranu, v empirických šetřeních jako by byl vztah jazyka a kolektivní paměti spíše podceňován.
Ukazuje se, že různé společenskovědní a humanitní disciplíny se s podobnými tématy vyrovnávají značně odlišně a rozdíly lze nalézt také v míře explicitní pozornosti věnované tématu kolektivní paměti.
Technická zprava shrnuje pravidla anotace koreference v Pražském česko-anglickém závislostním korpusu.
Tento článek popisuje Parmesan, náš příspěvěk na  Workshop on Statistical Machine Translation 2014.
Ukazuje, že parafrázovací tabulky Meteoru pro češtinu obsahují tolik šumu, že jejich použití ve skutečnosti může poškodit výkon metriky.
Nicméně po důkladní filtraci mohou být velmi užitečné v cíleném parafrázovní referenčních vět předcházejícím evaluaci.
Parmesan nejprve provede cílené parafrázování referenčních vět a poté spočítá Meteor score s pouze přímou shodou na těchto nových referencích.
Na datech z WMT12 a WMT13 ukazuje signifikantně vyšší shodu s lidským hodnocením než Meteor.
Představujeme metodu cíleného parafrazování pro zpřesnění hodnocení strojového překladu.
V jejím rámci, využíváme strojový překld samotný a upravujeme jej tak, aby překládal v rámci jediného jazyka.
Popisujeme tento přístup na dvou typech strojového překladu - statistickém a pravidlovém.
V rámci statistického překladu experimentujeme s Mojžíšem, volně dostupným nástrojem pro statický strojový překlad.
Překladové modely tvoříme uměle ze dvou dostupých zdrojů českých parafrází - českého WordNetu a parafrázovacích tabulek Meteor.
Rozšiřujeme Mojžíše o nový rys, který vynucuje cílené parafrázování.
Bohužel, naše výsledky jsou spíše negativní.
S ohledem na chyby, které se objevily v parafrázovaných větách, navrhujeme nové řešení - parafrázování pomocí pravidlového systému Treex.
Tato zpráva popisuje účast týmu Univerzity Karlovy v Praze na ShARe/CLEF eHealth Evaluation Lab in 2014.
Představujeme rozšíření Kaldi automatického rozpoznávání řeči toolkit pro podporu on-line rozpoznávání řeči.
Výsledný rozpoznáč podporuje state-of-the-art  akustické modely.
(MFCC, MLLT + LDA, BMMI) Vzhledem k tomu, že rozpoznávání produkuje slovní posteriorní lattice, je užitečné zejména v systémech statistických dialogu.
V evaluaci se zaměříme na on-line rozpoznávání řeči v dialogovém systému Alex pro doménu "veřejné dopravy České republiky".
Dialogový systém je k dispozici na veřejném bezplatném 800 899 998 řádek.
V tomto článku je presentováno rozšíření Kaldi toolkitu pro rozpoznávání řeči, které podporuje on-line rozpoznávání.
Vysledný rozpoznávač řeči podporuje moderní modelovací metody.
Jelikož rozpoznávač vytváří slovní posteriorní svazy, je obzvlášt vhodný pro statistické dialogové systémy, které umí pracovat s nejistotou rozpoznávače řeči.
Experimenty ukazují, že online rozpoznávač má výrazně lepší výsledky vzhledem k latenci pri srovnání s rozpoznávačem v cloudu.
Přehled problémů, které ve strojovém překladu způsobuje bohatá morfologie na cílové straně a naše techniky, jimiž se s nimi vyrovnáváme.
Představujeme dosažené výsledky ve statistickém strojovém překladu z angličtiny, němčiny, španělštiny a francouzštiny do češtiny.
Probíráme specifické vlastnosti jednotlivých zdrojových jazyků a popisujeme techniky, které těchto vlastností využívají a zaměřují se na odstranění chyb specifických pro daný jazyk.
Kromě vlastního překladu také prezentujeme náš příspěvek k chybové analýze.
Článek představuje výsledky společných úloh WMT14 -- překladu novinových textů, překladu textů z oblasti medicíny, odhadu kvality překladu a metrik strojového překladu.
Do standardní překladové úlohy v 10 překladových směrech se letos zapojilo 143 systémů strojového překladu z 23 institucí.
Zároveň bylo vyhodnoceno 6 anonymizovaných systémů.
Úloha odhadu kvality překladu měla 4 podúlohy, kterých se zúčastnilo 10 týmů a celkem 57 systémů.
Představujeme HindEnCorp, paralelní hindsko-anglický korpus, a HindMonoCorp, jednojazyčný hindský korpus ve verzi 0.5.
Oba korpusy byly získány z webových zdrojů a předzpracovány primárně pro trénování systémů statistického strojového překladu.
HindEnCorp sestává z 274k paralelních vět (3,9 miliónů hindských a 3,8 miliónů anglických tokenů).
HindMonoCorp obsahuje 787 miliónů tokenů ve 44 miliónech vět.
Oba korpusy jsou zdarma přístupné pro nekomerční výzkum a jejich předběžné vydání bylo využito řadou účastníků společné překladové úlohy WMT 2014.
Představili jsme přehled činností naší katedry s důrazem na nástroje NLP užitečné pro textovou analytiku.
V úvodní stati sborníku se předkládají argumenty o závažnosti zpracování valence v teoretickém i aplikačním rámci.
Hlavní pozornost je věnována valenci substantiv a ověřování platnosti hypotéz uplatněných při zpracování valence sloves.
Nekrolog a přehled lingvistických vědeckých příspěvků velkého amerického lingvisty.
Popis současných právních problémů s jazykovými daty a jazykovými technologiemi.
Situace a možné perspektivy využívání persistentních identifikátorů (PID) v LINDAT/CLARIN.
Prezentace o ustavení a budování důvěry ve vztahu poskytovatel dat - infrastruktura - uživatel.
Prezentace vývoje a současného stavu repozitáře projektu EUDAT k bezpečnému ukládání a sdílení vědeckých dat.
Přehled služeb poskytovaných centrem LINDAT/CLARIN a jejich demonstrace online.
Tento balíček obsahuje datové sady pro vývoj a testování modelů strojového překladu pro krátké vyhledávací dotazy v oblasti medicíny, a to pro čestinu, angličtinu, francouzštinu a němčinu.
Dotazy obsažené v datech pochází jak od zdravotnických profesionálů, tak od laické veřejnosti.
Tento článek popisuje vývojové a testovací datové sady pro strojový překlad dotazů k vyhledávání informací v oboru medicíny napříč jazyky.
Data sestávají z 1508 skutečných uživatelských dotazů zadaných v angličtině a přeložených do češitny, němčiny a francouzštiny.
Popisujeme proces překladu a korektur, kterého se účastnili odborníci na medicínu, a představujeme základní experiment, při kterém jsou naše datové sady použity pro ladění a evaluaci systému pro strojový překlad.
Článek srovnává české a anglické anotace na pozadí formalismu Abstract Meaning representation.
Článek má tři cíle.
Za prvé seznamuje čtenáře se současnou verzí anotačního nástroje pro diskurzní vztahy v Pražském závislostním korpusu 3.0.
Za druhé představuje samotné diskurzní vztahy v tomto korpusu, včetně novinek ve srovnání s předchozím vydáním.
A za třetí ukazuje, jak v tomto korpusu vyhledávat, se zaměřením na diskurzní vztahy.
Cíl příspěvku je poměrně skromný: sebrat jednoduché statistiky z různých rovin Pražského závislostního korpusu a na nich ukázat jejich užitečnost pro jazykový výzkum, a to jako doklad pro existující jazykové teorie nebo jako inspirace pro nové směry výzkumu či nová vysvětlení existujících otázek.
Za tímto účelem jsme shromáždili data z již publikovaných článků o PDT (s odkazy na příslušných místech), přidali některé novější výsledky a vyvodili obecnější důsledky podstatné pro autory zabývající se českou gramatikou.
Lingua::Interset je univerzální sada morfosyntaktických rysů, do které je možné zobrazit všechny sady značek všech korpusů a jazyků.
Verze 2.026 pokrývá 64 různých sad značek pro 37 jazyků.
Představujeme HamleDT – Harmonizovaný vícejazyčný závislostní korpus (HArmonized Multi-LanguagE Dependency Treebank).
HamleDT je sbírka existujících závislostních korpusů (nebo jiných korpusů převedených do závislostní syntaxe), transformovaných tak, aby všechny odpovídaly jednotnému anotačnímu stylu.
V tomto článku představujeme podrobný rozbor řady jevů, které jsou v různých jazycích srovnatelné, jejich zachycení v korpusech se však často liší.
Tvrdíme, že je možné navrhnout takové transformační procedury, které většinu zmíněných jevů automaticky rozpoznají a převedou do jednotného stylu.
Tato normalizace je důležitá jak pro komparativní lingvistiku, tak pro strojové učení syntaktické analýzy.
Technická zpráva shrnuje nová anotační pravidla pro anotovaní českých textů na tektogramatické rovině Pražských závislostních korpusů, která doplňují velký anotační manuál (ÚFAL/CKL TR-2005-28).
Pravidla vznikla v souvislosti s anotováním korpusů PCEDT 2.0 a PDTSC 2.0.
The European project Khresmoi aims to develop a multilingual and multimodal search and access system  for bilomedical information and documents.
Příspěvek uvádí sadu slovesných předpon, které spolu s reflexním morfémem mění význam slovesa, a to vždy stejným způsobem.
Předpony tvoří posloupnost podle stupně intenzity, kterou pozměňují akci popisovanou daným slovesem.
Představujeme proces intenzifikace slovesa ve třech slovanských jazycích, a to v češtině, slovenštině a ruštině.
Článek popisuje plně automatické propojování dvou valenčních slovníku českých sloves: VALLEXu a PDT-Vallexu.
I přes společný teoretický základ, z něhož oba vycházejí, a přes stejné jazykové jevy, na něž se zaměřují, není plně automatické propojování snadné.
Ukážeme, že konverze slovníku do společného formátu představuje tu snadnější část úlohy, kdežto automatická identifikace dvojic odpovídajících si valenčních rámců přináší obtíže.
Celkovou dosaženou přesnost 81% lze považovat za uspokojivou.
Je však třeba si uvědomit, že s rostoucím počtem lexikálních jednotek slovesa klesá přesnost automatického mapování.
Ukážeme, že značně pomůže, pokud (i) poskytneme doplňující informace o lexikálních jednotkách a (ii) odhalíme a sladíme pravidelné nesrovnalosti v anotaci v obou slovnících.
The development of a database of Czech derived words is described, focusing on linguistic aspects of this task.
In Czech, which is a Slavic language with both rich inflectional and derivational morphology, derivation is the most frequent and most productive word-formation process.
The database of Czech derived words was designed as a lexical network, which consists of lexemes and derivational relations (links) between them, oriented from the base to the derived word.
The derivational relations were processed automatically under a thorough manual supervision in order to ensure efficiency and consistency on the one hand and theoretical adequacy on the other.
Tento článek popisuje framework dialogových systémů Alex (ADSF).
ADSF v současné době zahrnuje komponenty pro telefonii, detekci hlasu, rozpoznávání řeči, porozumění řeči a pravěpodobností sledování stavu dialogu.
ADSF je používáno v reálné aplikace pro poskytování informací o veřejné dopravě, "PTI" doméně.
V "PTI" doméně uživatelé komunikují s dialogovým systémem pomocí telefonu, aby získali informace o dopravních spojeních jak v MHD tak mezi městy.
Na základě uživatelských hodnocení je naprostá většina uživatelů se systémem spokojena.
Manuál podává instrukce pro instalaci a běh Depﬁxu, našeho open-source nástroje pro automatickou post-editaci strojového překladu.
V dokumentu pokrýváme kroky potřebné k užití Depﬁxu pro zpracování Vašich vlastních dat.
Manuál také obsahuje popis Depﬁxové pajplajny, včetně instrukcí, které vám umožní změnit fungování Depﬁxu.
Představujeme Depfix -- open-souce systém pro automatickou post-editaci výstupů frázového strojového překladu.
Depfix zapojuje řadu nástrojů pro automatické zpracování přirozeného jazyka, pomocí nichž získává rozbor vstupních vět, a používá sadu pravidel pro opravu závažných chyb či chyb obvyklých ve výstupech strojových překladačů.
Depfix je momentálně implementován pouze pro překladový směr z angličtiny do češtiny, ale v plánu je jeho rozšíření na další jazyky.
Depfix je open-souce systém pro automatickou post-editaci výstupů frázového strojového překladu.
Depfix zapojuje řadu nástrojů pro automatické zpracování přirozeného jazyka, pomocí nichž získává rozbor vstupních vět, a používá sadu pravidel pro opravu závažných chyb či chyb obvyklých ve výstupech strojových překladačů.
Depfix je momentálně implementován pouze pro překladový směr z angličtiny do češtiny.
Pohádkové dítě je jednoduchý chatbot, simulující zvídavé dítě.
Požádá uživatele, aby mu vyprávěl pohádku, ale často ho přerušuje, aby se zeptal na detaily a vysvětlení.
Pamatuje si ale, co mu uživatel řekl, a snaží se to pokud možno dát najevo.
Chatbot umí komunikovat česky a anglicky.
Analyzuje tvarosloví každé uživatelovy věty pomocí NLP nástrojů, pokusí se nalézt chodnou otázku, a tu pak položí.
Aby tvořené české věty zněly co nejpřirozeněji, využívá se pro skloňování tvaroslovný generátor.
Pohádkové dítě (Fairytale Child) je jednoduchý chatbot, snažící se napodobovat zvídavé dítě.
Žádá uživatele, aby mu vyprávěl pohádku, a často jej přerušuje, aby se zeptal na podrobnosti či si ujasnil některé věci.
Pamatuje si nicméně, co mu bylo řečeno, a snaží se to dát pokud možno najevo.
Chatbot umí komunikovat česky a anglicky.
Analyzuje morfologii každé věty, kterou uživatel zadal, za pomoci nástrojů pro zpracování přirozeného jazyka, snaží se rozpoznat potenciální otázky, na které by se mohl zeptat, a poté jednu z nich uživateli položí.
Ke stvoření správně vyskloňované české věty se používá morfologický generátor.
MSTperl je Perlovou reimplementací MST parseru  Ryana McDonalda, s několika pokročilými funkcemi navíc, jako je podpora pro paralelní rysy.
A simple way of browsing CoNLL format files in your terminal.
Fast and text-based.
Existuje sbírka 30 závislostních korpusů (HamleDT) a existují i další závislostní korpusy; avšak na světě je kolem 7000 jazyků, a budovat závislostní korpus pro každý z nich se zdá být nepraktickým.
Proto navrhuji prozkoumat možnosti částečně řízeného závislostního větného rozboru (pravděpodobně pomocí promítnutí z více zdrojů).
Taktéž navrhuji obecně použití mlhavějších vstupních rysů (zejména tvaroslovných značek).
Představujeme HamleDT 2.0 (HArmonized Multi-LanguagE Dependency Treebank).
HamleDT 2.0 je sbírka 30 existujících závislostních korpusů, harmonizovaných do společného anotačního stylu – Pražských závislostí – a dále transformovaných do Stanfordských závislostí – anotačního stylu, který se v nedávné době stal oblíbeným.
Používáme nejnovější základní Universal Stanford Dependencies, bez dodaných jazykově specifických subtypů.
Popisujeme oba anotační styly, včetně úprav, které bylo nutné provést, a poskytujeme detaily o procesu konverze.
Diskutujeme též rozdíly mezi těmito dvěma styly, vyhodnocujíce jejich výhody a nevýhody, a zmiňujeme vliv těchto rozdílů na konverzi.
Stanfordizaci obecně považujeme za úspěšnou, přestože uznáváme několik nedostatků – zejména v rozlišení přímých a nepřímých předmětů – kterým je nutné v budoucnosti věnovat pozornost.
Část HamleDT 2.0 volně zveřejňujeme; nemáme svolení k redistribuci celé datové sady, ale poskytujeme nástroje pro konverzi.
Klíč k rychlému přizpůsobení jazykových technologií pro libovolný jazyk  závisí na dostupnosti základních nástrojů a datových zdrojů, jako jsou jednojazyčné nebo paralelní korpusy, anotované korpusy, značkovače slovních druhů, syntaktické analyzátory, a podobně.
Jazyky, pro něž tyto základní zdroje  neexistují, označujeme jako zdrojově chudé jazyky.
V této práci se zabýváme otázkou závislostního syntaktického rozboru zdrojově  chudých jazyků za pomoci zdrojů pro jiné jazyky.
Pro nalezení závislostní struktury používáme tři postupy: (i) promítnutí závislostí ze zdrojově bohatého jazyka do zdrojově chudého jazyka za pomoci slovního zarovnání v paralelním  korpusu (ii) analýze pod-zdroji jazyků pomocí parserů, jejichž modely jsou vyškoleni na  stromových korpusů z jiných jazyků, a nedívejte se na skutečných slovních forem, ale pouze na  POS kategorie.
Zde se zabýváme problémem neslučitelnosti různých anotačních stylů používaných zdrojovými analyzátory a  cílovými závislostně anotovanými korpusy používanými pro evaluaci, který řešíme  pomocí harmonizace anotací do jednotného standardu; a konečně (iii) zavádíme  nový postup, ve kterém pro promítnutí závislostí do zdrojově chudého jazyka používáme paralelní korpusy vytvořené pomocí strojového překladu namísto lidského překladu.
Výše uvedené postupy jsme použili na pět indických jazyků: hindštinu, urdštinu,  telugštinu, bengálštinu a tamilštinu (seřazeno sestupně podle dostupnosti závislostně anotovaných dat).
Abychom prokázali použitelnost uvedených postupů v praxi, vyvinuli jsme závislostně anotovaný korpus pro tamilštinu, pro niž dosud žádný takový zdroj neexistoval, a takto získaná data využíváme pro evaluaci a také jako zdroj pro závislostní rozbor jiných indických jazyků.
Nakonec jsme seznam se strategie, které může být použit k získání závislost struktury pro cílových jazyků pod jiný scénáře s omezenými zdroji.
Tento dokument se vrací k přístupu projekce založené na závislost gramatiky indukční úkol.
Tradiční cross-kulturní závislost indukční úkoly jeden tak či onak, závisí na existenci  z bitexts nebo cílového jazyka nástrojů, jako je část-of-speech (POS) značkovače, abychom získali přiměřenou analýze přesnosti.
V tomto článku jsme se přenést závislost analyzátory pomocí pouze orientační zdroje, tj, stroje přeloženy bitexts namísto ručně vytvořených bitexts.
Děláme to tak,  získání zdrojového stranu textu ze strojového překladu (MT) systém a pak použít Přenos přístupy k vyvolání analyzátor pro cílové jazyky.
Dále snižují potřebu Informace o dostupnosti značených cílového jazyka zdrojů pomocí voze cílové tagger.
Ukázali jsme, že náš přístup stále překonává bez dozoru analyzátory o větší rozpětí  (8,2% absolutní), a výsledky v podobném provedení, kdy ve srovnání s delexicalized převodem  analyzátory.
Jedním z nejdůležitějších aspektů cross-kulturní přenos závislostí  je to, jak různé anotace styly, které často podceňují přesnost syntaktické jsou zpracovány.
Novým trendem je, že styl anotace různých jazykových stromových korpusů může být harmonizovány do jednoho stylu, a tak se lze vyhnout těžkopádné pravidla manuální transformace.
V tomto článku budeme používat harmonizované stromových korpusů (POS tagsets a závislost struktury původní  stromových korpusů mapované do společného stylu) pro vyvolání závislosti na nastavení cross-kulturní.
Nabízíme převod závislostí pomocí delexicalized analyzátory, které používají harmonizované verze původních stromových korpusů.
Tento přístup aplikovat na pět indických jazyků (Hindština, Urdu, Telugu, bengálský a Tamil) a ukazují, že  Nejlepšího výkonu lze získat delexicalized analýze, kdy dojde k přemístění z indického jazyka (IL) na IL stromových korpusů.
Tento článek prezentuje výsledky úlohy 3 z ShARe/CLEF eHealth Evaluation Lab 2014 zaměřené na  uživatelskou evaluace vyhledávání informací v oblasti zdraví
Prezentace aplikace JTagger, která detekuje reference v českých soudních rozhodnutích.
Tento úkol chápeme jako typický úkol pro identifikaci jmenných entit, kde entity jsou reference (odkazy) na jiné dokumenty.
Aplikujeme přístupy strojového učení s učitelem, konkrétně skryté Markovovy modely.
Protože metody strojového učení s učitelem vyžadují manuálně anotovaná trénovací data, anotovali jsme 300 soudních rozhodnutí.
Aplikace detekuje reference v českých soudních rozhodnutích.
Tento úkol chápeme jako typický úkol pro identifikaci jmenných entit, kde entity jsou reference (odkazy) na jiné dokumenty.
Aplikujeme přístupy strojového učení s učitelem, konkrétně skryté Markovovy modely.
Protože metody strojového učení s učitelem vyžadují manuálně anotovaná trénovací data, anotovali jsme 300 soudních rozhodnutí.
Článek popisuje pokus o vyřešení problému rozpoznávání klauzí a jejich vzájemných vztahů v českých souvětích na základě omezených informací, jmenovitě informací toliko získaných morfologickou analýzou.
Metodu popsaná v tomto článku lze v budoucnu použít pro rozdělení procesu automatické syntaktické analýzy do dvou fází, a to 1) určení klauzí a jejich vzájemných vztahů a 2) syntaktická analýza jednotlivých klauzí.
Tento přístup by měl zlepšit úspěšnost automatické syntaktické analýzy dlouhých souvětí.
Poster je zaměřen na popis možností vyjadřování textových vztahů v češtině.
Textové vztahy bývají vyjadřovány zejména diskurzními konektory, ale také jejich alternativními lexikálními vyjádřeními, jako např. "důvodem je".
Cílem prezentace bylo představit průzkum širších možností vyjadřování textových vztahů, resp.  představit, které jazykové prostředky (kromě "klasických" konektorů jako "a" nebo "avšak") mají schopnost signalizovat určitý vztah mezi dvěma jednotkami v textu.
Prezentace představila výsledky výzkumu diskurzních konektorů v širším smyslu založeném na korpusové analýze (s využitím Pražského závislostního korpusu a korpusu DIALOG).
Článek představuje možnosti využití vícevrstvé anotace Pražského závislostního korpusu.
Zaměřuje se přitom na překrývání koreferenčních vztahů a diskurzních vztahů vyjádřených víceslovnými konektory.
Článek se snaží prozkoumat, jaké aspekty tyto dvě jazykové oblasti spojují a jakým způsobem můžeme toto vzájemné překrývání využít při automatickém vyhledávání konektivních spojení typu "navzdory tomu", "díky této skutečnosti", která mají v textu platnost víceslovných konektorů.
Představujeme naše systémy pro překlad angličtina→čeština a angličtina→hindština, se kterými jsme se zúčastnili letošní překladové soutěže WMT.
Pro směr angličtina→čeština vycházíme z loňského systému CHIMERA a vyhodnocujeme několik nastavení.
Angličtina→hindština je letos novým jazykovým párem.
Provedli jsme pokusy se zpětným samoučením pro získání většího množství (umělých) paralelních dat a s modelováním tvarosloví cílové strany.
Prezentácie popisuje skúsenosti a rozhodnutia s vytvorením lingvistického repozitára.
Použitie EUDAT B2SAFE replikácie z repozitára postavenom na DSpace vrátane implementácie
Článek popisuje metriku pro automatickou evaluaci strojového překladu, odeslanou jako řešení soutěžního úkolu WMT14 Metrics Task.
Jedná se o jednoduchou modifikaci známého BLEU skóre, která používá párování slov v testovací a referenční větě v cílovém jazyce.
Počítá se vždy nejmenší párování zhledem k relativní editační vzdáleností prefixů a sufixů slov.
Spárovaná slova v testovací věty jsou nahrazena slovy z referenčního překladu.
Při výpočtu n-gramové přestnoti jsou pak n-gramy obsahující taková slova penalizovány proporcionálně ke vzdálenosti, podlé které se slova párovala.
Kurz seznámí studenty s metodami zpracování morfologie přirozených jazyků.
Začíná lingvistickým přehledem morfologie.
Dále se zabývá korpusy, tagsety a anotací.
Jádrem kurzu jsou supervised, unsupervised, a částečně supervised metody morfologické analýzy, morfologické segmentace, tvorba slovníků atd.
Kurz zahrnuje jak standardní metody, tak diskuzi nedávných důležitých článků například Yarowsky & Wicentowski 2000, Creutz & Lagus 2007, Monson 2009 a Tepper & Xia 2010.
Even though the quality of unsupervised dependency parsers grows, they often fail in recognition of very basic dependencies.
In this paper, we exploit a prior knowledge of STOP-probabilities (whether a given word has any children in a given direction), which is obtained from a large raw corpus using the reducibility principle.
By incorporating this knowledge into Dependency Model with Valence, we managed to considerably outperform the state-of-the-art results in terms of average attachment score over 20 treebanks from CoNLL 2006 and 2007 shared tasks
Tato technická zpráva se zabývá alternativními reprezentacemi koordinačních struktury a vlivem jednotlivých řešení na úspěšnost závislostního parsingu.
Článek uvádí do problému generovaní přirozeného jazyka a podává krátké shrnutí nedávného vývoje tohoto oboru, přičemž se zaměřuje na využití statistických metod.
Největší důraz je kladen na generování jazyka v hlasových dialogových systémech, ale ostatní oblasti využití jsou také zmíněny.
Článek končí přehledem problémů, je nutné vyřešit při vývoji vícejazyčného generátoru jazyka pro hlasový dialogový systém.
Prezentujeme novou metodu statistického generování morfologie, tj.
predikce konkrétní slovní formy z lemmatu, slovního druhu a morfologických kategorií, která cílí na robustnost vůči neznámým vstupům.
Náš systém používá trénovatelný klasifikátor pro predici „editačních scénářů“, které posléze použije k transformaci lemmat na cílové slovní formy.
Pro dosažení robustnosti jsou jako atributy pro klasifikaci použity také sufixy lemmat.
Náš systém byl vyhodnocen na šesti jazycích s různým stupněm morfologické bohatosti.
Výsledky ukazují, že systém je schopen se naučit většinu morfologických jevů a generalizuje na neznámé vstupy, takže dosahuje signifikatně lepších výsledků než baseline založený na slovníku.
Článek představuje koncept korespondenčního semináře jakožto prostředku, jak doplnit a podpořit jednorázové soutěže, zejména olympiády.
Vyhodnocujeme jednotlivé výhody tohoto způsobu výuky lingvistiky a porovnáváme jeho charakter s charakterem lingvistické olympiády.
Věříme, že korespondenční seminář je výborný způsob, jak přivést talentované středoškolské studenty k lingvistice.
Představujeme nový rozpoznávač pojmenovaných entit pro český jazyk, který dosahuje 82.82 F-measure na korpusu Czech Named Entity Corpus 1.0 a statisticky významně překonává dříve publikované české rozpoznávače pojmenovaných entit.
Na anglické úloze CoNLL-2003 shared task dosahuje 89.16 F-measure.
Tento výsledek je srovnatelný s anglickými současnými výsledky.
Rozpoznávač je založen na maximum entropy markovském modelu a optimální sekvence pojmenovaných entit je dosaženo globálním dekódováním Viterbiho algoritmem pomocí pravděpodobností odhadnutých maximum entropy klasifikátorem.
Klasifikátor využívá morfologickou analýzu, dvojúrovňovou predikci, clusterizaci slov a gazetteers.
Nová verze ručně anotovaného korpusu zaměřeného na pojmenované entity.
Popisujeme naše pokusy s frázovým strojovým překladem pro společnou úlohu WMT 2013.
Natrénovali jsme jeden systém pro 18 překladových směrů mezi angličtinou nebo češtinou na jedné straně a angličtinou, češtinou, němčinou, španělštinou, francouzštinou nebo ruštinou na straně druhé.
Popisujeme sadu výsledků s různými velikostmi trénovacích dat.
Pro páry obsahující ruštinu navíc popisujeme sadu nezávislých pokusů s lehce odlišnými překladovými modely.
V článku popisujeme prístup, ktorý sme použili v Search Subtasku v úlohe Search and Hyperlinking vrácmi Benchmarku MediaEval 2013.
Popisujeme rôzne prístupy k segmentácii nahrávok na menšie úseky, ktoré sú potom využité pri štandardnom vyhľadávaní.
Na segmentáciu používame rozdelenie na krátke úseky rovnakej dĺžky a tiež metódy strojového učenia, založené na našom riešení použitom v úlohe Similar Segments in Social Speech.
Rozhovor pro anglické vysílání Radia Praha o strojovém překladu a nové knížce, která jej přibližuje českému čtenáři.
V dnešní době stoupá zájem a potřeba inovativních řešení pro medicínské vyhledávání.
V tomto článku představujeme systém Khresmoi pro medicínské vyhledávání a získávání informací, podporovaný Evropskou unií, na kterém se podílí dvanáct partnerů a který je momentálně ve třetím roce vývoje ze čtyř.
Systém Khresmoi používá architekturu založenou na komponentách a provozovanou v cloudu, tak aby umožňovala vývoj několika inovativních aplikací, uspokojujících medicínské informační potřeby cílových uživatelů.
Vyhledávací systémy Khresmoi založené na této architektuře byly navrženy tak, aby podporovaly vícejazyčné a víceúčelové informační potřeby tří cílových skupin: všeobecné veřejnosti, praktických lékařů a radiologů.
V tomto článku se zaměřujeme na představení systémů pro praktické lékaře a radiology s využitím sémantického vyhledávání, vícejazyčného textového vyhledávání a vyhledávání založeného na obrázcích (zahrnujícího 2D a 3D radiologické obrázky).
V tomto článku se analyzují problémy anotace generických jmenných frází ve velkém jazykovém  korpusu.
Podává se přehled existujících teorií referencí generických NP, tyto teorie se pak srovnávají s přístupy k generickým NP v aplikačních projektech a se situací v anotací koreference v různých korpusech.
Po představení anotace generických NP v Pražském závoslostním korpusu se rozebírají typické problematické situace a obecné potíže a nabízí se některá řešení vylepšující kvalitu anotace.
Představujeme výsledky anotace koreference a asociační anafory v Pražském závislostním korpusu 2.0.
Anotace byla provedena na závislostních stromech tektogramatické roviny.
Popisujeme měření mezianotátorksé shody a klasifikujeme a analyzujeme nejčastější typy anotátorské neshody.
Na dvou vybraných delších textech jsme požádali anotátory o značení jistoty jejich rozhodnutí; tuto jistotu porovnáváme s výsledky měření mezianotátorské shody.
Zkoumáme výhody závislostních stromů a tektogramatických struktur použitých v Pražském závislostním korpusu pro anotaci jazykových jevů překračujících hranici věty, jmenovitě koreference a asociační anafory.
Uvádíme výhody závislostních stromů jako podrobné zpracování elips, syntaktické řešení koordinace a apozice umožňující značkování koreference v případech, které jsou přímo na textu složitější.
Toto je vydání PyKaldi pro rok 2013 - verze 1.0.
Tento kód obsahuje modifikace gmm-lat-gen-faster dekodéru, které umožňují jeho použití v úloze rozpoznávání mluvené řeči v reálném čase.
Změny jsou založeny na povrchové modifikaci původního kódu pomocí dědění z původního dekodéru a přidání online zpracování vstupu včetně LDA+MLLT transformací.
Navíc, tento kód obsahuje Python knihovnu takže samotný dekodér může být použit z libovolného programu napsaného v Python programovacím jazyku.
Článek popisuje naše příspěvky na WMT, systémy CU-BOJAR a CU-DEPFIX, později nazvaný "chiméra", protože kombinuje tři rozdílné přístupy: TectoMT, systém s transferem na úrovni hloubkové syntaxe, faktorový frázový překlad pomocí nástroje Moses, a konečně automatický pravidlový korektor častých gramatických a významových chyb.
Nepoužíváme žádnou standardní metodu systémové kombinace.
Jedna z hlavních obtíží při automatickém vyhodnocování strojového překladu je závislost na několika (typicky na jediném) lidských referenčních překladech, se kterými se výstup překladového systému srovnává.
Navrhujeme metodu, jak zachytit milióny možných překladů, a implementujeme nástroj, s jehož pomocí mohou překladatelé takové překlady popsat v kompaktní reprezentaci.
Vyhodnocujeme takto vzniklou novou referenční sadu s použitím editační vzdálenosti a korelace s lidským hodnocením kvality překladu.
Představujeme emana, nástroj pro správu velkého množství výpočetních experimentů.
V průběhu let našeho výzkumu strojového překladu (MT) jsme sesbírali několik nápadů pro efektivní experimentování.
Věříme, že tyto nápady jsou obecně použitelné v (počítačovém) výzkumu v libovolném oboru.
Zahrnuli jsme je do emana, aby byly dostupné v prostředí příkazové řádky Unixu.
Cílem článku je zvýraznit hlavní myšlenky v pozadí těchto nápadů.
Doufáme, že text bude sloužit jako sbírka tipů pro správu experimentů pro každého, nezávisle na konkrétním oboru nebo počítačové platformě.
Konkrétní příklady, které ukazujeme v současné syntaxi nástroje eman, jsou méně důležité, ale umožňují užití konkrétních termínů.
Článek tedy zároveň vyplňuje mezeru v dokumentaci emana tím, že podává abstraktnější pohled na tento nástroj.
Zamyšlení nad dílem významného českého lingvisty a slavisty prof. L. Matějky, který byl významným propagátorem české lingvistiky i kultury vůbec v mezinárodnim měřítku.
O velkém českém lingvistovi a jeho přispění lingvistice, zejména o jeho aktuálním členění.
Cílem příspěvku je představit anotaci aktuálního členění v české části Pražského česko-anglického závislostního korpusu.
Podáváme zprávu o tomto prvním kroku v procesu vytváření paralelní anotace aktuálního členění v tomto korpusu a podrobně popisujeme automatickou předanotaci české části.
Výsledky předanotace jsou vyhodnoceny na základě srovnání automatické a ruční anotace.
Pražský závislostní korpus arabštiny, verze 1.5, je kolekce textů v moderní arabštině, obohacená o ruční morfologickou a závislostní anotaci.
Naším cílem je predikovat rodný jazyk (L1) autorů anglických esejí za pomoci korpusu TOEFL11, ve kterém jsou známy jazykové úrovně autorů a témata esejí.
Úlohu řešíme jako klasifikační úlohu pomocí řízených metod strojového učení.
Zaměřujeme se na ladění atributů, mezi které jazykovou úroveň a témata nezahrnujeme.
Atributy navrhujeme napříč jazyky L1.
Experimentujeme s několika technikami pro filtrování a kombinaci atributů s ohledem na kritéria z informační teorie.
Celkem jsme natrénovali čtyři modely SVM a pomocí většinového hlasování je zkombinovali do modelu dosahujícího úspěšnosti 72.5%.
Fenomén volného slovosledu hraje důležitou roli v syntaktické analýze mnoha přirozených jazyků.
Tento příspěvek zavádí pojem slovosledného posunu ('shiftu'), který odrážející stupeň volnosti slovosledu.
Slovosledný posun je operace založená na slovosledných změnách zachovávajících syntaktickou správnost, jednotlivé slovní tvary, jejich morfologické charakteristiky a jejich syntaktické vztahy v průběhu tzv. redukční analýzy, tedy postupného zjednodušování věty.
Příspěvek přináší lingvistickou motivaci pro tuto operaci a zaměřuje se na formální popis celkového mechanismu pomocí speciální třídy automatů, tzv. restartovacich automatů s operací shift  obohacených strukturovaným výstupem strukturovaný výstup.
Cílem této studie je objasnit vlastnosti výpočtů potřebných k provedení (rozšířené) redukční analýzy pro přirozené jazyky s volným slovosledem.
Wikipedie slouží nejen jako rozsáhlá encyklopedie zasahující do mnoha odvětví, ale v poslední době stále častěji i jako zdroj jazykových dat pro nejrůznější aplikace.
Jednotlivé jazykové mutace umožňují získat i paralelní data ve více jazycích.
Zařazení článků wikipedie do kategorií potom může sloužit k filtrování jazykových dat.
V našem projektu se zabýváme automatickým překladem textů v oboru biologie a lékařství, proto jsme potřebovali větší množství paralelních dat.
Jedním ze zdrojů byla právě wikipedie.
Pro výběr dat splňujících daná kritéria – tedy dané obory v daných jazycích – jsme využili projektu Dbpedia, který ze stránek wikipedie extrahuje strukturované informace a ve formátu RDF je zpřístupňuje uživatelům.
V příspěvku popíšeme postup extrakce dat a problémy, které jsme museli řešit, neboť u otevřeného projektu jako wikipedie, do něhož může přispívat kdokoli, nelze spoléhat na konzistenci.
V češtině a v ruštině existuje množina prefixů, které mění význam nedokonavých sloves vždy stejným způsobem.
Změna často (v českém jazyce vždy) vyžaduje přidání reflexivního morfému.
Tato vlastnost nedokonavých sloves může být použita pro automatické rozpoznávání slov, aniž by bylo nutné ukládat takto vzniklé tvary do morfologických slovníků.
Článek zkoumá jev volného slovosledu.
Soustředí se na vztak mezi (formální) závislostí a slovosledem.
Zkoumání je provedeno aplikací poloautomatické metody redukční analýzy na česká syntaktický anotovaná data.
Volnost slovosledu je vyjádřena pomocí počtu nutných záměn v průběhu redukční analýzy.
Článek ukazuje, že tato míra je ortogonální k mírám vyjadřujícím volnost slovosledu pomocí počtu neprojektivních konstrukcí či klitik ve větě.
Článek se zabývá metodou identifikace zajímavých konstrukcí v syntakticky anotovaném korpusu češtiny (Pražském závislostním korpusu) pomocí aplikace automatické procedury redukční analýzy na stromy tohoto korpusu.
Procedura odhaluje některé lingvistické jevy, které jdou za hranici "závislosti".
Článek obsahuje diskuzi a analýzu jednotlivých jevů a rovněž kvantifikuje výsledky automatické procedury na podmnožině korpusu.
V příspěvku shrnujeme základní rysy Dokulilovy teorie slovotvorné produktivity a zasazujeme ji do kontextu zkoumání produktivity v posledních desetiletích.
Na materiálu z velkých korpusů češtiny zkoumáme produktivitu čtyř českých sufixů (-ost, -ství/ctví, -ismus, -ita) a ukazujeme, že jednotlivé míry používané ke kvantifikaci produktivity vedou k rozdílným výsledkům.
Tutoriál přibližující práci s nástrojem PML-TQ určeným pro prohledávání syntakticky anotovaných korpusů.
Představeny byly dvě verze klientského rozhraní, příklady používaly data v češtině, angličtině a němčině.
Představujeme Depfix, systém pro samočinnou post-edititaci výstupů frázových strojových překladů z angličtiny do češtiny, založený na jazykovědných znalostech.
Nejprve jsme rozebrali druhy chyb, kterých se dopouští typický strojový překladač.
Poté jsme vytvořili sadu pravidel a statistickou komponentu, které opravují takové chyby, které jsou běžné nebo závažné a může přicházet v úvahu jejich oprava pomocí našeho přístupu.
Používáme řadu nástrojů pro zpracování přirozeného jazyka, které nám poskytují rozbor vstupních vět.
Navíc jsme reimplementovali závislostní analyzátor a několika způsoby jej upravili pro provádění rozboru výstupů statistických strojových překladačů.
Provedli jsme automatická i ruční vyhodnocení, která potvrdila, že kvalita překladů se zpracováním v našem systému zlepšuje.
Depfix je systém pro samočinnou post-edititaci výstupů frázových strojových překladů z angličtiny do češtiny, založený na jazykovědných znalostech.
Rozebrali jsme druhy chyb, kterých se dopouští typický strojový překladač, a vytvořili jsme sadu pravidel a statistickou komponentu, které opravují některé z těchto chyby.
Používáme řadu nástrojů pro zpracování přirozeného jazyka, které nám poskytují rozbor vstupních vět.
Navíc jsme reimplementovali závislostní parser a několika způsoby jej upravili pro provádění rozboru výstupů statistických strojových překladačů.
Provedli jsme automatická i ruční vyhodnocení, která potvrdila, že kvalita překladů se zpracováním v našem systému zlepšuje.
Některé veci jsou pro PB SMT obtížné -- negace, shoda, trpný rod... Automatická post-editace může často pomoci -- i hrstka jednoduchých pravidel může fungovat velmi dobře.
NLP nástroje jsou typicky užitečné -- tagger, parser, morphologický generátor; adaptujte je pro zpracování výstupů SMT, je-li to možné.
Deepfix je statistický post-editovací systém pro zlepšování kvality výstupů statistického strojového překladu.
Pokouší se opravovat chyby ve slovesné a substantivní valenci za použití hloubkové syntactické analýzy a jednoduchého pravděpodobnostního valenčního modelu.
Na jazykovém páru angličtina-čeština ukazujeme že, pokud je podporována hlubokou lingvistickou znalostí, statistická post-editace statistického strojového překladu vede ke zlepšení  kvality překladu.
TamilTB 1.0 zlepšuje v průběhu prvního vydání Tamil závislostní korpus (TamilTB v0.1).
Aktuální verze přináší řadu vylepšení oproti pravopis a morfologické tagset údajů.
Nyní, primární datový reprezentace korpusu používá kódování UTF-8.
Prezentace prvních kroků směrem ke lingvistickému zpracování textů pro detekci sémantických vztahů v nich.
Naše práce je klíčovou součastí projektu INTLIB, kterého cílem je vytvořit efektivní a uživatelsky přívětivý nástroj pro dotazování nad textovými dokumenty, odlišný od full-textu.
Tento nástroj je navrhován jako obecní framework, který lze snadno modifikovat a rozšiřovat pro další domény.
Pilotní doménou projektu jsou legislativní texty.
Prezentujeme aplikaci JTagger, která detekuje reference v soudních rozhodnutích a aplikaci RExtractor, která extrahuje vztahy mezi entitami v českých zákonech.
Prezentujeme první kroky směrem k lingvistickému zpracování textů pro detekci sémantických vazeb.
Naše práce je důležitou částí projektu INTLIB, který má za cíl vytvořit efektivnější a uživatelsky více přívětivý nástroj na dotazování v textových dokumentech než full-textové vyhledávání.
Tento nástroj je navrhnut jako obecný framework, který bude možno modifikovat a rozšiřovat pro konkrétní datové domény.
Aktuálně se zaměřujeme na české legislativní dokumenty.
Aplikace detekuje reference v českých soudních rozhodnutích.
Tento úkol chápeme jako typický úkol pro identifikaci jmenných entit, kde entity jsou reference (odkazy) na jiné dokumenty.
Aplikujeme přístupy strojového učení s učitelem, konkrétně skryté Markovovy modely.
Protože metody strojového učení s učitelem vyžadují manuálně anotovaná trénovací data, anotovali jsme 300 soudních rozhodnutí.
Tato zpráva popisuje Addicter, nástroj pro automatickou detekci a vyhodnocení chyb, který dává uživateli k dispozici také grafické rozhraní, užitečné pro prohlížení dat.
Popis textových anotací a jejich vybraných problémů (anotace na stromech a na lineárním textu; nesoulad mezi syntaktickou a diskurzní strukturou; nevyjádřená myšlenka jako diskurzní argument)
Současné metody pro statistický strojový překlad obvykle využívají pouze omezený kontext ve zdrojové větě.
Mnoho jazykových jevů tak zůstavá mimo jejich dosah, např. gramatická shoda v morfologicky bohatých jazycích nebo lexikální výběr často vyžadují informace z celé zdrojové věty.
V této práci představujeme přehled metod modelování širšího kontextu ve strojovém překladu a popisujeme naše první experimenty.
Představujeme webovou službu, která zpracovává a distribuuje požadavky na strojový překlad (posílané přes HTTP ve formátu JSON).
V současné době se používá pro poskytování strojového překladu mezi několika jazyky ve vícejazyčném vyhledávání informací v rámci projektu Khresmoi.
Software sestává z aplikačního serveru a vzdálených workerů, kteří zajišťují zpracování textu a komunikují požadavky na překlad systémům strojového překladu.
Komunikace mezi aplikačním serverem a workery je založena na protoklolu XML-RPC.
Představujeme celkový návrh softwaru a výsledky testů, který dokumentují rychlost a škálovatelnost našeho řešení.
Software podléhá licenci Apache 2.0 a je dostupný ke stažení v repozitáři Lindat-Clarin a na serveru GitHub.
Stručně představujeme frázový strojový překlad a nástroj Moses.
Popisujeme Emana, nástroj pro správu experimentů, a ukazujeme, jak ho lze využít k trénování několika jednoduchých systémů pro strojový překlad.
Taxonomie strojového překladu Online učení Guided učení Easy-First dekódování ve strojovém překladu Guided učení ve strojovém překladu
Treex je platforma pro nástroje zpracování přirozeného jazyka.
NIF je formát založený na RDF, který by měl sloužit k propojování takovýchto nástrojů.
Přednáška popisuje Treex a další nástroje a treebanky vyvíjené na ÚFAL.
Zaměřuje se též na podobnosti a rozdíly s formátem NIF a iniciativou nlp2rdf.
O parataktických syntaktických strukturách je známo, že jejich zachycení pomocí závislostních mechanismů je obtížné, což má bolestivé důsledky jako značné množství chyb v automatické syntaktické analýze, které souvisí s koordinacemi.
Jinými slovy, koordinace je nevyřešeným problémem závislostní analýzy přirozených jazyků.
Tento článek se snaží vnést trochu světla do této oblasti a přináší systematický přehled různých formálních prostředků vyvinutých k zachycení souřadných struktur.
Přinášíme novou taxonomii takových přístupů a aplikujeme ji na treebanky z typologicky rozličné sady 26 jazyků.
Dále prezentujeme empirická pozorování, pokud jde o vzájemnou převoditelnost mezi vybranými styly zachycení.
Praktický seminář představení platformu Treex, která slouží k integraci nástrojů pro zpracování přirozeného jazyka.
Semináři předcházela přednáška o překladovém systému TectoMT vyvinutém v platformě Treex.
The poster deals with the sentence information structure (functional sentence perspective) in Czech, focusing on the tendency of the particular sentence constituents to appear in Czech sentence as topic or focus.
Článek popisuje a vyhodnocuje proces poloautomatické anotace vnitrovětných textových vztahů v Pražském závislostním korpusu, což je část projektu jinak především manuální anotace všech (vnitro- i mezi-větných) diskurzních vztahů s explicitními konektory v tomto korpusu.
Bohatá anotace korpusu nám umožnila ve většině případů automaticky najít vnitrovětné diskurzní vztahy, jejich konektory a argumenty.
Tato kapitola popisuje metody učení z dat vhodné pro vývoj systémů porozumění mluvené řeči pro dialogové systémy.
Nerízená závislostní analýza je alternativní zpusob urcování vztahu mezi slovy ve vete.
Nepotrebuje žádný anotovaný závislostní korpus, je nezávislý na jazykové teorii a univerzální pro velké množství jazyku.
Jeho nevýhodou je ale zatím relativne nízká úspešnost.
V této práci diskutujeme nekteré predchozí práce a predstavujeme novou metodu nerízenéhé analýzy.
Náš závislostní model se skládá ze ctyr podmodelu: (i) hranový model, který rídí rozdelení dvojic rídících a závislých clenu, (ii) model plodnosti, který rídí pocet clenu závislých na uzlu, (iii) model vzdálenosti, který rídí délku závislostních hran a (iv) model vypustitelnosti.
Tento model je založen na predpokladu, že slovau která se mohou z vety vypustit, aniž by se porušila její gramaticnost jsou v závislostním slove listy.
Odvození závislostních struktur provádíme pomocí Gibbsova vzorkovace.
Predstavujeme vzorkovací algoritmus, který zachovovává projektivitu závislostních stromu, cože je velmi užitecnou vlastností.
V našich experimentech na 30 jazycích srovnáváme výsledky pro ruzné parametry modelu.
Naše metoda prekonávvá dríve publikované výsledky pro vetšinu zkoumaných jazyku.
This paper describes a system for unsupervised dependency parsing based on Gibbs sampling algorithm.
The novel approach in- troduces a fertility model and reducibility model, which assumes that dependent words can be removed from a sentence without vio- lating its syntactic correctness.
V tomto příspěvku přinášíme popis alternačního modelu valenčního lexikonu českých sloves, VALLEX.
V práci rozlišujeme celkem dva základní typy alternací (změn ve valenční struktuře sloves): (i) gramatikalizované a (ii) lexikalizované alternace.
Jak gramatikalizované, tak lexikalizované alternace mohou být konverzní či nekonverzní povahy.
Zatímco gramatikalizované alternace spojují rozdílné povrchové strukturace téže lexikální jednotky, lexikalizované alternace charakterizují syntaktické struktury tvořené rozdílnými lexikálními jednotkami.
Pro účely reprezentace alternací rozdělujeme lexikon na datovou a pravidlovou část.
V datové části je každá lexikální jednotka reprezentována jedním valenčním rámcem.
Pravidlová část obsahuje dva typy pravidel: (i) formální syntaktická pravidla zachycující gramatikalizované alternace a (ii) obecná pravidla určující změny v korespondenci participantů a valenčních doplnění typické pro lexikalizované alternace.
Tato kapitola prezentuje současné poznatky v oblasti vývoje statistických dialogových systému založených na POMDP modelu řízení komunikace s uživatelem.
Postupně jsou vysvětleny základy POMDP a vhodné metody pro implementaci v oblasti dialogových systémů.
Fokus hodně závislostní analýzy se na vytváření nových modelovacích technik a zkoumání nových funkcí sady pro stávající závislost modelů.
Často jsou tyto nové modely mají to štěstí, aby dosahovaly rovnocenných výsledků s aktuálním stavem že umělecké výsledky a často vedou hůř.
Tyto přístupy jsou pro jazyky, které jsou často zdrojem bohaté a mají dostatek tréninková data k dispozici pro závislost rozebrat.
Z tohoto důvodu, přesnost výsledky jsou často dosti vysoká.
To, ze své podstaty, je to docela obtížné vytvořit výrazně velký nárůst v současném state-of-the-art.
Výzkum v této oblasti se často zabývá malými změnami přesnosti nebo velmi specifickým lokalizovaných změn, jako je zvýšení přesnosti a zejména jazykovou konstrukci.
S tolika technik modelování jsou k dispozici pro jazyky s velkým zdroji problém existuje o tom, jak využít stávající techniky s použitím kombinace, nebo souborem, techniky spolu s tímto množstvím dat.
Závislost analyzátory jsou téměř všude se vyskytující hodnoceny na jejich přesnost výsledků, tyto výsledky nemluvě o složitosti a užitečnosti výsledných struktur.
Tyto struktury mohou mít větší složitost vzhledem k hloubce jejich co- koordinační nebo podstatné jméno věty.
Jako závislost analyzuje jsou základní struktury, ve kterých jsou ostatní systémy postavené na, by se zdálo rozumné posouzení těchto parserů dolů potrubí NLP.
Typy parsování chyb, které způsobují významné problémy v jiných aplikacích NLP je v současné době znám.
Segmentácia na tématicky koherentné úseky je dôležitou súčasťou vyhľadávania informácií.
Vhodná segmentácia môže zlepšiť výsledky vyhľadávania a pomôcť užívateľom pri rýchlejšom hľadaní relevantného úseku.
Segmentácia je zvlášť dôležitá pri audiovizuálnych nahrávkach, v ktorých je navigácia zvlášť zložitá.
V článku popisujeme niekoľko prístupov ku tématickej segmentácii, založených na textovej, zvukovej a vizuálnej informácii.
V článku je tiež prezentovaný náš návrh prístupu k tématickej segmentácii, založený na fúzii zvukových a vizuálnych dát.
Anglicko-slovenský paralelný korpus, vytvorený z voľne dostupných zdrojov.
Korpus je prístupný v textovom formáte a s morfologickou anotáciou.
Množstvo trénovacích dát je pre kvalitu štatistického strojového prekladu rozhodujúce.
V článku popisujeme, akým spôsobom je možné zlepšiť kvalitu prekladu pre daný jazykový pár pomocou využitia paralelných dát v príbuznom jazyku.
Konkrétne sme vylepšili en→sk preklad pomocou využitia veľkého česko-anglického paralelného korpusu a cs→sk prekladového systému založeného na pravidlách.
Preskúmaných je niekoľko možností konfigurácie použitých systémov.
Testovacia sada z workshopu WMT 2011 manuálne preložená z češtiny a angličtiny do slovenčiny.
This paper describes the creation process of an Indonesian-English parallel corpus (IDENTIC).
The corpus contains 45,000 sentences collected from different sources in different genres.
Several manual text preprocessing tasks, such as alignment and spelling correction, are applied to the corpus to assure its quality.
We also apply language specific text processing such as tokenization on both sides and clitic normalization on the Indonesian side.
The corpus is available in two different formats: ‘plain’, stored in text format and ‘morphologically enriched’, stored in CoNLL format.
Some parts of the corpus are publicly available at the IDENTIC homepage
Dáta z troch zdrojov (časť korpusu Acquis, časť testovacej sady z WMT a vety vybrané z kníh) automaticky preložené pomocou piatich systémov (Česílko, Česílko 2, Google Translate a Moses s rôznymi nastaveniami) z češtiny do slovenčiny a ohodnotené troma anotátormi.
Preklady boli ručne zoradené podľa ich kvality.
Představujeme taxonomii pro faktorové modely frázového překladu a provádíme sérii experimentů s konfiguracemi z navržené taxonomie.
Odhalujeme přitom řadu chyb v návrhu překladových modelů, jichž je vhodné se vyvarovat.
Článek slouží rovněž jako popis našich systémů CU-BOJAR a CU-POOR-COMB v soutěži WMT12.
Závěrečná technická zpráva grantu EuroMatrixPlus popisující strojový překlad prostřednictvím stromových struktur s bohatou anotací.
Tři přídavné české referenční překlady celé datové sady WMT 2011 (http://www.statmt.org/wmt11/test.tgz), přeložené z němčiny.
Původní segmentace dat z WMT 2011 byla zachována.
Bílá kniha prezentuje stav podpory jazykových technologií pro češtinu.
Je částí série, která analyzuje dostupné jayzkové zdroje pro 30 evropských jazyků.
Eman („experimentální manažer“) je softwarový nástroj, který umožňuje řídit rozsáhlé soubory vzájemně provázaných experimentů, při kterých se zpracovávají velké datové soubory, typicky na výpočetním clusteru.
Byl vyvinut jako infrastruktura pro statistický strojový překlad, ale uplatní se i v jiných úlohách.
Návod, jak provádět širokou sérii experimentů (se zaměřením na strojový překlad).
Korpusová anotace je důležitou součástí lingvistické analýzy a počítačového zpracování jazyka.
Tento článek se zabývá problémy spojenými se syntaktickou anotací mluvených textů na pozadí syntaktické anotace ČAKu.
V přednášce představím software, který jsem vyvinul pro převod Kodaňského závislostního korpusu (CDT) do systému Treex.
CDT je vícejazyčný korpus vyvinutý v Copenhagen Business School.
Treex je multilinguální softwarový systém vyvinutý na Karlově univerzitě v Praze.
Treex se používá mimo jiné pro vývoj systémů strojového překladu.
Přednáška bude mít dvě části.
V první představím konverzní proceduru.
Ve druhé části předvedu možné způsoby, jak s daty v novém formátu pracovat.
The present work focuses on using tree-shaped syntactic structures as an intermediate sentence representation in an experimental English-Czech machine translation system.
Rozbor různých přístupů k pojetí a popisu stupňovitosti z hlediska aktuálního členění.
Hlavní principy explicitního pražského závislostního modelu jazyka postupující od funkce k formě.
Srovnání dvou teoretických přístupů k aktuálnímu členění a uplatnění pražského přistupu v anotovaném počítačovém korpusu češtiny.
Srovnání přístupu k aktuálnímu členění v české lingvistice, od základní práce Mathesiovy až po práce současné.
Článek shrnuje lingvistické problémy, na které jsme narazili a které řešili anotátoři při anotování informační struktury ve větách Pražského závislostního korpusu.
Tento software je modifikací a konfigurací Dspace 1.6, která umožňuje centrům Clarin, která používají Dspace jako svůj software pro repozitáře, využít službu Handle od konzorcia EPIC, doporučenou Clarinem, v rámci Dspace.
Tento příspěvek se zabývá vztahem korpusu a valenčního slovníku.
Slovník vznikl jako vedlejší produkt anotace Pražského závislostního korpusu, stal se důležitým zdrojem jak pro další lingvistický výzkum, tak pro počítačové zpracování češtiny.
Příspěvek popisuje systém použitý pro závislostní syntaktickou analýzu hindských dat v rámci soutěže na Colingu 2012.
Popisujeme naše pokusy s frázovým strojovým překladem pro soutěž WMT 2012.
Natrénovali jsme jeden systém pro 14 překladových párů mezi angličtinou nebo češtinou na jedné straně a angličtinou, češtinou, němčinou, španělštinou nebo francouzštinou na druhé straně.
Popisujeme sadu výsledků s různými velikostmi trénovacích dat a jejich podmnožin.
Postřehy z letošních pokusů na ÚFALu v rámci mezinárodní soutěže ve strojovém překladu.
Tento článek se zabývá formalizací popisu volného slovosledu přirozených jazyků.
Využívá mechanismu redukční analýzy a definuje míru volnosti slovosledu na základě počtu přesunů provedených v průběhu analýzy.
Tato míra umožňuje rozlišit složitost slovosledu (jak obtížné je analyzovat věty se složitějším slovosledem) a volnost slovosledu (do jaké míry je možné měnit slovosled, aniž by došlo ke změně jednotlivých slovních tvarů, jejich morfologické charakteristiky a / nebo jejich povrchově syntaktických vztahů).
Tento rozdíl je ilustrován na pilotní studii českých vět s klitikami.
Kapitola popisuje historii pokusů s automatickým překladem mezi příbuznými jazyky, použité metody a dosažené výsledky.
Představujeme nejnovější verzi Pražského závislostního treebanku PDT 2.5, který bude poprvé vydán pod veřejnou licencí.
Výhody PDT 2.5 ukážeme na srovnání s nejmodernějšími treebanky.
Představíme nové vlastnosti verze 2.5, popíšeme, jak byly anotovány i jak spolehlivá tato anotace je.
Ukážeme, jakými dotazy lze nové jevy hledat a jak se zobrazují v nástrojích dodávaných spolu s treebankem.
Článek se zabývá anotací větné modality v Pražském závislostním korpusu (PDT).
Větná modalita je v češtině vyjádřena kombinací několika faktorů, především slovesným způsobem a koncovou interpunkcí.
V PDT 2.0 byla větná modalita přiřazena poloautomaticky kořeni každé věty (stromu) a dále kořenům stromů reprezentujících vsuvku nebo přímou řeč.
Tento přístup byl příliš zjednodušující pro adekvátní zachycení daného jevu, proto byla metoda přiřazení větné modality pro příští vydání treebanku (PDT 3.0) zrevidována a rozpracována.
Zpětno vazební učení již bylo úspěšně použito k optimalizaci statisktických dialogových systémů.
Typicky zpětnovazební učení se učí online on-policy tj.
v přímé interakci s uživatelem.
Alternativou k tomuto přístupu je off-policy učení kdy otimální strategie řízení je určena z korpusu již dříve pořízených dialogů.
Tento článek prezentuje a nový zpětnovazební algoritmus založený na přirozených gradientech a vhodné adaptaci samplování dat.
Experimenty ukazují, že prezentovaný algoritmus je schopen se naučit strategii řízení, která je lepší než manuálně vytvořená strategie řízení.
Představujeme dvě metody pro trénování závislostního parseru vhodného pro parsing výstupů strojového překladu.
Upravili jsme MST parser použitím dalších rysů ze zdrojového jazyka a zavedením umělých gramatických chyb do trénovacích dat parseru, takže tato více odpovídají výstupu storjového překladu.
Upravený parser evaluujeme na systému DEPFIX, který zlepšuje výstupy anglicko-českého strojového překladu automatickými opravami založenými na pravidlech.
Obě úpravy parseru vedou ke zvýšení skóre BLEU; jejich kombinace byla evaluována manuálně a vykazuje statisticky signifikantní zlepšení kvality překladu.
Množstvo pozornosti v MT komunitě bylo v nedávne době věnováno zlepšování lexikálního výběru v cílovém jazyce pomocí zachycení kontextu širšího nežli jedna věta.
V této přednášce prezentuji náš příspěvek k těmto snahám, konkrétně pokrok v obohacování překladových modelů pro překlad z angličtiny do češtiny systémem TectoMT.
Ze všeho nejdřív jsme provedli čistě techický krok.
Nahradili jsme doteď používaný modul MaxEnt na strojové učení nástrojem Vowpal Wabbit.
Ten nám nejenom umožňuje trénovat modely rychleji a tím využít víc trénovacích příkladů a rysů, ale také nabízí bohaté možnosti parametrizace, co dohromady může vést k zlepšení našeho MT systému.
Nicméně, hlavním cílem tohoto pořád běžícího projektu je prozkoumat potenciál lexikálních kontextových rysů na vylepšení překladu.
Činíme tak přidáním standardních bag-of-words rysů a zavedením nových rysů reprezentujících koncepty z Explicitní Sémantické Analýzy, co je metoda původně vyvynuta v oboru Dobývaní znalostí.
V této přednášce jsem prezentoval posun témy mojeho výzkumu z využití koreference na využití textového kontextu všeobecně v úloze strojového překladu.
Představil jsem lexikální diskriminativní překladové modely a prvotní experimenty s nimi v rámci překladu z angličtiny do češtiny systémem TectoMT.
Anotované korpusy jako treebanks jsou důležité pro vývoj analyzátorů, jazykové aplikace, stejně jako porozumění Jazyk sám.
Jen velmi málo jazyků mají tyto omezené zdroje.
V tomto článku si popíšeme naše úsilí v syntakticky anotace malé korpusy (600 vět) z Tamil jazyce.
Naše anotace je podobný Pražského závislostního korpusu (PDT) a skládá se z Anotace na 2 podlažích či vrstev: (i) Morfologická rovina (m-layer) a (ii) analytické vrstvy (vrstvy).
U obou vrstev, uvádíme anotace programů, tj.
poziční značení pro m-layer a vztahy závislosti na několika vrstev.
Na závěr budeme diskutovat některé otázky v korpus vývoj pro Tamil.
Morph délka je jedním z orientační funkce , která pomáhá učit morfologii jazyků, zejména aglutinační jazyky.